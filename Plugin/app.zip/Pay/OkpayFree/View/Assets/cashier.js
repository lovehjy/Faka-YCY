/* OKPay 免费版收银台 */
(function () {
    "use strict";

    var page = document.querySelector(".okf-page");
    if (!page) return;

    var tradeNo = String(page.dataset.tradeNo || "").trim();
    var returnUrl = safeUrl(page.dataset.returnUrl);
    var timeoutMinutes = Math.min(120, Math.max(3, parseInt(page.dataset.timeoutMinutes, 10) || 10));

    var statusText = page.querySelector("[data-okf-status]");
    var countdownText = page.querySelector("[data-okf-countdown]");
    var openLink = page.querySelector("[data-okf-open]");
    var copyButton = page.querySelector("[data-okf-copy]");
    var backLink = page.querySelector("[data-okf-back]");

    var deadline = Date.now() + timeoutMinutes * 60 * 1000;
    var hardStop = deadline + 30 * 60 * 1000; // 超时后再等 30 分钟回调，之后停止轮询
    var pollDelay = 2500;
    var finished = false;
    var pollTimer = null;
    var tickTimer = null;

    function safeUrl(value) {
        try {
            var url = new URL(String(value || ""), window.location.origin);
            if (url.protocol === "http:" || url.protocol === "https:") return url.href;
        } catch (error) { /* 忽略非法地址 */ }
        return "";
    }

    function setText(node, value) {
        if (node) node.textContent = value;
    }

    function stop() {
        finished = true;
        if (pollTimer) window.clearTimeout(pollTimer);
        if (tickTimer) window.clearInterval(tickTimer);
    }

    function paid() {
        if (finished) return;
        stop();
        page.classList.remove("is-late", "is-closed");
        page.classList.add("is-paid");
        setText(statusText, "支付成功");
        setText(countdownText, "已确认");
        if (returnUrl) {
            setText(statusText, "支付成功，正在跳转…");
            window.setTimeout(function () { window.location.assign(returnUrl); }, 1200);
        }
    }

    function closed() {
        if (finished) return;
        stop();
        page.classList.remove("is-late", "is-paid");
        page.classList.add("is-closed");
        setText(statusText, "订单已关闭");
        setText(countdownText, "已失效");
        if (openLink) openLink.classList.add("is-disabled");
        if (copyButton) copyButton.disabled = true;
    }

    function tick() {
        if (finished) return;
        var left = deadline - Date.now();
        if (left <= 0) {
            setText(countdownText, "00:00");
            if (!page.classList.contains("is-late")) {
                page.classList.add("is-late");
                setText(statusText, "已超时，若已付款请稍候确认");
                pollDelay = 10000;
            }
            return;
        }
        var total = Math.ceil(left / 1000);
        var m = Math.floor(total / 60);
        var s = total % 60;
        setText(countdownText, (m < 10 ? "0" + m : m) + ":" + (s < 10 ? "0" + s : s));
    }

    function poll() {
        if (finished || !tradeNo) return;
        if (Date.now() > hardStop) { closed(); return; }

        var body = "tradeNo=" + encodeURIComponent(tradeNo);
        fetch("/user/api/order/state", {
            method: "POST",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "X-Requested-With": "XMLHttpRequest"
            },
            body: body
        }).then(function (response) {
            return response.json();
        }).then(function (result) {
            if (finished) return;
            if (Number(result.code) === 200 && result.data) {
                var state = Number(result.data.status);
                if (state === 1) { paid(); return; }
                if (state !== 0) { closed(); return; }
            }
            //非 200（限流等瞬时错误）不改变页面状态，稍后重试
            pollTimer = window.setTimeout(poll, pollDelay);
        }).catch(function () {
            if (!finished) pollTimer = window.setTimeout(poll, Math.max(pollDelay, 5000));
        });
    }

    function copyText(value) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            return navigator.clipboard.writeText(value);
        }
        return new Promise(function (resolve, reject) {
            var input = document.createElement("textarea");
            input.value = value;
            input.setAttribute("readonly", "");
            input.style.position = "fixed";
            input.style.opacity = "0";
            document.body.appendChild(input);
            input.select();
            try {
                document.execCommand("copy") ? resolve() : reject(new Error("copy failed"));
            } catch (error) {
                reject(error);
            } finally {
                document.body.removeChild(input);
            }
        });
    }

    if (copyButton) {
        copyButton.addEventListener("click", function () {
            var link = safeUrl(page.dataset.payUrl);
            if (!link) return;
            copyText(link).then(function () {
                var original = copyButton.textContent;
                copyButton.textContent = "已复制 ✓";
                window.setTimeout(function () { copyButton.textContent = original; }, 1600);
            }).catch(function () {
                window.prompt("请手动复制支付链接：", link);
            });
        });
    }

    if (backLink && !safeUrl(backLink.getAttribute("href"))) {
        backLink.setAttribute("href", "/");
    }

    tick();
    tickTimer = window.setInterval(tick, 1000);
    poll();
}());
