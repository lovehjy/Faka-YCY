<?php
declare(strict_types=1);

return [
    'version' => '1.0.0',
    'name' => 'OKPay免费版',
    'author' => '荔枝',
    'website' => 'https://docs.okaypay.me',
    'description' => 'OKPay（Telegram 钱包）收款免费版，支持 USDT / TRX / CNY，HMAC-SHA256 签名，自动/固定汇率',
    'options' => [
        'USDT' => 'USDT',
        'TRX' => 'TRX',
        'CNY' => 'CNY 人民币',
    ],
    'callback' => [
        //验签过程会把规范化结果写回 Context，以下键名均由 Impl/Signature 产出：
        //okpayfree_trade_no = 报文 data.unique_id（即本站订单号）
        //okpayfree_amount   = 核对快照后折回的人民币金额，交由框架与订单金额精确比对
        //okpayfree_paid     = 仅当验签+币种+金额全部通过才置 '1'
        \App\Consts\Pay::IS_SIGN => true,
        \App\Consts\Pay::IS_STATUS => true,
        \App\Consts\Pay::FIELD_STATUS_KEY => 'okpayfree_paid',
        \App\Consts\Pay::FIELD_STATUS_VALUE => '1',
        \App\Consts\Pay::FIELD_ORDER_KEY => 'okpayfree_trade_no',
        \App\Consts\Pay::FIELD_AMOUNT_KEY => 'okpayfree_amount',
        \App\Consts\Pay::FIELD_RESPONSE => 'ok',
    ],
];
