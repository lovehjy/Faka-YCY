[
  {
    name: "OKPay 对接配置",
    form: [
      {
        title: false,
        name: "okpayfree_explain",
        type: "custom",
        submit: false,
        complete: function (_, dom) {
          dom.html(
            '<div class="alert alert-info mb-4" style="line-height:1.8">' +
            '<b>OKPay 免费版</b>：在 <a href="https://t.me/okpay" target="_blank" rel="noopener">@okpay</a> 机器人申请商户，获取商户ID与Token填入下方。<br>' +
            '回调地址由插件在下单时自动传给 OKPay，<b>无需在 OKPay 侧手工配置</b>；请确保本站回调域名可被公网访问。<br>' +
            'USDT / TRX 通道会按汇率把人民币订单折算为币种金额；填写固定汇率可跳过自动汇率。' +
            '</div>'
          );
        }
      },
      { title: "接口地址", name: "api_url", type: "input", placeholder: "https://api.okaypay.me", default: "https://api.okaypay.me" },
      { title: "商户ID", name: "shop_id", type: "input", placeholder: "OKPay 商户ID（id）" },
      { title: "商户Token", name: "token", type: "password", placeholder: "OKPay 商户Token", tips: "仅用于本地 HMAC-SHA256 签名，不会随请求发送" },
      { title: "订单标题", name: "order_title", type: "input", placeholder: "商品订单:${trade_no}", default: "商品订单:${trade_no}", tips: "${trade_no} 会替换为本站订单号" },
      { title: "支付有效期(分钟)", name: "timeout_minutes", type: "input", placeholder: "10", default: "10", tips: "范围 3-120，仅影响收银台倒计时展示" }
    ]
  },
  {
    name: "汇率设置",
    form: [
      { title: "USDT固定汇率", name: "usdt_rate", type: "input", placeholder: "1 USDT = ? CNY，留空自动获取" },
      { title: "TRX固定汇率", name: "trx_rate", type: "input", placeholder: "1 TRX = ? CNY，留空自动获取" },
      { title: "汇率上浮(%)", name: "rate_markup_percent", type: "input", placeholder: "0", default: "0", tips: "例：2 表示折算出的币种金额上浮 2%，用于覆盖波动与手续费" },
      { title: "汇率缓存(秒)", name: "rate_cache_seconds", type: "input", placeholder: "300", default: "300" },
      { title: "USDT小数位", name: "usdt_decimals", type: "input", placeholder: "2", default: "2", tips: "范围 0-8" },
      { title: "TRX小数位", name: "trx_decimals", type: "input", placeholder: "2", default: "2", tips: "范围 0-8" }
    ]
  },
  {
    name: "高级",
    form: [
      { title: "跳过SSL证书校验", name: "ssl_skip_verify", type: "switch", tips: "默认校验 HTTPS 证书；仅当服务器 CA 证书缺失导致下单失败时才开启" }
    ]
  }
]
