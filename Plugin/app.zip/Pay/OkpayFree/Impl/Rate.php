<?php
declare(strict_types=1);

namespace App\Pay\OkpayFree\Impl;

use App\Util\Http;
use Kernel\Exception\JSONException;

/**
 * 汇率报价：把人民币订单金额折算为 OKPay 通道币种金额。
 *
 * 取率优先级：后台固定汇率 > 自动汇率（主/备双源 + 文件缓存，源全挂时退用过期缓存）。
 * 报价的完整现场（币种、币种金额、人民币金额、所用汇率）会作为快照存入订单，
 * 回调验签时逐项核对，杜绝"低价币种冒充高价币种"之类的金额偷换。
 */
class Rate
{
    private const AUTO_SOURCES = [
        'https://latest.currency-api.pages.dev/v1/currencies/usdt.json',
        'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usdt.json',
    ];

    private const CACHE_FILE = '/runtime/cache/okpayfree-rates.json';

    /**
     * 报价：返回应付币种金额与订单快照
     * @param float $cnyAmount 人民币金额（已含接口手续费）
     * @param string $coin USDT/TRX/CNY
     * @param array $config
     * @return array{amount: string, option: array}
     * @throws JSONException
     */
    public static function quote(float $cnyAmount, string $coin, array $config): array
    {
        if ($cnyAmount <= 0) {
            throw new JSONException('订单金额无效');
        }
        $cny = self::format($cnyAmount, 2);

        if ($coin === 'CNY') {
            return [
                'amount' => $cny,
                'option' => self::snapshot('CNY', $cny, $cny, '1', 'fixed', 0.0),
            ];
        }

        if (!in_array($coin, ['USDT', 'TRX'], true)) {
            throw new JSONException('OKPay 通道编码必须为 USDT / TRX / CNY');
        }

        //固定汇率优先：usdt_rate / trx_rate 均为「1 币种 = ? CNY」
        $fixed = (float)($config[strtolower($coin) . '_rate'] ?? 0);
        if ($fixed > 0) {
            $rate = $fixed;
            $source = 'fixed';
        } else {
            $auto = self::autoRates($config);
            $usdtCny = (float)$auto['usdt_cny'];
            $usdtTrx = (float)$auto['usdt_trx'];
            if ($usdtCny <= 0 || $usdtTrx <= 0) {
                throw new JSONException('汇率数据异常，请稍后再试');
            }
            $rate = $coin === 'USDT' ? $usdtCny : $usdtCny / $usdtTrx;
            $source = (string)$auto['source'];
        }

        $markup = self::clampFloat((float)($config['rate_markup_percent'] ?? 0), -90.0, 500.0);
        $converted = $cnyAmount / $rate * (1 + $markup / 100);

        $decimals = self::clampInt((int)($config[strtolower($coin) . '_decimals'] ?? 2), 0, 8);
        $amount = self::format($converted, $decimals);
        if ((float)$amount <= 0) {
            throw new JSONException("订单金额过小，无法折算为 {$coin}，请调整小数位或换用其他支付方式");
        }

        return [
            'amount' => $amount,
            'option' => self::snapshot($coin, $amount, $cny, self::trimZeros(self::format($rate, 6)), $source, $markup),
        ];
    }

    /**
     * 自动汇率：文件缓存（TTL 内直接用）→ 主/备源拉取 → 过期缓存兜底
     * @param array $config
     * @return array{usdt_cny: string, usdt_trx: string, source: string}
     * @throws JSONException
     */
    private static function autoRates(array $config): array
    {
        $ttl = self::clampInt((int)($config['rate_cache_seconds'] ?? 300), 0, 86400);
        $cacheFile = BASE_PATH . self::CACHE_FILE;

        $cached = null;
        if (is_file($cacheFile)) {
            $decoded = json_decode((string)file_get_contents($cacheFile), true);
            if (is_array($decoded) && (float)($decoded['usdt_cny'] ?? 0) > 0 && (float)($decoded['usdt_trx'] ?? 0) > 0) {
                $cached = $decoded;
                if ($ttl > 0 && time() - (int)($decoded['fetched_at'] ?? 0) <= $ttl) {
                    $cached['source'] = 'cache';
                    return $cached;
                }
            }
        }

        $errors = [];
        foreach (self::AUTO_SOURCES as $url) {
            try {
                $response = Http::make([
                    'timeout' => 10,
                    'connect_timeout' => 5,
                    'headers' => ['User-Agent' => 'acg-faka OkpayFree'],
                ])->get($url);
                $json = json_decode($response->getBody()->getContents(), true);
                $usdt = is_array($json) && is_array($json['usdt'] ?? null) ? $json['usdt'] : null;
                $usdtCny = (float)($usdt['cny'] ?? 0);
                $usdtTrx = (float)($usdt['trx'] ?? 0);
                if ($usdtCny <= 0 || $usdtTrx <= 0) {
                    throw new \RuntimeException('rate payload invalid');
                }
                $rates = [
                    'usdt_cny' => (string)$usdtCny,
                    'usdt_trx' => (string)$usdtTrx,
                    'fetched_at' => time(),
                    'source' => $url,
                ];
                $dir = dirname($cacheFile);
                if (!is_dir($dir)) {
                    @mkdir($dir, 0775, true);
                }
                @file_put_contents($cacheFile, json_encode($rates, JSON_UNESCAPED_SLASHES));
                return $rates;
            } catch (\Throwable $e) {
                $errors[] = $e->getMessage();
            }
        }

        //所有源都失败：过期缓存好过下单失败
        if ($cached !== null) {
            $cached['source'] = 'stale-cache';
            return $cached;
        }

        throw new JSONException('汇率获取失败，请稍后再试或在后台配置固定汇率');
    }

    /**
     * @param string $coin
     * @param string $payAmount
     * @param string $cnyAmount
     * @param string $rate
     * @param string $source
     * @param float $markup
     * @return array
     */
    private static function snapshot(string $coin, string $payAmount, string $cnyAmount, string $rate, string $source, float $markup): array
    {
        return [
            'okpayfree_coin' => $coin,
            'okpayfree_pay_amount' => $payAmount,
            'okpayfree_cny_amount' => $cnyAmount,
            'okpayfree_rate' => $rate,
            'okpayfree_rate_source' => $source,
            'okpayfree_markup_percent' => (string)$markup,
        ];
    }

    /**
     * 四舍五入并定标，输出不带千分位的纯数字串
     * @param float $amount
     * @param int $decimals
     * @return string
     */
    public static function format(float $amount, int $decimals = 2): string
    {
        return number_format(round($amount, $decimals, PHP_ROUND_HALF_UP), $decimals, '.', '');
    }

    /**
     * 去掉小数尾零，仅用于展示（"7.036000" → "7.036"）
     * @param string $amount
     * @return string
     */
    private static function trimZeros(string $amount): string
    {
        return str_contains($amount, '.') ? rtrim(rtrim($amount, '0'), '.') : $amount;
    }

    /**
     * @param int $value
     * @param int $min
     * @param int $max
     * @return int
     */
    private static function clampInt(int $value, int $min, int $max): int
    {
        return max($min, min($max, $value));
    }

    /**
     * @param float $value
     * @param float $min
     * @param float $max
     * @return float
     */
    private static function clampFloat(float $value, float $min, float $max): float
    {
        return max($min, min($max, $value));
    }
}
