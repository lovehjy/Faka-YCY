<?php
declare(strict_types=1);

namespace App\Pay\OkpayFree\Impl;

use App\Entity\PayEntity;
use App\Pay\Base;
use App\Util\Http;
use Kernel\Exception\JSONException;

/**
 * OKPay 下单：报价 → 签名请求 payLink → 校验响应签名 → 渲染本地收银台。
 */
class Pay extends Base implements \App\Pay\Pay
{
    /**
     * @return PayEntity
     * @throws JSONException
     */
    public function trade(): PayEntity
    {
        [$apiUrl, $shopId, $token] = $this->credentials();

        $coin = strtoupper(trim((string)$this->code));
        if (!in_array($coin, ['USDT', 'TRX', 'CNY'], true)) {
            throw new JSONException('OKPay 通道编码必须为 USDT / TRX / CNY');
        }

        $quote = Rate::quote((float)$this->amount, $coin, $this->config);

        $params = Signature::signedRequest([
            'amount' => $quote['amount'],
            'coin' => $coin,
            'unique_id' => $this->tradeNo,
            'name' => $this->orderTitle(),
            'return_url' => $this->returnUrl,
            'callback_url' => $this->callbackUrl,
        ], $shopId, $token);

        try {
            $response = Http::make([
                'timeout' => 15,
                'connect_timeout' => 10,
                'verify' => ((string)($this->config['ssl_skip_verify'] ?? '0')) !== '1',
            ])->post($apiUrl . '/shop/payLink', ['form_params' => $params]);
            $json = json_decode($response->getBody()->getContents(), true);
        } catch (\Throwable $e) {
            $this->log('payLink 请求异常: ' . $e->getMessage());
            throw new JSONException('OKPay 下单失败，请稍后再试');
        }

        if (!is_array($json)) {
            $this->log('payLink 响应不是合法 JSON');
            throw new JSONException('OKPay 响应异常，请稍后再试');
        }
        if ((string)($json['status'] ?? '') !== 'success') {
            $message = mb_substr(strip_tags((string)($json['msg'] ?? '下单失败')), 0, 120);
            $this->log('payLink 下单被拒: ' . json_encode($json, JSON_UNESCAPED_UNICODE));
            throw new JSONException('OKPay: ' . $message);
        }
        if (!Signature::verify($json, $token)) {
            $this->log('payLink 响应验签失败: ' . json_encode($json, JSON_UNESCAPED_UNICODE));
            throw new JSONException('OKPay 响应验签失败，已终止下单');
        }

        $payUrl = (string)($json['data']['pay_url'] ?? '');
        $scheme = strtolower((string)parse_url($payUrl, PHP_URL_SCHEME));
        if ($payUrl === '' || !in_array($scheme, ['http', 'https'], true)) {
            $this->log('payLink 未返回有效 pay_url: ' . json_encode($json, JSON_UNESCAPED_UNICODE));
            throw new JSONException('OKPay 未返回支付链接');
        }

        $option = $quote['option'] + [
            'okpayfree_order_id' => (string)($json['data']['order_id'] ?? ''),
            'okpayfree_return_url' => $this->returnUrl,
            'okpayfree_timeout_minutes' => (string)max(3, min(120, (int)($this->config['timeout_minutes'] ?? 10))),
        ];

        $payEntity = new PayEntity();
        $payEntity->setType(self::TYPE_LOCAL_RENDER);
        $payEntity->setUrl($payUrl);
        $payEntity->setOption($option);
        return $payEntity;
    }

    /**
     * 校验并返回网关凭据
     * @return array{0: string, 1: string, 2: string}
     * @throws JSONException
     */
    private function credentials(): array
    {
        $apiUrl = rtrim(trim((string)($this->config['api_url'] ?? 'https://api.okaypay.me')), '/');
        $shopId = trim((string)($this->config['shop_id'] ?? ''));
        $token = trim((string)($this->config['token'] ?? ''));

        $scheme = strtolower((string)parse_url($apiUrl, PHP_URL_SCHEME));
        if ($apiUrl === '' || !in_array($scheme, ['http', 'https'], true)) {
            throw new JSONException('OKPay 接口地址配置无效');
        }
        if ($shopId === '' || $token === '') {
            throw new JSONException('OKPay 商户ID或Token未配置');
        }
        return [$apiUrl, $shopId, $token];
    }

    /**
     * 订单标题：支持 ${trade_no} 占位，限长 64 字符
     * @return string
     */
    private function orderTitle(): string
    {
        $template = trim((string)($this->config['order_title'] ?? ''));
        if ($template === '') {
            $template = '商品订单:${trade_no}';
        }
        return mb_substr(str_replace('${trade_no}', $this->tradeNo, $template), 0, 64);
    }
}
