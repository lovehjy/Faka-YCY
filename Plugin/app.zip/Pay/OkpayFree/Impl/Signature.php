<?php
declare(strict_types=1);

namespace App\Pay\OkpayFree\Impl;

use App\Consts\Pay as PayConst;
use App\Model\Order;
use App\Model\OrderOption;
use App\Model\UserRecharge;
use Kernel\Util\Context;

/**
 * OKPay HMAC-SHA256 签名协议实现 + 异步回调验签。
 *
 * 协议要点（https://docs.okaypay.me/doc.html）：
 *  1. 剔除 sign，剔除 null/空串（保留 0、"0"、false）
 *  2. 嵌套对象用点号展开：data.order_id=x
 *  3. 布尔转 true/false，其余按原样转字符串（金额不重排格式）
 *  4. 键名按 ASCII 升序排序，key=value 用 & 连接，不做 URL 编码
 *  5. sign = UPPER( HMAC_SHA256( base, token ) )
 */
class Signature implements \App\Pay\Signature
{
    /**
     * 构造待签名串
     * @param array $params
     * @return string
     */
    public static function buildBase(array $params): string
    {
        unset($params['sign']);
        $flat = self::flatten($params);
        ksort($flat, SORT_STRING);
        $pairs = [];
        foreach ($flat as $key => $value) {
            $pairs[] = $key . '=' . $value;
        }
        return implode('&', $pairs);
    }

    /**
     * 计算签名：64 位大写十六进制
     * @param array $params
     * @param string $token
     * @return string
     */
    public static function sign(array $params, string $token): string
    {
        return strtoupper(hash_hmac('sha256', self::buildBase($params), $token));
    }

    /**
     * 补齐公共参数（id/timestamp/nonce）并签名，返回可直接提交的参数
     * @param array $params
     * @param string $shopId
     * @param string $token
     * @return array
     * @throws \Exception random_bytes 不可用时（现代环境不会发生）
     */
    public static function signedRequest(array $params, string $shopId, string $token): array
    {
        $params['id'] = $shopId;
        $params['timestamp'] = time();
        $params['nonce'] = bin2hex(random_bytes(16));
        $params['sign'] = self::sign($params, $token);
        return $params;
    }

    /**
     * 校验报文签名（同步响应与异步回调通用），恒定时间比较
     * @param array $payload
     * @param string $token
     * @return bool
     */
    public static function verify(array $payload, string $token): bool
    {
        $given = $payload['sign'] ?? null;
        if (!is_string($given) || trim($given) === '') {
            return false;
        }
        return hash_equals(self::sign($payload, $token), strtoupper(trim($given)));
    }

    /**
     * 异步回调验签。通过后把规范化字段写回 Context，
     * 供框架按 Info.php 里的声明取订单号 / 金额 / 状态。
     *
     * 安全设计：
     *  - 只认 status=success 且签名有效的报文，商户号能配则必须一致
     *  - 只处理 type=deposit 且 data.status=1 的收款成功通知
     *  - 回调金额是通道币种金额：先与下单时的报价快照核对币种与金额，
     *    对得上才折回人民币交给框架与订单金额精确比对；
     *    快照缺失时不做任何换算直接原样上报——币种金额对不上人民币金额会被框架拒绝（失败关闭）
     *
     * @param array $data
     * @param array $config
     * @return bool
     */
    public function verification(array $data, array $config): bool
    {
        $token = trim((string)($config['token'] ?? ''));
        if ($token === '') {
            return false;
        }

        //报文可能以表单转发，data 是 JSON 字符串；统一为数组后再验签
        if (isset($data['data']) && is_string($data['data'])) {
            $decoded = json_decode($data['data'], true);
            if (is_array($decoded)) {
                $data['data'] = $decoded;
            }
        }

        //非 success 报文不携带签名，也没有处理价值
        if ((string)($data['status'] ?? '') !== 'success') {
            return false;
        }
        if (!self::verify($data, $token)) {
            return false;
        }

        //防商户号串用：报文 id 必须是本店
        $shopId = trim((string)($config['shop_id'] ?? ''));
        if ($shopId !== '' && (string)($data['id'] ?? '') !== $shopId) {
            return false;
        }

        $payload = is_array($data['data'] ?? null) ? $data['data'] : [];

        //只处理收款成功通知；出款(withdraw)等其他类型一律忽略
        if (strtolower(trim((string)($payload['type'] ?? 'deposit'))) !== 'deposit') {
            return false;
        }
        if ((string)($payload['status'] ?? '') !== '1') {
            return false;
        }

        $tradeNo = trim((string)($payload['unique_id'] ?? ''));
        $coin = strtoupper(trim((string)($payload['coin'] ?? '')));
        $paidAmount = trim((string)($payload['amount'] ?? ''));
        if ($tradeNo === '' || $paidAmount === '' || !is_numeric($paidAmount)) {
            return false;
        }

        $cnyAmount = $paidAmount;
        $snapshot = self::snapshot($tradeNo);
        if ($snapshot !== null) {
            if ($coin !== '' && strtoupper((string)$snapshot['okpayfree_coin']) !== $coin) {
                return false;
            }
            if (!self::amountEquals($paidAmount, (string)$snapshot['okpayfree_pay_amount'])) {
                return false;
            }
            $cnyAmount = (string)$snapshot['okpayfree_cny_amount'];
        }

        $data['okpayfree_trade_no'] = $tradeNo;
        $data['okpayfree_amount'] = $cnyAmount;
        $data['okpayfree_paid'] = '1';
        Context::set(PayConst::DAFA, $data);
        return true;
    }

    /**
     * 嵌套数组点号展开，并按协议清洗值
     * @param array $data
     * @param string $prefix
     * @return array
     */
    private static function flatten(array $data, string $prefix = ''): array
    {
        $out = [];
        foreach ($data as $key => $value) {
            $name = $prefix === '' ? (string)$key : $prefix . '.' . $key;
            if (is_array($value)) {
                $out += self::flatten($value, $name);
                continue;
            }
            if ($value === null || $value === '') {
                continue;
            }
            if (is_bool($value)) {
                $value = $value ? 'true' : 'false';
            }
            $out[$name] = (string)$value;
        }
        return $out;
    }

    /**
     * 金额等值比较："14.2" 与 "14.20" 视为相等，精度 8 位
     * @param string $a
     * @param string $b
     * @return bool
     */
    private static function amountEquals(string $a, string $b): bool
    {
        if (!is_numeric($a) || !is_numeric($b)) {
            return false;
        }
        if (function_exists('bccomp')) {
            return bccomp($a, $b, 8) === 0;
        }
        return abs((float)$a - (float)$b) < 0.000001;
    }

    /**
     * 取回下单时的报价快照（商品订单 → OrderOption，充值订单 → UserRecharge.option）
     * @param string $tradeNo
     * @return array|null
     */
    private static function snapshot(string $tradeNo): ?array
    {
        try {
            $order = Order::query()->where('trade_no', $tradeNo)->first(['id']);
            if ($order) {
                $option = OrderOption::get((int)$order->id);
                if (self::validSnapshot($option)) {
                    return $option;
                }
            }
            $recharge = UserRecharge::query()->where('trade_no', $tradeNo)->first(['option']);
            if ($recharge && is_string($recharge->option) && $recharge->option !== '') {
                $option = json_decode($recharge->option, true);
                if (self::validSnapshot($option)) {
                    return $option;
                }
            }
        } catch (\Throwable) {
            //查询异常时退回"无快照"路径：不换算、不放大信任，框架金额比对兜底
        }
        return null;
    }

    /**
     * @param mixed $option
     * @return bool
     */
    private static function validSnapshot(mixed $option): bool
    {
        return is_array($option)
            && isset($option['okpayfree_coin'], $option['okpayfree_pay_amount'], $option['okpayfree_cny_amount']);
    }
}
