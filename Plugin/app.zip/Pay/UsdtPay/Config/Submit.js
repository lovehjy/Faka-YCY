(() => {
    /**
     * USDT-免挂版 多配置表单：一套配置 = 一条链的一个收款钱包 + 该钱包的定价策略。
     * 想收哪条链就建哪套配置，支付接口按通道绑定对应配置。
     * 字段书写注意：name 与 type 必须相邻（服务端用正则扒字段名当写入白名单）。
     */
    const chains = {
        tron: {label: "TRON 波场 —— USDT-TRC20 / TRX", field: "tron_address"},
        evm: {label: "EVM —— Ethereum / BSC / Polygon（USDT / USDC / ETH / BNB）", field: "evm_address"},
        solana: {label: "Solana —— USDT / USDC", field: "sol_address"},
        aptos: {label: "Aptos —— USDT / USDC", field: "apt_address"}
    };
    const current = chains[assign?.chain_type] ? assign.chain_type : "tron";

    const toggleChain = (form, val) => {
        const active = chains[val] ? val : "tron";
        Object.keys(chains).forEach(key => {
            if (key === active) {
                form.show(chains[key].field);
            } else {
                form.hide(chains[key].field);
            }
        });
    };

    const toggleFixedRate = (form, on) => {
        if (on === true || on === 1 || on === "1") {
            form.show("fixed_rate");
        } else {
            form.hide("fixed_rate");
        }
    };

    return [
        {
            name: "钱包与定价",
            form: [
                {
                    title: false,
                    name: "usdt_guide_panel",
                    type: "custom",
                    submit: false,
                    complete: (_, dom) => {
                        dom.html(
                            '<div class="alert alert-info mb-4" style="line-height:1.8">' +
                            '<b>一套配置对应一条链的一个收款钱包。</b><br>' +
                            '选择收款链并填入钱包地址即可；同一 EVM 地址在 Ethereum / BSC / Polygon 三条链上通用。<br>' +
                            '到账检测由「线程管理器」守护进程完成，请确保其已启用；' +
                            '汇率与检测参数的全局默认值在通用插件「USDT-免挂版」的配置里。' +
                            '</div>'
                        );
                    }
                },
                {
                    title: "收款链",
                    name: "chain_type", type: "select",
                    dict: Object.keys(chains).map(key => ({id: key, name: chains[key].label})),
                    default: current,
                    change: toggleChain,
                    complete: (form, val) => toggleChain(form, val || current),
                    tips: "该配置收哪条链的款。支付接口选通道（币种），配置选链和钱包，二者要能对上。"
                },
                {
                    title: "TRON 收款地址",
                    name: "tron_address", type: "input",
                    placeholder: "T 开头的 34 位地址",
                    hide: current !== "tron"
                },
                {
                    title: "EVM 收款地址",
                    name: "evm_address", type: "input",
                    placeholder: "0x 开头的 42 位地址，三条 EVM 链通用",
                    hide: current !== "evm"
                },
                {
                    title: "Solana 收款地址",
                    name: "sol_address", type: "input",
                    placeholder: "Base58 格式的钱包地址",
                    hide: current !== "solana"
                },
                {
                    title: "Aptos 收款地址",
                    name: "apt_address", type: "input",
                    placeholder: "0x 开头的十六进制地址",
                    hide: current !== "aptos"
                },
                {
                    title: "汇率上浮",
                    name: "rate_premium", type: "input",
                    placeholder: "百分比，留空用通用插件的全局值",
                    tips: "在市价折算的基础上让客户多付的百分比，可为负。例：填 2，客户实付币量 ×1.02。"
                },
                {
                    title: "启用固定汇率",
                    name: "fixed_rate_on", type: "switch",
                    text: "启用",
                    change: toggleFixedRate,
                    tips: "只作用于 USDT / USDC 稳定币通道；原生币（TRX/ETH/BNB）始终按市场价折算。"
                },
                {
                    title: "稳定币固定汇率",
                    name: "fixed_rate", type: "input",
                    placeholder: "CNY / 枚，如 7.2",
                    hide: !(assign?.fixed_rate_on == 1)
                },
                {
                    title: "稳定币最低数量",
                    name: "min_stable", type: "input",
                    placeholder: "低于该枚数驳回下单，留空用全局值"
                }
                //通信密钥不在这里配：它只用于插件通知商城这一步的自签自验，两端都是本站，
                //由通用插件自动生成与维护（每站唯一）。老配置里存过的 app_key 依然被验签逻辑认。
            ]
        }
    ];
})()
