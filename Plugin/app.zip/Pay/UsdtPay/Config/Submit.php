<?php
declare (strict_types=1);

/**
 * 静态兜底表单：新内核优先用同目录的 Submit.js（按收款链动态渲染字段），
 * 这份给不认 Submit.js 的老内核用，字段名与 Submit.js 完全一致。
 */
return [
    [
        "title" => "收款链",
        "name" => "chain_type",
        "type" => "select",
        "placeholder" => "该配置收哪条链的款",
        "dict" => [
            ["id" => "tron", "name" => "TRON 波场 —— USDT-TRC20 / TRX"],
            ["id" => "evm", "name" => "EVM —— Ethereum / BSC / Polygon"],
            ["id" => "solana", "name" => "Solana —— USDT / USDC"],
            ["id" => "aptos", "name" => "Aptos —— USDT / USDC"],
        ]
    ],
    [
        "title" => "TRON 收款地址",
        "name" => "tron_address",
        "type" => "input",
        "placeholder" => "T 开头的 34 位地址（收款链为 TRON 时填写）"
    ],
    [
        "title" => "EVM 收款地址",
        "name" => "evm_address",
        "type" => "input",
        "placeholder" => "0x 开头的 42 位地址，三条 EVM 链通用（收款链为 EVM 时填写）"
    ],
    [
        "title" => "Solana 收款地址",
        "name" => "sol_address",
        "type" => "input",
        "placeholder" => "Base58 地址（收款链为 Solana 时填写）"
    ],
    [
        "title" => "Aptos 收款地址",
        "name" => "apt_address",
        "type" => "input",
        "placeholder" => "0x 开头的十六进制地址（收款链为 Aptos 时填写）"
    ],
    [
        "title" => "汇率上浮",
        "name" => "rate_premium",
        "type" => "input",
        "placeholder" => "百分比，留空用通用插件的全局值"
    ],
    [
        "title" => "启用固定汇率",
        "name" => "fixed_rate_on",
        "type" => "switch",
        "text" => "启用",
        "tips" => "只作用于 USDT / USDC 稳定币通道"
    ],
    [
        "title" => "稳定币固定汇率",
        "name" => "fixed_rate",
        "type" => "input",
        "placeholder" => "CNY / 枚，如 7.2"
    ],
    [
        "title" => "稳定币最低数量",
        "name" => "min_stable",
        "type" => "input",
        "placeholder" => "低于该枚数驳回下单，留空用全局值"
    ]
    //通信密钥不在这里配：由通用插件自动生成与维护（每站唯一），
    //老配置里存过的 app_key 依然被验签逻辑认。
];
