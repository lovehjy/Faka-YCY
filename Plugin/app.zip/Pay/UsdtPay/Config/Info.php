<?php
declare (strict_types=1);

/**
 * 通道列表直接取自「USDT免挂版」插件的通道注册表，两边永远不漂移。
 * 插件没装时回落到只有 TRC20-USDT，装上后自动出现全部通道。
 */
$options = [0 => 'USDT · TRC20（TRON 波场）'];
try {
    if (class_exists(\App\Plugin\Usdt\Consts\Channels::class)) {
        $options = \App\Plugin\Usdt\Consts\Channels::options();
    }
} catch (\Throwable $e) {
}

return [
    'version' => '2.0.0',
    'name' => 'USDT-免挂版(接口)',
    'author' => '荔枝',
    'website' => '#',
    'description' => '这个支付扩展需要依赖通用扩展：USDT-免挂版(主程序) 2.0+。支持 TRON / Ethereum / BSC / Polygon / Solana / Aptos 多链的 USDT、USDC 及原生币收款。收款钱包走多配置：想收哪条链就新建哪套配置（选链、填地址），再为对应通道的支付接口绑定该配置。',
    'options' => $options,
    'callback' => [
        \App\Consts\Pay::IS_SIGN => true,
        \App\Consts\Pay::IS_STATUS => true,
        \App\Consts\Pay::FIELD_STATUS_KEY => 'status',
        \App\Consts\Pay::FIELD_STATUS_VALUE => 1,
        \App\Consts\Pay::FIELD_ORDER_KEY => 'trade_no',
        \App\Consts\Pay::FIELD_AMOUNT_KEY => 'amount',
        \App\Consts\Pay::FIELD_RESPONSE => 'success'
    ]
];
