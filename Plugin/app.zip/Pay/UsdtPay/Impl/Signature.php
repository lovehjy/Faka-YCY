<?php
declare(strict_types=1);

namespace App\Pay\UsdtPay\Impl;

use App\Util\Plugin;
use App\Util\Str;

/**
 * Class Signature
 * @package App\Pay\Kvmpay\Impl
 */
class Signature implements \App\Pay\Signature
{

    /**
     * @param mixed $str
     * @param string $local
     * @return bool
     */
    public static function safetyEquals(mixed $str, string $local): bool
    {
        if (!is_string($str) || $str === '') {
            return false;
        }

        return hash_equals($local, $str);
    }



    /**
     * 验签用的通信密钥：优先用本支付接口选中的那套配置，没填就回落到「USDT免挂机」插件的全局配置。
     * 回落是为了让升级前就在用的站点零配置继续工作。
     *
     * 注意：这里能区分的只有验签密钥。下单仍然委托给「USDT免挂机」插件，而那个插件是单实例的
     * （手机App配对、自己的表和队列都在它那边），所以多套配置换不了收款设备。
     *
     * @param array $config
     * @return string
     */
    private static function resolveAppKey(array $config): string
    {
        $key = trim((string)($config['app_key'] ?? ''));
        if ($key !== '') {
            return $key;
        }
        return (string)(Plugin::getConfig("Usdt")['app_key'] ?? '');
    }

    /**
     * @inheritDoc
     */
    public function verification(array $data, array $config): bool
    {
        $appKey = self::resolveAppKey($config);

        //密钥为空时绝不能继续：Str::generateSignature 用空串照样能算出一个签名，
        //而那个签名攻击者自己也能算，等于验签形同虚设。宁可拒收也不放行。
        if ($appKey === '') {
            return false;
        }

        $generateSignature = Str::generateSignature($data, $appKey);
        if (!self::safetyEquals($data['sign'], $generateSignature)) {
            return false;
        }
        return true;
    }

}