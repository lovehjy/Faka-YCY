<?php
declare(strict_types=1);

namespace App\Pay\Xunhupay\Impl;

use App\Entity\PayEntity;
use App\Pay\Base;
use App\Util\Http;
use App\Util\Str;
use GuzzleHttp\Exception\GuzzleException;
use Kernel\Exception\JSONException;

/**
 * Class Pay
 * @package App\Pay\Kvmpay\Impl
 */
class Pay extends Base implements \App\Pay\Pay
{

    /**
     * @return PayEntity
     * @throws JSONException|GuzzleException
     */
    public function trade(): PayEntity
    {

        $appid = $this->config["c{$this->code}_appId"];
        $hashKey = $this->config["c{$this->code}_key"];

        $param = [
            'version' => '1.1',
            'appid' => $appid,
            'trade_order_id' => $this->tradeNo,
            'total_fee' => $this->amount,
            'title' => $this->tradeNo,
            'time' => time(),
            'attach' => $this->code,
            'notify_url' => $this->callbackUrl,
            'return_url' => $this->returnUrl,
            'callback_url' => $this->returnUrl,
            'nonce_str' => Str::generateRandStr(),
            'type' => "WAP",
            'wap_url' => $this->config['domain'],
            'wap_name' => $this->config['shop_name'],
        ];

        $param['hash'] = Signature::generateSignature($param, $hashKey);

        try {
            $request = Http::make()->post('https://api.xunhupay.com/payment/do.html', [
                "form_params" => $param
            ]);

            $contents = $request->getBody()->getContents();
            $json = json_decode($contents, true);

            if ($json['errcode'] != 0) {
                throw new JSONException((string)$json['errmsg']);
            }

            $url = $json['url'];
        } catch (\Exception|\Error $e) {
            throw new JSONException("请求失败");
        }

        $payEntity = new PayEntity();
        $payEntity->setType(self::TYPE_REDIRECT);
        $payEntity->setUrl($url);
        return $payEntity;
    }
}