<?php
declare(strict_types=1);

namespace App\Pay\Xunhupay\Impl;


class Signature implements \App\Pay\Signature
{

    /**
     * @param mixed $str
     * @param string $local
     * @return bool
     */
    public static function safetyEquals(mixed $str, string $local): bool
    {
        if (!is_string($str) || $str === '') {
            return false;
        }

        return hash_equals($local, $str);
    }

    /**
     * 生成签名
     * @param array $data
     * @param string $hashKey
     * @return string
     */
    public static function generateSignature(array $data, string $hashKey): string
    {
        ksort($data);
        reset($data);
        $arg = '';
        foreach ($data as $key => $val) {
            if ($key == 'hash' || is_null($val) || $val === '') {
                continue;
            }
            if ($arg) {
                $arg .= '&';
            }
            $arg .= "{$key}={$val}";
        }
        return md5($arg . $hashKey);
    }

    /**
     * @inheritDoc
     */
    public function verification(array $data, array $config): bool
    {
        $sign = $data['hash'];
        unset($data['hash']);
        $hashKey = $config["c{$data['attach']}_key"];
        $generateSignature = self::generateSignature($data, $hashKey);
        if (!self::safetyEquals($sign, $generateSignature)) {
            return false;
        }
        return true;
    }
}