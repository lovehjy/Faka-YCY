<?php
declare(strict_types=1);

namespace App\Pay\TTpay\Impl;

use Kernel\Util\Context;

/**
 * Class Signature
 * @package App\Pay\Kvmpay\Impl
 */
class Signature implements \App\Pay\Signature
{

    /**
     * @param mixed $str
     * @param string $local
     * @return bool
     */
    public static function safetyEquals(mixed $str, string $local): bool
    {
        if (!is_string($str) || $str === '') {
            return false;
        }

        return hash_equals($local, $str);
    }

    /**
     * 生成签名
     * @param array $data
     * @param string $key
     * @return string
     */
    public static function generateSignature(array $data, string $key): string
    {
        ksort($data);
        $sign = '';
        foreach ($data as $k => $v) {
            $sign .= $k . '=' . $v . '&';
        }
        $sign = trim($sign, '&');
        return strtoupper(md5($sign . "&key=" . $key));
    }

    /**
     * @inheritDoc
     */
    public function verification(array $data, array $config): bool
    {
        $data = (array)json_decode((string)file_get_contents("php://input"));;
        $sign = $data['sign'];
        unset($data['sign']);
        $generateSignature = self::generateSignature($data, $config['key']);
        if (!self::safetyEquals($sign, $generateSignature)) {
            return false;
        }
        $data['order_money'] = (float)sprintf("%.2f", $data['order_money'] / 100);
        Context::set(\App\Consts\Pay::DAFA, $data);
        return true;
    }

}