<?php
declare(strict_types=1);

namespace App\Pay\TTpay\Impl;

use App\Entity\PayEntity;
use App\Pay\Base;
use Kernel\Exception\JSONException;

/**
 * Class Pay
 * @package App\Pay\Kvmpay\Impl
 */
class Pay extends Base implements \App\Pay\Pay
{

    /**
     * @return PayEntity
     * @throws \Kernel\Exception\JSONException|\GuzzleHttp\Exception\GuzzleException
     */
    public function trade(): PayEntity
    {

        if (!$this->config['url']) {
            throw new JSONException("请配置网关地址");
        }

        if (!$this->config['pid']) {
            throw new JSONException("请配置通道号");
        }

        if (!$this->config['key']) {
            throw new JSONException("请配置签名密钥");
        }

        $amount = (int)($this->amount * 100);

        $param = [
            'channel' => $this->config['pid'],
            'type' => $this->code,
            'money' => $amount,
            'orderno' => $this->tradeNo,
            'notifyurl' => $this->callbackUrl
        ];

        $param['sign'] = Signature::generateSignature($param, $this->config['key']);

        try {
            $response = $this->http()->post($this->config['url'] . "/gate/take_order.do", [
                'form_params' => $param
            ]);
            $contents = $response->getBody()->getContents();
            $json = json_decode($contents, true);

            if ($json['result'] != true) {
                throw new JSONException($json['message']);
            }

        } catch (\Error|\Exception $e) {
            throw new JSONException($e->getMessage());
        }
        $payEntity = new PayEntity();
        $payEntity->setType(self::TYPE_LOCAL_RENDER);
        $payEntity->setOption(['returnUrl' => $this->returnUrl]);
        $payEntity->setUrl($json['data']['pay_url']);
        return $payEntity;
    }
}