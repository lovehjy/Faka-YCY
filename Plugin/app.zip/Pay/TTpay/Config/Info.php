<?php
declare (strict_types=1);

return [
    'version' => '1.0.2',
    'name' => '天天PAY',
    'author' => '天天',
    'website' => '#',
    'description' => '暂无说明',
    'options' => [
        'alipay' => '支付宝',
        'alipay_h5' => '支付宝H5',
        'wechat ' => '微信',
        'wechat_qrcode' => '微信扫码',
    ],
    'callback' => [
        \App\Consts\Pay::IS_SIGN => true,
        \App\Consts\Pay::IS_STATUS => false,
        \App\Consts\Pay::FIELD_STATUS_KEY => '',
        \App\Consts\Pay::FIELD_STATUS_VALUE => '',
        \App\Consts\Pay::FIELD_ORDER_KEY => 'orderno',
        \App\Consts\Pay::FIELD_AMOUNT_KEY => 'order_money',
        \App\Consts\Pay::FIELD_RESPONSE => 'success'
    ]
];