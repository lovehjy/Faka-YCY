<?php
declare (strict_types=1);

return [
    [
        "title" => "网关地址",
        "name" => "url",
        "type" => "input",
        "placeholder" => "支付网关地址(如:https://xxx.com，不要带路由)"
    ],
    [
        "title" => "通道号",
        "name" => "pid",
        "type" => "input",
        "placeholder" => "通道号"
    ],
    [
        "title" => "签名密钥",
        "name" => "key",
        "type" => "input",
        "placeholder" => "签名密钥"
    ]
];