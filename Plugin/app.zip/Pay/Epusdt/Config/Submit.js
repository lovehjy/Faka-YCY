(() => {
    /**
     * Epusdt(GMPay) 多配置表单：一套配置 = 一个网关商户（pid + secret_key）。
     * 字段书写注意：name 与 type 必须相邻（服务端用正则扒字段名当写入白名单）。
     */
    return [
        {
            name: "网关与商户",
            form: [
                {
                    title: false,
                    name: "epusdt_guide_panel",
                    type: "custom",
                    submit: false,
                    complete: (_, dom) => {
                        dom.html(
                            '<div class="alert alert-info mb-4" style="line-height:1.8">' +
                            '商户ID(pid)与密钥(secret_key)在网关的 API 密钥管理中获取；2.0.0 之前的 MD5 旧密钥不可用，请先升级网关。<br>' +
                            '回调地址由插件在下单时自动提交给网关，无需在网关侧手工配置；请确保本站回调域名可被网关访问。<br>' +
                            '支付接口的通道决定收款币种：<code>cashier</code> 由付款人在收银台自选，其余为 币种.网络 固定通道（如 <code>usdt.tron</code>）。' +
                            '</div>'
                        );
                    }
                },
                {
                    title: "支付网关",
                    name: "url", type: "input",
                    placeholder: "https://pay.example.com",
                    tips: "Epusdt 网关根地址，须以 http:// 或 https:// 开头，插件会拼接 GMPay 下单接口路径。"
                },
                {
                    title: "商户ID",
                    name: "pid", type: "input",
                    placeholder: "API 密钥对应的商户ID(pid)"
                },
                {
                    title: "商户密钥",
                    name: "key", type: "password",
                    placeholder: "API 密钥(secret_key)",
                    tips: "HMAC-SHA256 签名密钥，泄露即可伪造支付回调，请妥善保管。"
                },
                {
                    title: "计价币种",
                    name: "currency", type: "input",
                    placeholder: "留空默认 cny",
                    tips: "传给网关的法币代码（如 cny / usd），决定网关按哪种法币折算币价，须与本站结算币种一致。"
                }
            ]
        }
    ];
})()
