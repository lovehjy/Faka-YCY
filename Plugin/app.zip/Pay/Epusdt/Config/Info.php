<?php
declare (strict_types=1);

return [
    'version' => '1.0.4',
    'name' => 'Epusdt(GMPay)',
    'author' => '#',
    'website' => 'https://epusdt.com',
    'description' => 'Epusdt(GMPay) 数字货币收款，支持多链 USDT/USDC/TRX/SOL',
    'options' => [
        'cashier' => '收银台自选币种',
        'usdt.tron' => 'TRON-USDT',
        'trx.tron' => 'TRON-TRX',
        'usdt.ethereum' => 'ERC20-USDT',
        'usdc.ethereum' => 'ERC20-USDC',
        'usdt.bsc' => 'BEP20-USDT',
        'usdc.bsc' => 'BEP20-USDC',
        'usdt.polygon' => 'POLYGON-USDT',
        'usdc.polygon' => 'POLYGON-USDC',
        'usdt.solana' => 'SOLANA-USDT',
        'usdc.solana' => 'SOLANA-USDC',
        'sol.solana' => 'SOLANA-SOL',
        'usdt.plasma' => 'PLASMA-USDT',
    ],
    'callback' => [
        \App\Consts\Pay::IS_SIGN => true,
        \App\Consts\Pay::IS_STATUS => true,
        \App\Consts\Pay::FIELD_STATUS_KEY => 'status',
        \App\Consts\Pay::FIELD_STATUS_VALUE => 2,
        \App\Consts\Pay::FIELD_ORDER_KEY => 'order_id',
        \App\Consts\Pay::FIELD_AMOUNT_KEY => 'amount',
        \App\Consts\Pay::FIELD_RESPONSE => 'ok'
    ]
];
