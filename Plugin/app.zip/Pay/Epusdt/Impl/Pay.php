<?php
declare(strict_types=1);

namespace App\Pay\Epusdt\Impl;

use App\Entity\PayEntity;
use App\Pay\Base;
use GuzzleHttp\Exception\GuzzleException;
use Kernel\Exception\JSONException;

/**
 * Epusdt(GMPay) 数字货币支付
 *
 * 对接 /payments/gmpay/v1/order/create-transaction 下单接口：
 * HMAC-SHA256 签名，下单成功后跳转网关收银台，支付结果由异步回调确认。
 *
 * @package App\Pay\Epusdt\Impl
 */
class Pay extends Base implements \App\Pay\Pay
{

    /**
     * GMPay 下单接口路径（v2.0.0+）
     */
    private const CREATE_TRANSACTION = '/payments/gmpay/v1/order/create-transaction';

    /**
     * @return PayEntity
     * @throws JSONException
     */
    public function trade(): PayEntity
    {
        $gateway = rtrim(trim((string)($this->config['url'] ?? '')), '/');
        $pid = trim((string)($this->config['pid'] ?? ''));
        $secretKey = trim((string)($this->config['key'] ?? ''));

        if ($gateway === '' || !preg_match('#^https?://#i', $gateway)) {
            throw new JSONException("请先在支付配置中填写 Epusdt 网关地址（以 http:// 或 https:// 开头）");
        }
        if ($pid === '') {
            throw new JSONException("请先在支付配置中填写商户ID(pid)");
        }
        if ($secretKey === '') {
            throw new JSONException("请先在支付配置中填写商户密钥(secret_key)");
        }

        $param = [
            'pid' => $pid,
            'order_id' => $this->tradeNo,
            'currency' => strtolower(trim((string)($this->config['currency'] ?? ''))) ?: 'cny',
            'amount' => $this->normalizeAmount(),
            'notify_url' => $this->callbackUrl,
            'redirect_url' => $this->returnUrl,
        ];

        //通道编码即 币种.网络（如 usdt.tron）；cashier 表示不指定币种，由付款人在网关收银台自选
        $code = strtolower(trim((string)$this->code));
        if ($code !== '' && $code !== 'cashier') {
            [$token, $network] = array_pad(explode('.', $code, 2), 2, '');
            //接口要求 token 与 network 必须成对出现
            if ($token === '' || $network === '') {
                throw new JSONException("通道编码不合法，应为 币种.网络 格式（如 usdt.tron），或使用 cashier 由付款人自选");
            }
            $param['token'] = $token;
            $param['network'] = $network;
        }

        //空值不参与签名，也不发给网关，保证签过什么就发什么
        $param = array_filter($param, static fn($v) => $v !== null && $v !== '');
        $param['signature'] = Signature::generateSignature($param, $secretKey);

        try {
            $response = $this->http()->post($gateway . self::CREATE_TRANSACTION, [
                'json' => $param,
                'headers' => ['Accept' => 'application/json'],
                //网关不可达时快速失败，别拖死当前进程；业务错误(4xx)不抛异常，读响应里的 message
                'connect_timeout' => 10,
                'timeout' => 20,
                'http_errors' => false,
            ]);
        } catch (GuzzleException $e) {
            $this->log("下单失败，网关连接异常：" . $e->getMessage());
            throw new JSONException("支付网关连接失败，请稍后重试");
        }

        $body = (string)$response->getBody();
        $json = json_decode($body, true);

        if (!is_array($json)) {
            $this->log("下单失败，网关响应不是JSON(HTTP " . $response->getStatusCode() . ")：" . mb_substr($body, 0, 300));
            throw new JSONException("支付网关响应异常，请联系网站管理员");
        }

        if ((int)($json['status_code'] ?? 0) !== 200) {
            $this->log("下单被网关拒绝：" . mb_substr($body, 0, 300));
            $message = trim((string)($json['message'] ?? ''));
            throw new JSONException($message !== '' ? "网关：" . mb_substr($message, 0, 128) : "支付网关下单失败");
        }

        $data = is_array($json['data'] ?? null) ? $json['data'] : [];
        $paymentUrl = trim((string)($data['payment_url'] ?? ''));

        if (!preg_match('#^https?://#i', $paymentUrl)) {
            $this->log("下单成功但网关未返回有效收银台地址：" . mb_substr($body, 0, 300));
            throw new JSONException("支付网关未返回收银台地址，请联系网站管理员");
        }

        $payEntity = new PayEntity();
        $payEntity->setType(self::TYPE_REDIRECT);
        $payEntity->setOption($data);
        $payEntity->setUrl($paymentUrl);
        return $payEntity;
    }

    /**
     * 金额定标到两位小数；整数金额转 int，保证签名串里的字符串表示
     * 与 JSON 报文里的数字字面量完全一致（100 而不是 100.0）。
     * @return int|float
     * @throws JSONException
     */
    private function normalizeAmount(): int|float
    {
        $amount = round($this->amount, 2);
        if ($amount < 0.01) {
            throw new JSONException("支付金额过低，无法发起数字货币支付");
        }
        return floor($amount) == $amount ? (int)$amount : $amount;
    }
}
