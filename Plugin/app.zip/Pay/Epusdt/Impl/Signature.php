<?php
declare(strict_types=1);

namespace App\Pay\Epusdt\Impl;

/**
 * Epusdt(GMPay) HMAC-SHA256 签名
 *
 * 规则（v2.0.0+）：剔除 signature 与空值后，按键名 ASCII 升序拼接 k=v&k=v，
 * 以商户 secret_key 为密钥计算 HMAC-SHA256，结果为 64 位小写十六进制。
 *
 * @package App\Pay\Epusdt\Impl
 */
class Signature implements \App\Pay\Signature
{

    /**
     * 生成签名
     * @param array $data
     * @param string $secretKey
     * @return string
     */
    public static function generateSignature(array $data, string $secretKey): string
    {
        unset($data['signature']);
        ksort($data, SORT_STRING);

        $pairs = [];
        foreach ($data as $k => $v) {
            //空串与 null 不参与签名；数组/布尔没有约定的字符串形态，一并跳过——
            //宁可签名对不上被拒，也不产出歧义签名
            if (!is_scalar($v) || is_bool($v) || $v === '') {
                continue;
            }
            $pairs[] = $k . '=' . $v;
        }

        return hash_hmac('sha256', implode('&', $pairs), $secretKey);
    }

    /**
     * 回调验签
     * @param array $data
     * @param array $config
     * @return bool
     */
    public function verification(array $data, array $config): bool
    {
        //空密钥意味着任何人都能算出合法签名，直接拒绝
        $secretKey = trim((string)($config['key'] ?? ''));
        if ($secretKey === '') {
            return false;
        }

        $sign = $data['signature'] ?? null;
        if (!is_string($sign) || $sign === '') {
            return false;
        }

        //回调携带 pid 时必须与本配置档的商户ID一致，防止同一网关下多商户配置间串单
        $configPid = trim((string)($config['pid'] ?? ''));
        $callbackPid = trim((string)($data['pid'] ?? ''));
        if ($configPid !== '' && $callbackPid !== '' && $callbackPid !== $configPid) {
            return false;
        }

        unset($data['signature']);

        return hash_equals(self::generateSignature($data, $secretKey), strtolower($sign));
    }
}
