<?php require("Header.php"); ?>


    <div class="layout">
        <div class="layout-search">
            <input type="text" placeholder="<?= t('请输入联系方式或订单号进行查询') ?>" class="keywords" value="<?php echo $data['tradeNo']; ?>">
            <button type="button" class="query-btn"><?= t('查询') ?></button>
        </div>
    </div>


    <div class="layout">
        <div class="layout-result">
            <h1 class="notfound"><?= t('未查询到相关订单') ?></h1>
            <div class="order-success">
            </div>
        </div>
    </div>

    </div>
    <script>
        acg.ready("<?php echo $from;?>", () => {
            let instance = $('.keywords');

            function query(keywords) {
                let orderSuccess = $('.order-success');
                $('.notfound').hide();
                orderSuccess.hide();
                orderSuccess.html('');
                acg.API.query({
                    keywords: keywords,
                    success: order => {
                        if (order.commodity && order.pay) {
                            let status = '<span style="color: red;">' + <?= json_encode(t('未支付'), JSON_UNESCAPED_UNICODE) ?> + '</span>';
                            if (order.status === 1) {
                                status = '<span style="color: green;">' + <?= json_encode(t('已支付'), JSON_UNESCAPED_UNICODE) ?> + '</span>';
                            }

                            let race = "";
                            if (order.race) {
                                race = " ( <b style='color: #20b033;'>" + order.race + "</b> )";
                            }

                            let html = '<div class="hr-top">\n' +
                                '                        <div style="font-size: 14px;">' + <?= json_encode(t('订单号：'), JSON_UNESCAPED_UNICODE) ?> + '<b class="trade_no">' + order.trade_no + '</b> <?php hook(\App\Consts\Hook::USER_VIEW_QUERY_TRADE_NO);?></div>\n' +
                                '                        <div style="font-size: 14px;">' + <?= json_encode(t('下单金额：'), JSON_UNESCAPED_UNICODE) ?> + '<b style="color: red;" class="amount">' + order.amount + '</b></div>\n' +
                                '                        <div style="font-size: 14px;">' + <?= json_encode(t('购买数量：'), JSON_UNESCAPED_UNICODE) ?> + '<b style="color: #8e8ef3;" class="buyNum">' + order.card_num + '</b></div>\n' +
                                '                        <div style="font-size: 14px;">' + <?= json_encode(t('下单时间：'), JSON_UNESCAPED_UNICODE) ?> + '<b class="create_time">' + order.create_time + '</b></div>\n' +
                                '                        <div style="font-size: 14px;">' + <?= json_encode(t('商品名称：'), JSON_UNESCAPED_UNICODE) ?> + '<b>' + order.commodity.name + race + '</b></div>\n' +
                                '                        <div style="font-size: 14px;">' + <?= json_encode(t('支付方式：'), JSON_UNESCAPED_UNICODE) ?> + '<b class="icon">' + '<img src="' + order.pay.icon + '" height="16px" style="position: relative;top: 2px;">' + order.pay.name + '</b></div>\n' +
                                '                        <div style="font-size: 14px;">' + <?= json_encode(t('订单状态：'), JSON_UNESCAPED_UNICODE) ?> + '<b class="status">' + status + '</b></div>\n' +
                                '                        <div style="font-size: 14px;' + (order.status == 1 ? '' : 'display: none;') + '" class="payDateView">' + <?= json_encode(t('支付时间：'), JSON_UNESCAPED_UNICODE) ?> + '<b class="pay_date"\n' +
                                '                                                                                                style="color: green;">' + order.pay_time + '</b>\n' +
                                '                        </div>\n' +
                                '                        <div style="font-size: 14px;' + (order.leave_message ? "" : " display: none;") + '">' + <?= json_encode(t('使用说明：'), JSON_UNESCAPED_UNICODE) ?> + '<b>' + order.leave_message + '</b></div>\n' +
                                '                        <div style="font-size: 14px;margin: 5px 0 5px 0;">' + <?= json_encode(t('卡密信息：'), JSON_UNESCAPED_UNICODE) ?> + '<input style="' + (order.commodity.password_status == 1 ? '<?php echo $data['user'] ? 'display:none;' : '';?>' : 'display:none;') + <?= json_encode(t('"  type="text" placeholder="请输入查询密码.." class="query-password passId-'), JSON_UNESCAPED_UNICODE) ?> + order.id + '"> <b class="getCard" data-id="' + order.id + '">' + <?= json_encode(t('查看'), JSON_UNESCAPED_UNICODE) ?> + '</b>' + '</div>' + '\n' +
                                '                        <div style="margin-top: 10px; display: none;" class="cardInfoView-' + order.id + '">\n' +
                                '                            <textarea class="card-textarea cardInfo-' + order.id + '" style="height: 420px;"></textarea>\n' +
                                '                        </div>\n' +
                                '                    </div>';
                            orderSuccess.append(html);
                        }
                    },
                    yes: res => {
                        orderSuccess.show();
                        $('.getCard').click(function () {
                            let orderId = $(this).attr('data-id');
                            acg.API.secret({
                                orderId: orderId,
                                password: $('.passId-' + orderId).val(),
                                success: res => {
                                    let secret = "";
                                    if (res.widget) {
                                        secret += <?= json_encode(t('--------------您隐私内容---------------\n'), JSON_UNESCAPED_UNICODE) ?>;
                                        for (const widgetKey in res.widget) {
                                            secret += res.widget[widgetKey].cn + "：" + res.widget[widgetKey].value + "\n";
                                        }
                                        secret += <?= json_encode(t('--------------卡密信息---------------\n'), JSON_UNESCAPED_UNICODE) ?>;
                                    }
                                    secret += res.secret;
                                    $('.cardInfo-' + orderId).html(secret);
                                    $('.cardInfoView-' + orderId).show(80);
                                }
                            });
                        });
                    },
                    error: () => {
                        $('.notfound').show();
                    }
                });
            }

            $('.query-btn').click(function () {
                query(instance.val());
            });

            <?php if ($data['tradeNo']) {?>
            $('.query-btn').click();
            <?php } elseif ($data['user']){?>
            query("");
            <?php }?>

        });
    </script>
<?php require("Footer.php"); ?>