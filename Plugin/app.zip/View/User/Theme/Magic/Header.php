<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title><?php echo $data["config"]["title"]; ?></title>
    <meta name="keywords" content="<?php echo $data["config"]["keywords"]; ?>"/>
    <meta name="description" content="<?php echo $data["config"]["description"]; ?>"/>
    <link href="<?php echo $data['favicon']; ?>" rel="icon">
    <?php
    echo css([
            "/app/View/User/Theme/Magic/Assets/Css/Style.css",
            "/assets/static/font/font-awesome-4.7.0/css/font-awesome.min.css"
    ]);

    echo js([
            "/assets/static/jquery.min.js",
            //ready.js 必须在 acg.js 之前：它提供语言切换与 i18n()
            "/assets/common/js/ready.js",
            "/assets/static/acg.js"
    ]);
    ?>

    <!--start::HOOK-->
    <?php hook(\App\Consts\Hook::USER_VIEW_INDEX_HEADER); ?>
    <!--end::HOOK-->
</head>
<body>
<div class="card main-window">
    <div class="logo">
        <a href="<?php echo $data['user'] ? '/user/dashboard/index' : '/user/authentication/login?goto=/'; ?>"><img
                    src="<?php echo $data['user'] ? ($data['user']['avatar'] ? $data['user']['avatar'] : $data['favicon']) : $data['favicon']; ?>"></a>
        <div class="username">
            <?php //语言切换：ready.js 认 [data-lang-value] 切换、[data-lang-label] 填当前语言短码、[data-lang-parent] 控制展开 ?>
            <?php //把当前语言喂给前端：ready.js 的切换器靠 getVar("LANG") 标记当前项与短码 ?>
<script>window._data_var=window._data_var||{};window._data_var.LANG="<?php echo \Kernel\Util\Lang::get(); ?>";</script>
<span class="acg-lang" data-lang-parent>
                <a class="acg-lang-toggle" href="javascript:;" title="<?= t('语言') ?>" aria-label="<?= t('切换语言') ?>"><i class="fa fa-globe"></i> <span data-lang-label></span></a>
                <span class="acg-lang-menu">
                    <?php foreach (($data['langs'] ?? []) as $l) { ?>
                        <a href="javascript:;" data-lang-value="<?= $l['code'] ?>"><?= $l['name'] ?></a>
                    <?php } ?>
                </span>
            </span> ·
            <?php if (!$data['user']) { ?>
                <a href="/user/authentication/login?goto=/"><i class="fa fa-sign-in"></i> <?= t('登录') ?></a> · <a
                        href="/user/authentication/register?goto=/"><i class="fa fa-user-plus"></i> <?= t('注册') ?></a>
            <?php } else { ?>
                <a href="/user/dashboard/index"><?= t('欢迎你，') ?><span
                            class="nickname"><?php echo $data['user']['username']; ?><?= t('(余额:') ?><?php echo $data['user']['balance']; ?>)</span></a>
            <?php } ?>
            · <a
                    href="<?php echo getLocalRouter() == '/user/index/query' ? '/' : '/user/index/query'; ?>"> <?php echo getLocalRouter() == '/user/index/query' ? '<i class="fa fa-shopping-cart"></i> ' . t('购买商品') : '<i class="fa fa-safari"></i> ' . t('订单查询'); ?></a> <?php if ($data['config']['service_url']) { ?>·
            <a href="<?php echo $data['config']['service_url']; ?>" target="_blank"><i
                            class="fa fa-paint-brush"></i> <?= t('联系客服') ?></a><?php } ?>

            <?php foreach (hook(\App\Consts\Hook::USER_VIEW_HEADER_NAV) as $item) { ?>
                · <a href="<?php echo $item['url']; ?>" target="<?php echo $item['target']; ?>"><?php echo user_nav_icon($item); ?> <?php echo $item['name']; ?></a>
            <?php } ?>
        </div>
    </div>