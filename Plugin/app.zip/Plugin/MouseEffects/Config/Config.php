<?php
declare (strict_types=1);

return [
    'STATUS' => '0',
    'text' => '',
];