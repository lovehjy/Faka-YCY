<?php
declare(strict_types=1);

namespace App\Plugin\Redis\Hook;

use App\Plugin\Redis\Redis;
use App\Util\Client;
use App\Util\Plugin;
use Kernel\Annotation\Hook;
use Kernel\Exception\JSONException;

class Main
{
    const CACHE_URL = [
        'user/api/index/data',
        'user/api/index/commodity',
        'user/api/index/commodityDetail'
    ];

    /**
     * @return \Redis
     */
    private function getRedis(): \Redis
    {
        return Redis::inst()->getRedis();
    }

    /**
     * @throws \Kernel\Exception\JSONException
     */
    #[\Kernel\Annotation\Plugin(state: \Kernel\Annotation\Plugin::START)]
    public function start(): void
    {
        $config = Plugin::getConfig("Redis");
        if (!$config['host'] || !$config['port']) {
            throw new JSONException("请先配置好，再启动插件哦。");
        }
        try {
            $this->getRedis();
        } catch (\Error|\Exception $e) {
            throw new JSONException("Redis连接失败，请先配置好Redis再启动。");
        }
    }


    #[Hook(point: \App\Consts\Hook::HTTP_ROUTE_RESPONSE)]
    public function routeAccess(string $route, mixed $response): void
    {
        //废弃代码
    }

    #[Hook(point: \App\Consts\Hook::KERNEL_INIT)]
    public function routeCache(): void
    {
       //废弃代码
    }
}