<?php
declare (strict_types=1);

namespace App\Plugin\Redis;

use App\Util\Plugin;
use Kernel\Component\Singleton;

class Redis
{
    use Singleton;

    /**
     * @var \Redis|null
     */
    private ?\Redis $redis = null;


    /**
     * @return \Redis
     */
    public function getRedis(): \Redis
    {
        if (!$this->redis) {
            if (!extension_loaded("redis")) {
                //没装扩展时给出可定位的报错，而不是致命的 Class "Redis" not found
                throw new \RuntimeException("PHP 的 redis 扩展未安装，无法使用 Redis 插件相关功能，请先安装 php-redis 扩展");
            }
            $config = Plugin::getConfig("Redis");
            $redis = new \Redis();
            $redis->connect((string)$config['host'], (int)$config['port']);
            $redis->setOption(\Redis::OPT_SERIALIZER, \Redis::SERIALIZER_PHP);
            if ($config['auth']) {
                $redis->auth($config['auth']);
            }
            $this->redis = $redis;
        }
        return $this->redis;
    }
}