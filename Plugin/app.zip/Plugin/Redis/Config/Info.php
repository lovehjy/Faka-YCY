<?php
declare(strict_types=1);

use App\Consts\Plugin;

return [
    Plugin::NAME => 'Redis-缓存器',
    Plugin::AUTHOR => '荔枝',
    Plugin::WEB_SITE => '#',
    Plugin::DESCRIPTION => 'Redis 基础设施插件，提供给其他插件 Redis API 调用',
    Plugin::VERSION => '1.0.4'
];