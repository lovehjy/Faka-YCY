<?php
declare(strict_types=1);

namespace App\Plugin\ChatwootWidget\Hook;

use App\Controller\Base\View\ManagePlugin;
use Kernel\Annotation\Hook;

class Main extends ManagePlugin
{
    private const PLUGIN_NAME = "ChatwootWidget";

    /**
     * 声明本插件需要放行的 CSP 外部源，不用管理员手动去后台"违规记录"里点允许。
     * Chatwoot 的 SDK 除了加载脚本本身，还会用这同一个域名做实时聊天的 API/WebSocket 连接、
     * 加载头像/图片/文件等附件，所以这几个指令都要放行，只放 script-src 的话脚本能加载
     * 但连不上聊天服务器，气泡会一直转圈。
     */
    #[Hook(point: \App\Consts\Hook::CSP_SOURCE_ALLOW)]
    public function CSP_SOURCE_ALLOW(array &$sources): void
    {
        $config = getPluginConfig(self::PLUGIN_NAME);
        if ((string)($config['enable'] ?? '0') !== '1') {
            return;
        }

        $baseUrl = trim((string)($config['base_url'] ?? ''));
        if ($baseUrl === '') {
            return;
        }

        $sources['script-src'][] = $baseUrl;
        $sources['connect-src'][] = $baseUrl;
        $sources['img-src'][] = $baseUrl;
        $sources['media-src'][] = $baseUrl;
        $sources['frame-src'][] = $baseUrl;
        $sources['style-src'][] = $baseUrl;
    }

    /**
     * 全站前台页面注入 Chatwoot 客服 SDK
     */
    #[Hook(point: \App\Consts\Hook::USER_GLOBAL_VIEW_FOOTER)]
    public function footer(): string
    {
        $config = getPluginConfig(self::PLUGIN_NAME);
        if ((string)($config['enable'] ?? '0') !== '1') {
            return '';
        }

        $baseUrl = trim((string)($config['base_url'] ?? ''));
        $token = trim((string)($config['website_token'] ?? ''));
        if ($baseUrl === '' || $token === '') {
            // 关键信息没填全，不输出，避免报 JS 错误
            return '';
        }

        $position = (string)($config['position'] ?? 'right') === 'left' ? 'left' : 'right';
        $type = (string)($config['type'] ?? 'expanded_bubble') === 'standard' ? 'standard' : 'expanded_bubble';
        $launcherTitle = (string)($config['launcher_title'] ?? '联系我们');

        // 用 json_encode 而不是手动拼字符串，避免 token/文案里出现引号等特殊字符把 JS 弄坏
        $settingsJson = json_encode([
            'position' => $position,
            'type' => $type,
            'launcherTitle' => $launcherTitle,
        ], JSON_UNESCAPED_UNICODE);
        $baseUrlJson = json_encode($baseUrl, JSON_UNESCAPED_SLASHES);
        $tokenJson = json_encode($token);

        return <<<HTML
<script>
  window.chatwootSettings = {$settingsJson};
  (function(d,t) {
    var BASE_URL={$baseUrlJson};
    var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
    g.src=BASE_URL+"/packs/js/sdk.js";
    g.async = true;
    s.parentNode.insertBefore(g,s);
    g.onload=function(){
      window.chatwootSDK.run({
        websiteToken: {$tokenJson},
        baseUrl: BASE_URL
      })
    }
  })(document,"script");
</script>
HTML;
    }
}
