<?php
declare(strict_types=1);

return [
    [
        "title" => "启用客服窗口",
        "name" => "enable",
        "type" => "switch",
        "text" => "启用"
    ],
    [
        "title" => "Chatwoot 地址",
        "name" => "base_url",
        "type" => "input",
        "placeholder" => "你的 Chatwoot 服务地址，如 https://chat.dengnaer.com"
    ],
    [
        "title" => "Website Token",
        "name" => "website_token",
        "type" => "input",
        "placeholder" => "在 Chatwoot 后台『收件箱设置』里能找到"
    ],
    [
        "title" => "悬浮位置",
        "name" => "position",
        "type" => "input",
        "placeholder" => "填 left 或 right，默认 right"
    ],
    [
        "title" => "气泡样式",
        "name" => "type",
        "type" => "input",
        "placeholder" => "填 standard 或 expanded_bubble，默认 expanded_bubble"
    ],
    [
        "title" => "气泡文案",
        "name" => "launcher_title",
        "type" => "input",
        "placeholder" => "鼠标悬浮气泡上显示的文字，默认『联系我们』"
    ]
];
