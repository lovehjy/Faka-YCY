<?php
declare(strict_types=1);

use App\Consts\Plugin;

return [
    Plugin::NAME => 'Chatwoot在线客服',
    Plugin::AUTHOR => '性情',
    Plugin::WEB_SITE => '#',
    Plugin::DESCRIPTION => '在全站前台页面注入 Chatwoot 客服悬浮窗，Token、位置、气泡文案均可在后台配置，无需修改主题模板文件。',
    Plugin::VERSION => '1.0.1'
];
