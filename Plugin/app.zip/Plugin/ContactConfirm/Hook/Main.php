<?php
declare(strict_types=1);

namespace App\Plugin\ContactConfirm\Hook;

use App\Controller\Base\View\ManagePlugin;
use Kernel\Annotation\Hook;

/**
 * 不同主题用的"页脚注入点"命名不统一：Tokyo/Cartoon 走 USER_GLOBAL_VIEW_FOOTER（同时也会
 * 触发 USER_VIEW_INDEX_FOOTER），MountFuji 走 USER_VIEW_FOOTER，Dream（纯PHP模板，非Smarty）
 * 走 USER_VIEW_INDEX_FOOTER。只订阅一种钩子会导致部分主题完全不生效。
 *
 * 关键点：纯 PHP 模板的主题里，模板对 hook() 是裸调用（<?php hook(...); ?>，没有 echo），
 * 返回值会被直接丢弃——所以这里必须用 echo 直接输出，不能 return，否则在这类主题下就是哑的。
 * Smarty 模板（.html，用 #{hook(...)} 语法）虽然会自动打印返回值，但这里改成 echo 之后，
 * 内容已经在 echo 那一刻正确输出了，多余的 return null 对 Smarty 只是打印个空字符串，无害。
 *
 * 三个钩子都订阅，同一页面可能被注入多次（Tokyo/Cartoon 会同时触发两种钩子），
 * 靠 confirm.js 自身的 window.__ccInited 幂等判断兜底，不会重复初始化。
 */
class Main extends ManagePlugin
{
    private const PLUGIN_NAME = "ContactConfirm";

    #[Hook(point: \App\Consts\Hook::USER_GLOBAL_VIEW_FOOTER)]
    public function globalFooter(): void
    {
        $this->output();
    }

    #[Hook(point: \App\Consts\Hook::USER_VIEW_FOOTER)]
    public function viewFooter(): void
    {
        $this->output();
    }

    #[Hook(point: \App\Consts\Hook::USER_VIEW_INDEX_FOOTER)]
    public function viewIndexFooter(): void
    {
        $this->output();
    }

    private function output(): void
    {
        $config = getPluginConfig(self::PLUGIN_NAME);
        if ((string)($config['enable'] ?? '0') !== '1') {
            return;
        }

        echo <<<'HTML'
<link rel="stylesheet" href="/app/Plugin/ContactConfirm/Assets/confirm.css">
<script src="/app/Plugin/ContactConfirm/Assets/confirm.js"></script>
HTML;
    }
}
