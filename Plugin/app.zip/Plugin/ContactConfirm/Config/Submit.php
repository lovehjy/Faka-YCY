<?php
declare(strict_types=1);

return [
    [
        "title" => "启用",
        "name" => "enable",
        "type" => "switch",
        "text" => "启用"
    ],
    [
        "title" => "说明",
        "name" => "explain_note",
        "type" => "explain",
        "placeholder" => "启用后，商品购买页填写联系方式失焦时会自动清理空格并弹窗展示结果，方便核对。这只是提示，不会阻止用户继续下单/付款。"
    ]
];
