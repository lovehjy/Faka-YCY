<?php
declare(strict_types=1);

use App\Consts\Plugin;

return [
    Plugin::NAME => '联系方式二次确认',
    Plugin::AUTHOR => '性情',
    Plugin::WEB_SITE => '#',
    Plugin::DESCRIPTION => '自动清理联系方式中的空格并弹窗展示结果，方便客户核对。',
    Plugin::VERSION => '1.0.0'
];
