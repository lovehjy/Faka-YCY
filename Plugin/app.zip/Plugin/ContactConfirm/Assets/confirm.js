(function () {
    'use strict';

    // 同一页面可能被多个钩子重复注入这个脚本文件（Tokyo/Cartoon 主题的页脚会同时触发两种钩子），
    // 靠这个全局标记确保初始化逻辑只真正跑一次，重复的 <script> 标签第二次进来直接跳过
    if (window.__ccInited) { return; }
    window.__ccInited = true;

    var lastShownValue = null; // 避免同一个值反复弹窗打扰用户

    function cleanContact(raw) {
        // 去掉所有空格（包括中间的、首尾的），联系方式里出现空格基本都是误触，
        // 不只是 trim 首尾——中间多打的空格同样会导致邮箱/QQ/手机号变成无效值
        return String(raw || '').replace(/\s+/g, '');
    }

    function getContactInput() {
        return document.querySelector('input[name="contact"]');
    }

    function showResultModal(cleanedValue, input) {
        var overlay = document.createElement('div');
        overlay.className = 'cc-overlay';

        var card = document.createElement('div');
        card.className = 'cc-card';

        var title = document.createElement('div');
        title.className = 'cc-title';
        title.textContent = '联系方式已自动清理';

        var desc = document.createElement('div');
        desc.className = 'cc-desc';
        desc.textContent = '卡密/发货信息将发送到这里，请核对：';

        var valueBox = document.createElement('div');
        valueBox.className = 'cc-value';
        valueBox.textContent = cleanedValue || '（空）';

        var btnRow = document.createElement('div');
        btnRow.className = 'cc-btn-row';

        var editBtn = document.createElement('button');
        editBtn.type = 'button';
        editBtn.className = 'cc-btn cc-btn-ghost';
        editBtn.textContent = '再改改';

        var okBtn = document.createElement('button');
        okBtn.type = 'button';
        okBtn.className = 'cc-btn cc-btn-primary';
        okBtn.textContent = '知道了';

        btnRow.appendChild(editBtn);
        btnRow.appendChild(okBtn);
        card.appendChild(title);
        card.appendChild(desc);
        card.appendChild(valueBox);
        card.appendChild(btnRow);
        overlay.appendChild(card);
        document.body.appendChild(overlay);

        function close() {
            if (overlay.parentNode) {
                overlay.parentNode.removeChild(overlay);
            }
        }

        editBtn.addEventListener('click', function () {
            close();
            input.focus();
        });
        okBtn.addEventListener('click', close);
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) { close(); }
        });
    }

    // 失焦时清理空格并弹窗展示结果，纯提示性质，不拦截、不阻止后续任何操作
    document.addEventListener('blur', function (e) {
        var input = getContactInput();
        if (!input || e.target !== input) { return; }

        var cleaned = cleanContact(input.value);
        if (input.value !== cleaned) {
            input.value = cleaned;
        }
        if (cleaned === '' || cleaned === lastShownValue) { return; }

        lastShownValue = cleaned;
        showResultModal(cleaned, input);
    }, true);
})();
