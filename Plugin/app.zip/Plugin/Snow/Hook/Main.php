<?php

declare(strict_types=1);

namespace App\Plugin\Snow\Hook;

use App\Controller\Base\View\UserPlugin;
use Kernel\Annotation\Hook;

class Main extends UserPlugin
{
    #[Hook(point: \App\Consts\Hook::USER_VIEW_INDEX_HEADER)]
    public function header()
    {
        echo '<script type="text/javascript" src="' . Plugin('Snow', 'View/snow.js') . '"></script>';
    }
}