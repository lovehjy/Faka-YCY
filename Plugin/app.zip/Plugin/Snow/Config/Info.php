<?php
declare(strict_types=1);

use App\Consts\Plugin;

return [
    Plugin::NAME => '首页下雪',
    Plugin::AUTHOR => '小七',
    Plugin::WEB_SITE => '#',
    Plugin::DESCRIPTION => '开启本插件可以让你的首页开始下雪',
    Plugin::VERSION => '1.0.0'
];