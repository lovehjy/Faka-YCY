<?php
declare (strict_types=1);

return [
    [
        "title" => "HTML",
        "name" => "html",
        "type" => "html",
        "placeholder" => "请输入第三方加载代码(HTML)"
    ]
];