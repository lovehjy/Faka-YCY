(function () {
    'use strict';

    if (window.__orderEnhancerLoaded || typeof Table === 'undefined' || !window.jQuery) return;
    window.__orderEnhancerLoaded = true;

    const $ = window.jQuery;
    const pluginBase = '/plugin/OrderEnhancer/api/order/';
    const endpointMap = {
        '/admin/api/order/data': pluginBase + 'data',
        '/admin/api/order/save': pluginBase + 'deliver',
        '/admin/api/order/exportImpact': pluginBase + 'exportImpact',
        '/admin/api/order/export': pluginBase + 'export'
    };

    $.ajaxPrefilter(function (options) {
        const source = String(options.url || '');
        const path = source.split('?')[0];
        if (endpointMap[path]) {
            options.url = endpointMap[path] + source.slice(path.length);
        }
    });

    // 新版订单导出使用原生 fetch；仅映射四个明确的订单接口，不影响其他请求。
    const nativeFetch = window.fetch.bind(window);
    window.fetch = function (input, init) {
        if (typeof input === 'string') {
            const url = new URL(input, window.location.origin);
            if (url.origin === window.location.origin && endpointMap[url.pathname]) {
                input = endpointMap[url.pathname] + url.search + url.hash;
            }
        }
        return nativeFetch(input, init);
    };

    const originalSetColumns = Table.prototype.setColumns;
    Table.prototype.setColumns = function (columns) {
        if (this.$table && this.$table.is('#order-table') && Array.isArray(columns)) {
            const skuColumnIndex = columns.findIndex(column => column && column.field === 'sku');
            const secretColumnIndex = columns.findIndex(column => column && column.field === 'secret');
            if (skuColumnIndex !== -1 && secretColumnIndex !== -1 && skuColumnIndex < secretColumnIndex) {
                [columns[skuColumnIndex], columns[secretColumnIndex]] = [columns[secretColumnIndex], columns[skuColumnIndex]];
            }

            const secretColumn = columns.find(column => column && column.field === 'secret');
            if (secretColumn && Array.isArray(secretColumn.buttons)) {
                const editButton = secretColumn.buttons.find(button =>
                    button && (button.title === '手动发货' || button.title === '编辑并下发')
                );
                if (editButton) {
                    editButton.title = '编辑并下发';
                    editButton.show = row => Number(row && row.status) === 1;
                }
            }
        }
        return originalSetColumns.apply(this, arguments);
    };

    const originalSetSearch = Table.prototype.setSearch;
    Table.prototype.setSearch = function (items) {
        if (this.$table && this.$table.is('#order-table') && Array.isArray(items)) {
            const oldNames = ['equal-trade_no', 'search-trade_no', 'equal-contact', 'search-contact', 'search-secret'];
            let inserted = items.some(item => item && item.name === 'search-keyword');
            const enhanced = [];
            items.forEach(item => {
                if (!item || !oldNames.includes(item.name)) {
                    enhanced.push(item);
                    return;
                }
                if (!inserted) {
                    enhanced.push({
                        title: '综合查询：订单号/联系方式/卡密',
                        name: 'search-keyword',
                        type: 'input'
                    });
                    inserted = true;
                }
            });
            arguments[0] = enhanced;
        }
        return originalSetSearch.apply(this, arguments);
    };

}());
