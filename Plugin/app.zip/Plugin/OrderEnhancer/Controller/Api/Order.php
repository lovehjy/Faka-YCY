<?php
declare(strict_types=1);

namespace App\Plugin\OrderEnhancer\Controller\Api;

use App\Controller\Base\API\ManagePlugin;
use App\Controller\Admin\Api\Order as CoreOrder;
use App\Interceptor\ManageSession;
use App\Model\ManageLog;
use Illuminate\Database\Capsule\Manager as DB;
use Illuminate\Database\Eloquent\Builder;
use Kernel\Annotation\Interceptor;
use Kernel\Container\Di;
use Kernel\Exception\JSONException;
use Kernel\Waf\Filter;

/**
 * 复用当前系统订单控制器，仅叠加跨字段综合搜索条件。
 * 统计、关联数据、导出格式和后续版本逻辑全部由系统原生接口处理。
 */
#[Interceptor(ManageSession::class, Interceptor::TYPE_API)]
class Order extends ManagePlugin
{
    private const SEARCH_SCOPE = 'order_enhancer_keyword';

    private function requirePost(): void
    {
        if (strtoupper($this->request->method()) !== 'POST') {
            throw new JSONException('请求方式不正确');
        }
    }

    private function keyword(array $post): string
    {
        $value = $post['search-keyword'] ?? '';
        if (!is_scalar($value) && $value !== null) {
            throw new JSONException('综合查询参数格式不正确');
        }

        $keyword = trim((string)$value);
        if (mb_strlen($keyword) > 255) {
            throw new JSONException('综合查询内容过长');
        }
        return $keyword;
    }

    private function withKeywordScope(callable $callback): mixed
    {
        $this->requirePost();
        $post = (array)$this->request->post();
        $keyword = $this->keyword($post);
        unset($post['search-keyword']);
        unset($_POST['search-keyword']);
        $this->request->setProperty('post', $post);

        if ($keyword !== '') {
            $like = '%' . addcslashes($keyword, '\\%_') . '%';
            \App\Model\Order::addGlobalScope(self::SEARCH_SCOPE, static function (Builder $builder) use ($like): void {
                $builder->where(static function (Builder $query) use ($like): void {
                    $query->where('trade_no', 'like', $like)
                        ->orWhere('contact', 'like', $like)
                        ->orWhere('secret', 'like', $like);
                });
            });
        }

        return $callback();
    }

    private function core(): CoreOrder
    {
        $controller = new CoreOrder();
        Di::instance()->inject($controller);
        return $controller;
    }

    public function data(): array
    {
        return $this->withKeywordScope(fn(): array => $this->core()->data());
    }

    public function deliver(): array
    {
        $this->requirePost();
        $map = $this->request->post(flags: Filter::NORMAL);
        $id = filter_var($map['id'] ?? null, FILTER_VALIDATE_INT);
        if ($id === false || $id < 1) {
            throw new JSONException('订单 ID 不正确，请刷新后重试');
        }

        if (isset($map['secret']) && !is_scalar($map['secret'])) {
            throw new JSONException('发货内容格式不正确');
        }
        $secret = (string)($map['secret'] ?? '');
        $normalizedSecret = trim($secret);
        if ($normalizedSecret === '' || $normalizedSecret === '0') {
            throw new JSONException('请填写有效的发货内容，不能仅为空白或“0”');
        }
        if (mb_strlen($secret) > 65535 || strlen($secret) > 65535) {
            throw new JSONException('发货内容过长');
        }

        $overwriteConfirmed = filter_var(
            $map['overwrite_confirmed'] ?? false,
            FILTER_VALIDATE_BOOLEAN,
            FILTER_NULL_ON_FAILURE
        ) === true;

        [$order, $overwrote] = DB::transaction(function () use ($id, $secret, $overwriteConfirmed): array {
            $order = \App\Model\Order::query()->where('id', $id)->lockForUpdate()->first();
            if (!$order) {
                throw new JSONException('订单不存在，请刷新后重试');
            }
            if ((int)$order->status !== 1) {
                throw new JSONException('仅已支付订单可以修改发货内容');
            }

            $commodity = \App\Model\Commodity::query()
                ->where('id', (int)$order->commodity_id)
                ->first(['id', 'delivery_way']);
            if (!$commodity || !in_array((int)$commodity->delivery_way, [0, 1], true)) {
                throw new JSONException('订单商品或发货方式无效');
            }

            $hasExisting = (int)$order->delivery_status === 1
                || trim((string)$order->secret) !== '';
            if ($hasExisting && !$overwriteConfirmed) {
                throw new JSONException('此订单已有发货记录，请明确确认覆盖后重试');
            }

            $order->secret = $secret;
            $order->delivery_status = 1;
            if (!$order->save()) {
                throw new JSONException('发货信息保存失败，请重试');
            }
            return [$order, $hasExisting];
        });

        try {
            hook(\App\Consts\Hook::ORDER_MANUAL_DELIVERY_AFTER, $order, $overwrote);
        } catch (\Throwable) {
        }

        ManageLog::log($this->getManage(), "[订单增强]({$id})编辑并下发了卡密");
        return $this->json(200, '发货信息已保存');
    }

    public function exportImpact(): array
    {
        return $this->withKeywordScope(fn(): array => $this->core()->exportImpact());
    }

    public function export(): string
    {
        return $this->withKeywordScope(fn(): string => $this->core()->export());
    }
}
