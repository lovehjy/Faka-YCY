<?php
declare(strict_types=1);

namespace App\Plugin\OrderEnhancer\Hook;

use App\Consts\Hook;
use Kernel\Annotation\Hook as HookPoint;

class Order
{
    #[HookPoint(point: Hook::ADMIN_VIEW_ORDER_FOOTER)]
    public function footer(): string
    {
        return ready(Plugin('OrderEnhancer', 'Assets/order-enhancer.js') . '?rev=10600');
    }
}
