<?php
declare(strict_types=1);

use App\Consts\Plugin;

return [
    Plugin::NAME => '订单增强',
    Plugin::AUTHOR => '同同',
    Plugin::WEB_SITE => '',
    Plugin::DESCRIPTION => '自动发货卡密可编辑下发，订单综合模糊查询与列表列位置优化。',
    Plugin::VERSION => '1.0.0',
];
