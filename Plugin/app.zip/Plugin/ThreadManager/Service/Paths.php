<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Service;

final class Paths
{
    public const NAME = 'ThreadManager';

    private static ?string $runtimeOverride = null;

    public static function setRuntimeOverride(?string $dir): void
    {
        self::$runtimeOverride = $dir === null ? null : rtrim($dir, '/') . '/';
    }

    public static function base(): string
    {
        if (defined('BASE_PATH')) {
            return rtrim((string)constant('BASE_PATH'), '/') . '/';
        }

        return dirname(__DIR__, 4) . '/';
    }

    public static function plugin(): string
    {
        return dirname(__DIR__) . '/';
    }

    public static function runtime(): string
    {
        $dir = self::$runtimeOverride ?? (self::base() . 'runtime/plugin/' . self::NAME . '/');
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        return $dir;
    }

    public static function status(): string { return self::runtime() . 'status.json'; }

    public static function registry(): string { return self::runtime() . 'registry.json'; }

    public static function daemonLock(): string { return self::runtime() . 'daemon.lock'; }

    public static function reloadSentinel(): string { return self::runtime() . 'reload'; }

    public static function commands(): string
    {
        $dir = self::runtime() . 'commands/';
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
        return $dir;
    }

    public static function log(): string { return self::plugin() . 'runtime.log'; }

    public static function daemon(): string { return self::plugin() . 'Bin/Daemon.php'; }

    public static function binary(?string $configured = null): string
    {
        $configured = trim((string)$configured);
        if ($configured !== '') {
            return $configured;
        }
        return self::plugin() . 'swoole-cli';
    }
}
