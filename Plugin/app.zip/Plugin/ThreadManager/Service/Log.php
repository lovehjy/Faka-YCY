<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Service;

final class Log
{
    public const DEBUG = 10;
    public const INFO  = 20;
    public const WARN  = 30;
    public const ERROR = 40;

    private const NAMES = [
        self::DEBUG => 'DEBUG',
        self::INFO  => 'INFO',
        self::WARN  => 'WARN',
        self::ERROR => 'ERROR',
    ];

    private const MAX_BYTES = 8 * 1024 * 1024;

    private static int $level = self::INFO;
    private static string $scope = 'daemon';
    private static bool $echo = false;

    public static function configure(int $level = self::INFO, string $scope = 'daemon', bool $echo = false): void
    {
        self::$level = $level;
        self::$scope = $scope;
        self::$echo = $echo;
    }

    public static function levelFromName(string $name): int
    {
        return match (strtolower(trim($name))) {
            'debug' => self::DEBUG,
            'warn', 'warning' => self::WARN,
            'error' => self::ERROR,
            default => self::INFO,
        };
    }

    public static function debug(string $msg, array $ctx = []): void { self::write(self::DEBUG, $msg, $ctx); }
    public static function info(string $msg, array $ctx = []): void  { self::write(self::INFO, $msg, $ctx); }
    public static function warn(string $msg, array $ctx = []): void  { self::write(self::WARN, $msg, $ctx); }
    public static function error(string $msg, array $ctx = []): void { self::write(self::ERROR, $msg, $ctx); }

    public static function exception(\Throwable $e, string $prefix = ''): void
    {
        self::write(self::ERROR, trim($prefix . ' ' . get_class($e) . ': ' . $e->getMessage()), [
            'file' => $e->getFile() . ':' . $e->getLine(),
            'trace' => self::shortTrace($e),
        ]);
    }

    public static function shortTrace(\Throwable $e, int $frames = 8): string
    {
        $lines = explode("\n", $e->getTraceAsString());
        return implode("\n", array_slice($lines, 0, $frames));
    }

    private static function write(int $level, string $msg, array $ctx = []): void
    {
        if ($level < self::$level) {
            return;
        }

        $line = sprintf(
            "[%s][%s][%s] %s%s\n",
            date('Y-m-d H:i:s'),
            self::NAMES[$level] ?? '?',
            self::$scope,
            str_replace(["\r", "\n"], ' ', $msg),
            $ctx === [] ? '' : ' ' . json_encode($ctx, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );

        $file = Paths::log();
        self::rotate($file);
        @file_put_contents($file, $line, FILE_APPEND);

        if (self::$echo) {
            fwrite($level >= self::WARN ? STDERR : STDOUT, $line);
        }
    }

    private static function rotate(string $file): void
    {
        if (!is_file($file) || filesize($file) < self::MAX_BYTES) {
            return;
        }

        @rename($file, $file . '.1');
    }

    public static function tail(int $lines = 300, string $level = '', string $scope = ''): array
    {
        $file = Paths::log();
        if (!is_file($file)) {
            return [];
        }

        $size = filesize($file);
        $read = min($size, max(64 * 1024, $lines * 220));
        $fp = @fopen($file, 'rb');
        if (!$fp) {
            return [];
        }
        fseek($fp, -$read, SEEK_END);
        $buf = (string)fread($fp, $read);
        fclose($fp);

        $all = array_values(array_filter(explode("\n", $buf), static fn($l) => trim($l) !== ''));

        if ($size > $read && $all !== []) {
            array_shift($all);
        }

        $level = strtoupper(trim($level));
        $scope = trim($scope);
        if ($level !== '' || $scope !== '') {
            $all = array_values(array_filter($all, static function (string $l) use ($level, $scope): bool {
                if ($level !== '' && !str_contains($l, "][{$level}][")) {
                    return false;
                }
                return $scope === '' || str_contains($l, "][{$scope}]");
            }));
        }

        return array_slice($all, -$lines);
    }
}
