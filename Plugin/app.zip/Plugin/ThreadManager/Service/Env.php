<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Service;

/**
 * 运行环境探测。
 *
 * 守护进程本体对 systemd 没有任何依赖（Type=simple，就是个前台进程），
 * 但「谁在它退出后把它拉起来」这件事各环境不一样：
 * 裸机是 systemd、容器是 Docker 的重启策略、容器里跑第二个进程时可能压根没人管。
 * 面板要据此换文案，守护进程要据此决定 restart-daemon 该不该承诺「会自动回来」。
 */
final class Env
{
    /**
     * systemd 是不是真的在跑。
     *
     * 只看 `command -v systemctl` 是不够的：容器里装了 systemd 包但用别的 init
     * 启动时 systemctl 存在却一调就报 "System has not been booted with systemd"。
     * /run/systemd/system 只有 systemd 作为 init 跑起来后才存在，这是官方推荐的判据。
     */
    public static function hasSystemd(): bool
    {
        return is_dir('/run/systemd/system');
    }

    public static function inContainer(): bool
    {
        if (is_file('/.dockerenv') || is_file('/run/.containerenv')) {
            return true;
        }

        foreach (['/proc/1/cgroup', '/proc/self/cgroup'] as $f) {
            $raw = @file_get_contents($f);
            if (is_string($raw) && preg_match('#(docker|containerd|kubepods|lxc|podman|garden)#i', $raw) === 1) {
                return true;
            }
        }

        //cgroup v2 的容器里 /proc/1/cgroup 只有一行 "0::/"，认不出来。
        //退而求其次：PID 1 不是 init/systemd 基本可以断定不在裸机上。
        $comm = @file_get_contents('/proc/1/comm');
        if (is_string($comm)) {
            $comm = trim($comm);
            if ($comm !== '' && !in_array($comm, ['init', 'systemd'], true)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 安装模式：systemd 走 unit，其余一律走脚本自带的前台/后台模式。
     */
    public static function installMode(): string
    {
        return self::hasSystemd() ? 'systemd' : 'container';
    }

    /**
     * 守护进程退出后会不会被自动拉起。
     *
     * 三态：yes 有人管、no 没人管、unknown 判断不了（比如容器里挂了 supervisord/s6，
     * 从进程内部看不出来）。unknown 一律按「不敢保证」措辞，别让站长按完按钮干等。
     */
    public static function restartPolicy(): string
    {
        if (self::hasSystemd()) {
            return 'yes';
        }
        //自己就是容器 1 号进程 → 退出即容器退出，Docker 的 restart 策略接管。
        if (getmypid() === 1) {
            return 'yes';
        }
        //由 supervisord 拉起的进程会带上这几个环境变量（官方镜像的 entrypoint 会把
        //守护进程注册成 supervisord 程序）。有它就说明退出后一定会被重新拉起。
        if (getenv('SUPERVISOR_ENABLED') === '1' || getenv('SUPERVISOR_PROCESS_NAME') !== false) {
            return 'yes';
        }
        return self::inContainer() ? 'unknown' : 'no';
    }

    /**
     * restart-daemon / drain 回给面板的措辞。
     */
    public static function restartHint(): string
    {
        return match (self::restartPolicy()) {
            'yes' => match (true) {
                self::hasSystemd() => '守护进程将优雅退出，systemd 会自动拉起',
                getenv('SUPERVISOR_ENABLED') === '1' => '守护进程将优雅退出，supervisord 会自动拉起',
                default => '守护进程将优雅退出，容器会按重启策略拉起',
            },
            'unknown' => '守护进程将优雅退出；容器内若没有 supervisord / s6 之类的守护者，需要重新执行 service.sh start',
            default => '守护进程将优雅退出；当前环境没有进程守护者，需要手动执行 service.sh start',
        };
    }

    /**
     * 给面板看的环境快照。
     */
    public static function snapshot(): array
    {
        return [
            'systemd' => self::hasSystemd(),
            'container' => self::inContainer(),
            'install_mode' => self::installMode(),
            'restart_policy' => self::restartPolicy(),
        ];
    }
}
