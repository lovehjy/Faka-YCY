<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Service;

use App\Util\Http;

final class Binary
{
    public const NAME = 'swoole-cli';

    public static function hashFile(): string
    {
        return Paths::plugin() . 'swoole-cli.sha256';
    }

    public static function installedHashFile(): string
    {
        return Paths::runtime() . 'swoole-cli.sha256';
    }

    public static function expectedHash(): string
    {
        foreach ([self::installedHashFile(), self::hashFile()] as $f) {
            $h = self::readHashFile($f);
            if ($h !== '') {
                return $h;
            }
        }
        return '';
    }

    private static function readHashFile(string $f): string
    {
        if (!is_file($f)) {
            return '';
        }

        $line = trim((string)@file_get_contents($f));
        $hash = strtolower((string)strtok($line, " \t\n"));
        return preg_match('/^[0-9a-f]{64}$/', $hash) === 1 ? $hash : '';
    }

    public static function defaultSource(): ?array
    {
        $tag = 'v6.1.7.0';
        $ver = 'v6.1.7';
        $hashes = [
            'x64'   => '8cedfd58d36f26dbcf9988bc89ae85efcaf6cd8cf2cdd492370236cdd55e8161',
            'arm64' => 'd60b85c5d453b803eb13c552c8a935b80809448aefc13d69d36efee744c13dfb',
        ];

        $arch = match (php_uname('m')) {
            'x86_64', 'amd64' => 'x64',
            'aarch64', 'arm64' => 'arm64',
            default => null,
        };
        if ($arch === null || stripos(PHP_OS, 'Linux') === false) {
            return null;
        }

        return [
            'url' => "https://github.com/swoole/swoole-cli/releases/download/{$tag}/swoole-cli-{$ver}-linux-{$arch}.tar.xz",
            'sha256' => $hashes[$arch],
            'version' => $ver,
            'arch' => $arch,
        ];
    }

    public static function status(?string $configured = null): array
    {
        $path = Paths::binary($configured);
        $exists = is_file($path);

        $r = [
            'path' => $path,
            'exists' => $exists,
            'executable' => $exists && is_executable($path),
            'size' => $exists ? (int)filesize($path) : 0,
            'mtime' => $exists ? (int)filemtime($path) : 0,
            'perms' => $exists ? substr(sprintf('%o', fileperms($path)), -4) : '',
            'elf' => false,
            'expected_sha256' => self::expectedHash(),
            'problem' => '',
        ];

        if (!$exists) {
            $r['problem'] = '二进制不存在，在服务器上执行 ./service.sh install 即可自动下载安装';
            return $r;
        }

        $r['elf'] = self::looksLikeLinuxElf($path);
        if (!$r['elf']) {
            $r['problem'] = '这个文件不是 Linux ELF 可执行文件';
        } elseif (!$r['executable']) {

            $r['problem'] = '缺少可执行权限（chmod +x），systemd 会报 203/EXEC';
        }

        return $r;
    }

    public static function looksLikeLinuxElf(string $path): bool
    {
        $fp = @fopen($path, 'rb');
        if ($fp === false) {
            return false;
        }
        $magic = (string)fread($fp, 5);
        fclose($fp);

        return strncmp($magic, "\x7fELF", 4) === 0 && isset($magic[4]) && ord($magic[4]) === 2;
    }

    public static function ensureExecutable(?string $configured = null): bool
    {
        $path = Paths::binary($configured);
        if (!is_file($path)) {
            return false;
        }
        if (is_executable($path)) {
            return true;
        }
        @chmod($path, 0755);
        clearstatcache(true, $path);
        return is_executable($path);
    }

    public static function verify(?string $configured = null): array
    {
        $path = Paths::binary($configured);
        if (!is_file($path)) {
            return ['ok' => false, 'reason' => '二进制不存在', 'sha256' => '', 'expected' => self::expectedHash()];
        }

        $actual = strtolower((string)hash_file('sha256', $path));
        $expected = self::expectedHash();

        if ($expected === '') {
            return ['ok' => true, 'reason' => '插件里没有记录期望的 sha256，跳过比对', 'sha256' => $actual, 'expected' => ''];
        }
        if (!hash_equals($expected, $actual)) {
            return [
                'ok' => false,
                'reason' => 'sha256 与插件记录的不一致。如果这个二进制是你自己换的，属正常；否则请重新下载。',
                'sha256' => $actual,
                'expected' => $expected,
            ];
        }
        return ['ok' => true, 'reason' => '与插件记录的 sha256 一致', 'sha256' => $actual, 'expected' => $expected];
    }

    public static function download(string $url, string $sha256 = '', ?string $configured = null): array
    {
        $url = trim($url);
        if ($url === '') {
            return ['ok' => false, 'message' => '没有填下载地址'];
        }
        if (!preg_match('#^https://#i', $url)) {

            return ['ok' => false, 'message' => '只允许 https 地址'];
        }

        if (preg_match('#\.(tar\.(xz|gz)|tgz|zip)$#i', $url)) {
            return ['ok' => false, 'message' => '这是压缩包地址，请在服务器上执行 ./service.sh install 安装（PHP 侧解不了 xz）'];
        }

        $expected = strtolower(trim($sha256)) ?: self::expectedHash();
        if (!preg_match('/^[0-9a-f]{64}$/', $expected)) {
            return ['ok' => false, 'message' => '缺少 sha256，拒绝下载未经校验的可执行文件'];
        }

        $path = Paths::binary($configured);
        $part = $path . '.part';
        @unlink($part);

        try {

            Http::make()->request('GET', $url, [
                'sink' => $part,
                'timeout' => 1800,
                'connect_timeout' => 15,
                'headers' => ['User-Agent' => 'acg-faka ThreadManager'],
            ]);
        } catch (\Throwable $e) {
            @unlink($part);
            return ['ok' => false, 'message' => '下载失败：' . $e->getMessage()];
        }

        if (!is_file($part) || filesize($part) < 1024 * 1024) {
            @unlink($part);
            return ['ok' => false, 'message' => '下载到的文件太小，多半是拿到了一个错误页'];
        }

        $actual = strtolower((string)hash_file('sha256', $part));
        if (!hash_equals($expected, $actual)) {
            @unlink($part);
            return ['ok' => false, 'message' => "sha256 校验失败，已丢弃。期望 {$expected}，实际 {$actual}"];
        }
        if (!self::looksLikeLinuxElf($part)) {
            @unlink($part);
            return ['ok' => false, 'message' => '下载到的不是 Linux ELF 可执行文件'];
        }

        if (!@rename($part, $path)) {
            @unlink($part);
            return ['ok' => false, 'message' => '无法写入 ' . $path . '，请检查目录权限'];
        }
        @chmod($path, 0755);

        return ['ok' => true, 'message' => '下载并校验通过', 'sha256' => $actual, 'size' => filesize($path)];
    }
}
