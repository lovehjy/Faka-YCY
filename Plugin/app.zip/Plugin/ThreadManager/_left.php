<?php
$n = 0;
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator('app/Plugin/ThreadManager', FilesystemIterator::SKIP_DOTS));
foreach ($it as $f) {
    if (!$f->isFile() || $f->getExtension() !== 'php') continue;
    foreach (token_get_all(file_get_contents($f->getPathname())) as $t) {
        if (is_array($t) && ($t[0] === T_COMMENT || $t[0] === T_DOC_COMMENT)) $n++;
    }
}
echo "PHP 残留注释 token: {$n}\n";
