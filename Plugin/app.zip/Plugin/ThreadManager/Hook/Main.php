<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Hook;

use App\Plugin\ThreadManager\Service\Binary;
use App\Plugin\ThreadManager\Service\Log;
use App\Plugin\ThreadManager\Service\Paths;
use Kernel\Annotation\Hook;

class Main
{

    #[Hook(point: \App\Consts\Hook::ADMIN_VIEW_MENU)]
    public function ADMIN_VIEW_MENU(): void
    {
        try {
            $active = getLocalRouter() == "/plugin/ThreadManager/panel/index" ? "active" : "";
            $title = lang("线程管理器", "tpl");
            echo <<<HTML
<div class="menu-item">
    <a class="menu-link {$active}" href="/plugin/ThreadManager/panel/index">
        <span class="menu-icon"><span class="svg-icon svg-icon-2"><i class="fa-duotone fa-regular fa-diagram-project"></i></span></span>
        <span class="menu-title">{$title}</span>
    </a>
</div>
HTML;
        } catch (\Throwable $e) {
        }
    }

    #[\Kernel\Annotation\Plugin(state: \Kernel\Annotation\Plugin::INSTALL)]
    public function install(): void
    {
        $this->bootstrap();
    }

    #[\Kernel\Annotation\Plugin(state: \Kernel\Annotation\Plugin::START)]
    public function start(): void
    {
        $this->bootstrap();
    }

    private function bootstrap(): void
    {
        try {
            Paths::runtime();
            Paths::commands();

            Binary::ensureExecutable();
            $sh = Paths::plugin() . 'service.sh';
            if (is_file($sh) && !is_executable($sh)) {
                @chmod($sh, 0755);
            }

            Log::configure(Log::INFO, 'plugin');
            Log::info('插件已启用');
        } catch (\Throwable $e) {
        }
    }

    #[\Kernel\Annotation\Plugin(state: \Kernel\Annotation\Plugin::STOP)]
    public function stop(): void
    {
        try {
            $file = Paths::commands() . 'stop-' . bin2hex(random_bytes(8)) . '.json';
            @file_put_contents($file, json_encode([
                'ts' => time(),
                'op' => 'drain',
                'actor' => 'plugin:stop',
            ], JSON_UNESCAPED_UNICODE));
            Log::configure(Log::INFO, 'plugin');
            Log::info('插件已停用，已下发 drain');
        } catch (\Throwable $e) {
        }
    }

    #[\Kernel\Annotation\Plugin(state: \Kernel\Annotation\Plugin::UNINSTALL)]
    public function uninstall(): void
    {
        try {
            $dir = Paths::runtime();
            foreach (glob($dir . '{,.}*', GLOB_BRACE) ?: [] as $item) {
                if (is_file($item)) {
                    @unlink($item);
                }
            }
            foreach (glob($dir . 'commands/*.json') ?: [] as $item) {
                @unlink($item);
            }
        } catch (\Throwable $e) {
        }
    }
}
