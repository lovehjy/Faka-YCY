<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime;

use App\Plugin\ThreadManager\Runtime\Database\Pool as DbPool;
use App\Plugin\ThreadManager\Runtime\Redis\Pool as RedisPool;
use App\Plugin\ThreadManager\Service\Log;
use App\Plugin\ThreadManager\Supervisor\Shared\SharedState;
use App\Plugin\ThreadManager\Task\Invoker;
use App\Plugin\ThreadManager\Task\Registry;
use App\Plugin\ThreadManager\Task\TaskSpec;

final class WorkerEntry
{

    public static function runTask(
        string $specJson,
        int $replica,
        int $bornGeneration,
        ?SharedState $shared,
        int $maxIterations = 0,
        bool $echoToStdout = false,
    ): string {
        $spec = TaskSpec::fromJson($specJson);
        $taskId = $spec->replicaId($replica);

        self::prepareChild();
        Log::configure(Log::INFO, $taskId, $echoToStdout);

        $report = static function (array $st) use ($shared, $taskId, $spec, $replica, $bornGeneration): void {
            if ($shared === null) {
                return;
            }
            $st['gen'] = $bornGeneration;
            $st['task'] = $spec->id();
            $st['replica'] = $replica;
            $shared->putTaskState($taskId, $st);
        };

        $localIterations = 0;
        $stopped = false;
        $shouldRun = static function () use ($shared, $bornGeneration, $maxIterations, &$localIterations, &$stopped): bool {
            if ($stopped) {
                return false;
            }
            if ($shared !== null) {
                if (!$shared->running()) {
                    return false;
                }
                if ($shared->generation() !== $bornGeneration) {
                    return false;
                }
            }
            if ($maxIterations > 0 && $localIterations >= $maxIterations) {
                return false;
            }
            return true;
        };

        if (function_exists('pcntl_signal')) {
            pcntl_signal(SIGTERM, static function () use (&$stopped): void { $stopped = true; });
        }

        Hooks::enable();

        $exitReason = Runner::EXIT_ERROR;
        $runner = null;

        try {
            Bootstrap::boot($spec->boot, $taskId);
            Log::info('任务进程启动', [
                'pid' => getmypid(),
                'mode' => $spec->mode,
                'boot' => $spec->boot,
                'interval' => $spec->interval,
                'gen' => $bornGeneration,
                'hook' => Hooks::current(),
            ]);
            $report(['state' => 'running', 'ts' => microtime(true), 'iter' => 0, 'err' => null]);

            $invoker = new Invoker($spec);
            $invoker->prepare();

            $runner = new Runner(
                $spec,
                $replica,
                $invoker,
                static function () use ($shouldRun, &$localIterations, &$runner): bool {

                    if (function_exists('pcntl_signal_dispatch')) {
                        pcntl_signal_dispatch();
                    }
                    $localIterations = $runner?->iterations() ?? $localIterations;
                    return $shouldRun();
                },
                $report
            );

            if ($spec->boot !== TaskSpec::BOOT_NONE && class_exists('Swoole\Coroutine')) {
                $tmCfg = [];
                try {
                    $tmCfg = \App\Util\Plugin::getConfig('ThreadManager', false);
                } catch (\Throwable $e) {
                }
                $poolOpt = [
                    'min' => (int)($tmCfg['pool_min'] ?? 1),
                    'max' => (int)($tmCfg['pool_max'] ?? 6),
                ];

                DbPool::install($poolOpt);
                RedisPool::install($poolOpt);

                \Swoole\Coroutine\run(static function () use ($runner, $shouldRun, &$exitReason): void {
                    DbPool::start($shouldRun);
                    RedisPool::start($shouldRun);
                    $exitReason = $runner->run();
                });

                DbPool::shutdown();
                RedisPool::shutdown();
            } else {
                $exitReason = $runner->run();
            }
            Log::info('任务进程结束', ['reason' => $exitReason, 'iterations' => $runner->iterations()]);
        } catch (\Throwable $e) {
            $exitReason = Runner::EXIT_ERROR;
            Log::exception($e, '[worker]');
            $report([
                'state' => 'failed',
                'ts' => microtime(true),
                'iter' => $runner?->iterations() ?? 0,
                'err' => get_class($e) . ': ' . $e->getMessage(),
            ]);
            if ($echoToStdout) {
                fwrite(STDERR, get_class($e) . ': ' . $e->getMessage() . "\n");
            }
        }

        $report([
            'state' => 'exited',
            'ts' => microtime(true),
            'iter' => $runner?->iterations() ?? 0,
            'exit' => $exitReason,
            'err' => $runner?->lastError(),
        ]);

        $shared?->pushEvent([
            'ts' => microtime(true),
            'task' => $taskId,
            'exit' => $exitReason,
            'err' => $runner?->lastError(),
        ]);

        if ($echoToStdout) {
            echo "exit={$exitReason} iterations=" . ($runner?->iterations() ?? 0) . "\n";
        }

        return $exitReason;
    }

    public static function runRegistry(bool $echoToStdout = false): array
    {
        self::prepareChild();
        Log::configure(Log::INFO, 'registry', $echoToStdout);
        Bootstrap::boot(Bootstrap::LEVEL_FULL, 'registry');
        return Registry::collectAndWrite();
    }

    private static function prepareChild(): void
    {
        if (function_exists('pcntl_signal')) {
            foreach ([SIGTERM, SIGINT, SIGHUP] as $sig) {
                @pcntl_signal($sig, SIG_DFL);
            }
            @pcntl_signal(SIGPIPE, SIG_IGN);

            if (function_exists('pcntl_async_signals')) {
                pcntl_async_signals(false);
            }
        }
    }
}
