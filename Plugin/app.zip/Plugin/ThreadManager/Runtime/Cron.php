<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime;

final class Cron
{

    private array $sets = [];

    private const RANGES = [
        [0, 59],
        [0, 23],
        [1, 31],
        [1, 12],
        [0, 6],
    ];

    public function __construct(string $expr)
    {
        $parts = preg_split('/\s+/', trim($expr)) ?: [];
        if (count($parts) !== 5) {
            throw new \InvalidArgumentException("cron 必须是 5 段：{$expr}");
        }
        foreach ($parts as $i => $p) {
            $this->sets[$i] = $this->parseField((string)$p, self::RANGES[$i][0], self::RANGES[$i][1], $i === 4);
        }
    }

    private function parseField(string $field, int $min, int $max, bool $isDow): array
    {
        $out = [];
        foreach (explode(',', $field) as $chunk) {
            $chunk = trim($chunk);
            if ($chunk === '') {
                throw new \InvalidArgumentException("cron 段为空");
            }

            $step = 1;
            if (str_contains($chunk, '/')) {
                [$chunk, $stepRaw] = explode('/', $chunk, 2);
                $step = (int)$stepRaw;
                if ($step < 1) {
                    throw new \InvalidArgumentException("cron 步长非法：{$stepRaw}");
                }
            }

            if ($chunk === '*' || $chunk === '') {
                $lo = $min;
                $hi = $max;
            } elseif (str_contains($chunk, '-')) {
                [$a, $b] = explode('-', $chunk, 2);
                $lo = (int)$a;
                $hi = (int)$b;
            } else {
                $lo = $hi = (int)$chunk;
            }

            if ($isDow) {

                $lo = $lo === 7 ? 0 : $lo;
                $hi = $hi === 7 ? 0 : $hi;
                if ($hi < $lo) { $hi = $lo; }
            }

            if ($lo < $min || $hi > $max || $hi < $lo) {
                throw new \InvalidArgumentException("cron 段越界：{$chunk}（允许 {$min}-{$max}）");
            }
            for ($v = $lo; $v <= $hi; $v += $step) {
                $out[$v] = $v;
            }
        }
        ksort($out);
        return $out;
    }

    public function nextAfter(int $after): int
    {
        $t = ($after - ($after % 60)) + 60;
        $limit = $after + 366 * 4 * 86400;

        while ($t <= $limit) {
            [$min, $hour, $day, $mon, $dow] = array_map('intval', explode(' ', date('i G j n w', $t)));

            if (isset($this->sets[0][$min], $this->sets[1][$hour], $this->sets[3][$mon])
                && $this->dayMatches($day, $dow)) {
                return $t;
            }
            $t += 60;
        }

        return $limit;
    }

    private function dayMatches(int $day, int $dow): bool
    {
        $dayRestricted = count($this->sets[2]) !== 31;
        $dowRestricted = count($this->sets[4]) !== 7;

        if (!$dayRestricted && !$dowRestricted) {
            return true;
        }
        if ($dayRestricted && $dowRestricted) {
            return isset($this->sets[2][$day]) || isset($this->sets[4][$dow]);
        }
        if ($dayRestricted) {
            return isset($this->sets[2][$day]);
        }
        return isset($this->sets[4][$dow]);
    }
}
