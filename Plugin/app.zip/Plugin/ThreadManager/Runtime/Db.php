<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime;

use App\Plugin\ThreadManager\Service\Log;
use Illuminate\Database\Capsule\Manager as Capsule;

final class Db
{
    private static ?Capsule $capsule = null;
    private static array $config = [];

    public static function connect(): Capsule
    {
        if (self::$capsule !== null) {
            return self::$capsule;
        }

        $cfg = config('database');
        if (!is_array($cfg) || $cfg === []) {
            throw new \RuntimeException('config/database.php 为空，无法初始化数据库');
        }

        $cfg['options'] = ($cfg['options'] ?? []) + [
            \PDO::ATTR_PERSISTENT => false,
            \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
        ];
        self::$config = $cfg;

        $capsule = new Capsule();
        $capsule->addConnection($cfg);
        $capsule->setAsGlobal();
        $capsule->bootEloquent();
        self::$capsule = $capsule;

        return $capsule;
    }

    public static function capsule(): ?Capsule { return self::$capsule; }

    public static function config(): array { return self::$config; }

    public static function healthy(): bool
    {
        if (self::$capsule === null) {
            return false;
        }
        try {
            Capsule::connection()->getPdo()->query('/*tm-ping*/ SELECT 1');
            return true;
        } catch (\Throwable $e) {
            Log::warn('数据库连接失效，重连中：' . $e->getMessage());
            try {
                Capsule::connection()->disconnect();
                Capsule::connection()->reconnect();
                return true;
            } catch (\Throwable $e2) {
                Log::error('数据库重连失败：' . $e2->getMessage());
                return false;
            }
        }
    }

    public static function serverVar(string $name, ?int $default = null): ?int
    {
        try {
            $row = Capsule::connection()->select("select @@{$name} as v");
            $v = $row[0]->v ?? null;
            return $v === null ? $default : (int)$v;
        } catch (\Throwable $e) {
            return $default;
        }
    }

    public static function disconnect(): void
    {
        try {
            self::$capsule?->getConnection()->disconnect();
        } catch (\Throwable $e) {
        }
    }
}
