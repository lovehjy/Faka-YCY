<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime;

use App\Plugin\ThreadManager\Service\Log;
use Kernel\Consts\Base;
use Kernel\Util\Context;

final class Bootstrap
{
    public const LEVEL_NONE = 'none';
    public const LEVEL_DB = 'db';
    public const LEVEL_FULL = 'full';

    private static bool $booted = false;
    private static bool $storeLoaded = false;
    private static string $level = self::LEVEL_NONE;

    public static function level(): string { return self::$level; }

    public static function boot(string $level, string $scope = 'thread'): void
    {
        if (!self::$booted) {
            self::$booted = true;

            date_default_timezone_set('Asia/Shanghai');
            Guard::install($scope);

            self::seedSuperglobals($scope);
            self::defineConstants();
            self::seedContext($scope);
        }

        if ($level === self::LEVEL_NONE) {
            self::$level = self::LEVEL_NONE;
            return;
        }

        Db::connect();
        self::$level = self::LEVEL_DB;

        if ($level !== self::LEVEL_FULL) {
            return;
        }

        self::loadStore();
        self::$level = self::LEVEL_FULL;
    }

    public static function seedSuperglobals(string $scope = 'thread'): void
    {
        $host = 'localhost';
        try {
            $u = (string)(config('app')['url'] ?? '');
            if ($u !== '' && ($h = parse_url($u, PHP_URL_HOST)) !== null) {
                $host = (string)$h;
            }
        } catch (\Throwable $e) {
        }

        $_GET = ['s' => '/console/thread/' . str_replace([':', '#'], '/', $scope)];
        $_POST = [];
        $_COOKIE = [];
        $_FILES = [];
        $_REQUEST = [];
        $_SERVER['REQUEST_METHOD'] = 'CLI';
        $_SERVER['HTTP_HOST'] = $host;
        $_SERVER['SERVER_NAME'] = $host;
        $_SERVER['REQUEST_SCHEME'] = 'http';
        $_SERVER['SERVER_PORT'] = '80';
        $_SERVER['REMOTE_ADDR'] = '127.0.0.1';
        $_SERVER['REQUEST_URI'] = '/console/thread';
        $_SERVER['HTTP_USER_AGENT'] = 'ThreadManager/1.0';
        $_SERVER['HTTP_ACCEPT_LANGUAGE'] = 'zh-CN';
    }

    private static function defineConstants(): void
    {
        if (!defined('BASE_APP_SERVER')) {
            define('BASE_APP_SERVER', match ((int)(config('store')['server'] ?? 0)) {
                1 => \App\Service\App::STANDBY_SERVER1,
                2 => \App\Service\App::STANDBY_SERVER2,
                3 => \App\Service\App::GENERAL_SERVER,
                default => \App\Service\App::MAIN_SERVER,
            });
        }
        if (!defined('APP_VERSION')) {
            define('APP_VERSION', (string)(config('app')['version'] ?? '0.0.0'));
        }
    }

    private static function seedContext(string $scope): void
    {

        Context::set(Base::LOCK, (string)@file_get_contents(BASE_PATH . 'kernel/Install/Lock'));
        Context::set(Base::IS_INSTALL, file_exists(BASE_PATH . 'kernel/Install/Lock'));
        Context::set(Base::OPCACHE, extension_loaded('Zend OPcache'));
        Context::set(Base::STORE_STATUS, file_exists(BASE_PATH . 'kernel/Plugin.php'));

        Context::set(Base::ROUTE, '/console/thread/' . str_replace([':', '#'], '/', $scope));

        Context::set(Base::LANGUAGE, \Kernel\Util\Lang::SOURCE);
        \Kernel\Util\Lang::reset(\Kernel\Util\Lang::SOURCE);
    }

    private static function loadStore(): void
    {
        if (self::$storeLoaded) {
            return;
        }
        if (!Context::get(Base::STORE_STATUS) || !Context::get(Base::IS_INSTALL)) {
            Log::warn('插件商店层不可用，降级为 db 级');
            return;
        }
        self::$storeLoaded = true;

        if (!defined('_APP_STORE_LOAD_STATE')) {
            require(BASE_PATH . 'kernel/Plugin.php');
        }

        \Kernel\Plugin\Hook::inst()->load();

        $pruned = self::pruneHooks();

        Context::set(\Kernel\Context\Interface\Request::class, new \Kernel\Context\Request());

        Log::info('插件商店层就绪', [
            'points' => count(\Kernel\Util\Plugin::$container['hook'] ?? []),
            'pruned' => $pruned,
        ]);

    }

    private static function pruneHooks(): int
    {
        $container = \Kernel\Util\Plugin::$container['hook'] ?? [];
        if ($container === []) {
            return 0;
        }

        $deny = [];
        try {
            foreach ((new \ReflectionClass(\App\Consts\Hook::class))->getConstants() as $name => $value) {
                if (preg_match('/_VIEW_|^RENDER_VIEW$|^KERNEL_INIT$|^HTTP_ROUTE_RESPONSE$|^CONTROLLER_CALL_|^WAF_INTERCEPT$|^HACK_/', $name)) {
                    $deny[(int)$value] = $name;
                }
            }
        } catch (\Throwable $e) {
            return 0;
        }

        $removed = 0;
        foreach (array_keys($deny) as $point) {
            if (isset($container[$point])) {
                $removed += count($container[$point]);
                unset($container[$point]);
            }
        }
        \Kernel\Util\Plugin::$container['hook'] = $container;
        return $removed;
    }

    public static function betweenIterations(string $scope = 'thread'): void
    {
        StateReset::run();
        self::seedSuperglobals($scope);

        if (self::$level !== self::LEVEL_NONE) {
            Db::healthy();
        }

        if (self::$storeLoaded) {
            try {
                Context::set(\Kernel\Context\Interface\Request::class, new \Kernel\Context\Request());
            } catch (\Throwable $e) {
                Log::warn('重建 Request 失败：' . $e->getMessage());
            }
        }
    }
}
