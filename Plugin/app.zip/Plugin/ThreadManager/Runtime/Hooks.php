<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime;

final class Hooks
{

    public const FLAGS = SWOOLE_HOOK_TCP | SWOOLE_HOOK_UNIX | SWOOLE_HOOK_UDP | SWOOLE_HOOK_UDG
        | SWOOLE_HOOK_SSL | SWOOLE_HOOK_TLS | SWOOLE_HOOK_SLEEP
        | SWOOLE_HOOK_STREAM_FUNCTION | SWOOLE_HOOK_STREAM_SELECT
        | SWOOLE_HOOK_NATIVE_CURL | SWOOLE_HOOK_SOCKETS;

    public static function enable(): int
    {
        if (!class_exists('Swoole\Runtime')) {
            return 0;
        }
        \Swoole\Runtime::enableCoroutine(self::FLAGS);
        return self::current();
    }

    public static function current(): int
    {
        if (!class_exists('Swoole\Runtime') || !method_exists('Swoole\Runtime', 'getHookFlags')) {
            return 0;
        }
        return (int)\Swoole\Runtime::getHookFlags();
    }

    public static function ok(): bool
    {
        $f = self::current();
        return ($f & SWOOLE_HOOK_TCP) !== 0 && ($f & SWOOLE_HOOK_STREAM_FUNCTION) !== 0;
    }
}
