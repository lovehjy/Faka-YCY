<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime;

use App\Plugin\ThreadManager\Service\Log;
use App\Plugin\ThreadManager\Task\Invoker;
use App\Plugin\ThreadManager\Task\TaskContext;
use App\Plugin\ThreadManager\Task\TaskSpec;

final class Runner
{

    public const EXIT_OK = 'ok';
    public const EXIT_ERROR = 'error';
    public const EXIT_RELOAD = 'reload';
    public const EXIT_STOP = 'stop';

    private int $iterations = 0;
    private float $lastMs = 0.0;
    private float $avgMs = 0.0;
    private ?string $lastError = null;

    private int $consecutiveFailures = 0;
    private string $lastLoggedError = '';
    private float $lastLoggedAt = 0.0;

    public function __construct(
        private TaskSpec $spec,
        private int $replica,
        private Invoker $invoker,
        private \Closure $shouldRun,
        private \Closure $report,
    ) {}

    public function iterations(): int { return $this->iterations; }
    public function lastError(): ?string { return $this->lastError; }
    public function consecutiveFailures(): int { return $this->consecutiveFailures; }

    public function run(): string
    {
        $ctx = new TaskContext(
            id: $this->spec->replicaId($this->replica),
            plugin: $this->spec->plugin,
            name: $this->spec->name,
            replica: $this->replica,
            args: $this->spec->args,
            continueFn: fn(): bool => ($this->shouldRun)(),
            heartbeatFn: fn() => $this->heartbeat('running'),
        );

        if ($this->spec->delay > 0) {
            $this->sleep($this->spec->delay);
        }

        return match ($this->spec->mode) {
            TaskSpec::MODE_ONCE => $this->runOnce($ctx),
            TaskSpec::MODE_LOOP => $this->runLoop($ctx),
            TaskSpec::MODE_CRON => $this->runCron($ctx),
            default => $this->runInterval($ctx),
        };
    }

    private function runOnce(TaskContext $ctx): string
    {
        if (!($this->shouldRun)()) {
            return self::EXIT_STOP;
        }
        return $this->tick($ctx) ? self::EXIT_OK : self::EXIT_ERROR;
    }

    private function runInterval(TaskContext $ctx): string
    {
        while (($this->shouldRun)()) {
            $t0 = microtime(true);
            $this->tick($ctx);

            $wait = $this->spec->interval - (microtime(true) - $t0);
            if ($wait > 0 && !$this->sleep($wait)) {
                break;
            }
        }
        return ($this->shouldRun)() ? self::EXIT_OK : self::EXIT_RELOAD;
    }

    private function runLoop(TaskContext $ctx): string
    {
        if (!($this->shouldRun)()) {
            return self::EXIT_STOP;
        }
        $okRun = $this->tick($ctx);
        if (!$okRun) {
            return self::EXIT_ERROR;
        }

        if (($this->shouldRun)()) {
            Log::warn('loop 模式 handler 提前返回');
        }
        return self::EXIT_OK;
    }

    private function runCron(TaskContext $ctx): string
    {
        $cron = new Cron((string)$this->spec->cron);
        while (($this->shouldRun)()) {
            $next = $cron->nextAfter(time());
            $wait = max(1.0, (float)($next - time()));
            if (!$this->sleep($wait)) {
                break;
            }
            if (!($this->shouldRun)()) {
                break;
            }
            $this->tick($ctx);
        }
        return ($this->shouldRun)() ? self::EXIT_OK : self::EXIT_RELOAD;
    }

    private function tick(TaskContext $ctx): bool
    {
        $this->iterations++;
        $t0 = microtime(true);

        Guard::beginIteration();
        try {

            Bootstrap::betweenIterations($ctx->id);

            $this->callInOwnCoroutine($ctx);

            $this->lastError = null;
            Guard::endIteration();
            $ok = true;
        } catch (\Throwable $e) {
            $this->lastError = get_class($e) . ': ' . $e->getMessage();
            $this->consecutiveFailures++;

            $now = microtime(true);
            if ($this->lastError !== $this->lastLoggedError || $now - $this->lastLoggedAt > 30) {
                $this->lastLoggedError = $this->lastError;
                $this->lastLoggedAt = $now;
                Guard::report('task', $e);
                if ($this->consecutiveFailures > 1) {
                    Log::warn(sprintf('该错误已连续发生 %d 次', $this->consecutiveFailures));
                }
            }
            Guard::endIteration();
            $ok = false;
        }
        if ($ok) {
            $this->consecutiveFailures = 0;
        }

        $this->lastMs = (microtime(true) - $t0) * 1000;

        $this->avgMs = $this->avgMs > 0 ? ($this->avgMs * 0.8 + $this->lastMs * 0.2) : $this->lastMs;

        $this->heartbeat($ok ? 'running' : 'error');
        return $ok;
    }

    private function callInOwnCoroutine(TaskContext $ctx): void
    {
        if (!class_exists('Swoole\Coroutine') || \Swoole\Coroutine::getCid() < 0) {
            $this->invoker->call($ctx);
            return;
        }

        $ch = new \Swoole\Coroutine\Channel(1);
        \Swoole\Coroutine::create(function () use ($ctx, $ch): void {
            try {
                $this->invoker->call($ctx);
                $ch->push([null]);
            } catch (\Throwable $e) {
                $ch->push([$e]);
            }
        });
        $r = $ch->pop();
        if (is_array($r) && $r[0] instanceof \Throwable) {
            throw $r[0];
        }
    }

    private function heartbeat(string $state): void
    {
        ($this->report)([
            'state' => $state,
            'ts' => microtime(true),
            'iter' => $this->iterations,
            'last_ms' => round($this->lastMs, 2),
            'avg_ms' => round($this->avgMs, 2),
            'mem' => memory_get_usage(true),
            'err' => $this->lastError,
            'fails' => $this->consecutiveFailures,
            'pool' => \App\Plugin\ThreadManager\Runtime\Database\Pool::stats(),
            'redis' => \App\Plugin\ThreadManager\Runtime\Redis\Pool::stats(),
        ]);
    }

    /**
     * 等待期间的心跳间隔（秒）。
     * 必须远小于 hungThreshold 的下限（60 秒），否则等待中照样会被判成卡死。
     */
    private const IDLE_HEARTBEAT = 15.0;

    private function sleep(float $seconds): bool
    {
        $deadline = microtime(true) + $seconds;
        $slice = 0.25;

        //等待期间也要报心跳。cron 任务两次执行之间可能隔一整天，interval 任务也可能设成
        //几小时才跑一次，只在 tick() 结束时报一次心跳的话，Supervisor 会把正常排队等待的
        //worker 当成卡死：日志每分钟刷一条，面板长期挂着异常，hung_action=kill / restart-daemon
        //时还会把好好的任务杀掉或者让守护进程反复重启（GitHub #884）。
        //
        //这么改不会削弱卡死检测：真正卡死是卡在 handler 里（invoker->call），那时候根本执行
        //不到这里，心跳照样会断，该报的还是会报。
        $nextBeat = microtime(true) + self::IDLE_HEARTBEAT;

        while (microtime(true) < $deadline) {
            if (!($this->shouldRun)()) {
                return false;
            }
            $now = microtime(true);
            if ($now >= $nextBeat) {
                $nextBeat = $now + self::IDLE_HEARTBEAT;
                $this->heartbeat('idle');
            }
            $left = $deadline - $now;

            if ($left < 0.001) {
                break;
            }
            $nap = min($slice, $left);
            if (class_exists('Swoole\Coroutine') && \Swoole\Coroutine::getCid() > 0) {
                \Swoole\Coroutine::sleep($nap);
            } else {
                usleep((int)($nap * 1_000_000));
            }
        }
        return ($this->shouldRun)();
    }
}
