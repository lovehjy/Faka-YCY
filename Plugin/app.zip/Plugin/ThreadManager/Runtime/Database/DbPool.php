<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Database;

use App\Plugin\ThreadManager\Service\Log;
use Illuminate\Database\Connection;
use Illuminate\Database\Connectors\ConnectionFactory;
use Swoole\Coroutine;
use Swoole\Coroutine\Channel;

final class DbPool
{
    private ?Channel $idle = null;
    private int $created = 0;
    private int $waiting = 0;
    private bool $closed = false;

    private ?ConnectionFactory $factory = null;
    private ?TaskConnection $bootstrapConn = null;

    private int $statAcquired = 0;
    private int $statTimeouts = 0;
    private int $statTxLeaks = 0;
    private int $statDiscarded = 0;

    public function __construct(
        private array $config,
        private object $container,
        public int $min = 1,
        public int $max = 8,
        public float $acquireTimeout = 3.0,
        public float $maxIdleSeconds = 55.0,
        public float $maxLifetimeSeconds = 3600.0,
        public float $heartbeatSeconds = 30.0,
        public string $isolationLevel = 'REPEATABLE READ',
    ) {

        $this->config['options'] = ($this->config['options'] ?? []) + [
            \PDO::ATTR_PERSISTENT => false,
            \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
        ];
    }

    public function clampToServer(?int $waitTimeout): float
    {
        if ($waitTimeout === null || $waitTimeout <= 0) {
            return $this->maxIdleSeconds;
        }
        return min($this->maxIdleSeconds, max(5.0, $waitTimeout - 10.0));
    }

    public function init(): void
    {
        if ($this->idle !== null) {
            return;
        }

        $this->idle = new Channel($this->max);
        $this->factory = new ConnectionFactory($this->container);
    }

    public function fill(): void
    {
        $this->init();
        while ($this->created < $this->min) {
            try {
                $this->idle->push($this->make());
            } catch (\Throwable $e) {
                Log::warn('连接池预热失败：' . $e->getMessage());
                break;
            }
        }
    }

    private function make(): TaskConnection
    {

        $this->created++;
        try {
            return $this->build();
        } catch (\Throwable $e) {
            $this->created = max(0, $this->created - 1);
            throw $e;
        }
    }

    private function build(): TaskConnection
    {

        $conn = $this->factory->make($this->config, 'default');

        $cfg = $this->config;
        $factory = $this->factory;
        $conn->setReconnector(static function (Connection $c) use ($factory, $cfg): void {
            $c->setPdo($factory->createConnector($cfg)->connect($cfg));
        });

        $conn->getPdo();
        $conn->inPool = true;
        $conn->poolBornAt = microtime(true);
        $conn->poolLastUsed = microtime(true);

        return $conn;
    }

    public function acquire(): Lease
    {
        $this->init();
        if ($this->closed) {
            throw new PoolClosedException('连接池正在关闭');
        }

        $deadline = microtime(true) + $this->acquireTimeout;

        while (true) {
            $conn = null;

            if ($this->idle->isEmpty() && $this->created < $this->max) {
                $conn = $this->make();
            } else {
                $this->waiting++;
                try {
                    $left = max(0.001, $deadline - microtime(true));
                    $got = $this->idle->pop($left);
                } finally {
                    $this->waiting--;
                }

                if ($got === false) {
                    if ($this->idle->errCode === SWOOLE_CHANNEL_CLOSED) {
                        throw new PoolClosedException('连接池已关闭');
                    }
                    $this->statTimeouts++;
                    throw new PoolTimeoutException($this->stats());
                }
                $conn = $got;
            }

            $now = microtime(true);
            if ($now - $conn->poolBornAt > $this->maxLifetimeSeconds || !$this->ping($conn, $now)) {
                $this->destroy($conn);
                if (microtime(true) >= $deadline) {
                    $this->statTimeouts++;
                    throw new PoolTimeoutException($this->stats());
                }
                continue;
            }

            $conn->poolLastUsed = $now;
            $conn->ownerCid = class_exists('Swoole\Coroutine') ? Coroutine::getCid() : null;
            $conn->inPool = false;
            $this->statAcquired++;

            return new Lease($conn);
        }
    }

    private function ping(TaskConnection $conn, float $now): bool
    {
        if ($now - $conn->poolLastUsed < $this->heartbeatSeconds) {
            return true;
        }
        try {
            $conn->rawPdo()?->query('/*tm-ping*/ SELECT 1');
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function release(Lease $lease): void
    {
        if ($lease->released) {
            return;
        }
        $lease->released = true;
        $conn = $lease->connection;
        $conn->ownerCid = null;

        try {
            if ($conn->transactionLevel() > 0) {
                $this->statTxLeaks++;
                Log::error('任务结束时事务未提交，已回滚', ['level' => $conn->transactionLevel()]);
                $conn->rollBack();
            }
        } catch (\Throwable $e) {
            $conn->poolBroken = true;
            Log::error('回滚泄漏的事务失败，连接将被丢弃：' . $e->getMessage());
        }

        if ($this->closed || $conn->poolBroken || $conn->sessionPoisoned) {
            if ($conn->sessionPoisoned) {
                Log::debug('连接会话已污染，丢弃不复用');
            }
            $this->destroy($conn);
            return;
        }

        try {
            $pdo = $conn->rawPdo();
            if ($pdo !== null) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $pdo->exec('SET SESSION TRANSACTION ISOLATION LEVEL ' . $this->isolationLevel);
            }
            $conn->flushQueryLog();
        } catch (\Throwable $e) {
            $this->destroy($conn);
            return;
        }

        $conn->poolLastUsed = microtime(true);
        $conn->inPool = true;
        if (!$this->idle->push($conn, 0.001)) {
            $this->destroy($conn);
        }
    }

    private function destroy(TaskConnection $conn): void
    {
        $this->statDiscarded++;
        try {
            $conn->disconnect();
        } catch (\Throwable $e) {
        }
        $this->created = max(0, $this->created - 1);
    }

    public function bootstrapConnection(): TaskConnection
    {
        $this->init();
        if ($this->bootstrapConn === null) {
            $this->bootstrapConn = $this->make();
            $this->bootstrapConn->inPool = false;
        }
        return $this->bootstrapConn;
    }

    private function nap(callable $shouldRun): bool
    {
        $deadline = microtime(true) + $this->heartbeatSeconds;
        while (microtime(true) < $deadline) {
            if ($this->closed || !$shouldRun()) {
                return false;
            }
            $left = $deadline - microtime(true);
            if ($left < 0.001) {
                break;
            }
            Coroutine::sleep(min(0.5, $left));
        }
        return !$this->closed && $shouldRun();
    }

    public function janitor(callable $shouldRun): void
    {
        $maxIdle = $this->maxIdleSeconds;
        while (!$this->closed && $shouldRun()) {
            if (!$this->nap($shouldRun)) {
                break;
            }

            $n = $this->idle->length();
            for ($i = 0; $i < $n; $i++) {
                $c = $this->idle->pop(0.001);
                if ($c === false) {
                    break;
                }
                $now = microtime(true);
                if (($this->created > $this->min && $now - $c->poolLastUsed > $maxIdle)
                    || $now - $c->poolBornAt > $this->maxLifetimeSeconds) {
                    $this->destroy($c);
                    continue;
                }
                try {
                    $c->rawPdo()?->query('/*tm-ping*/ SELECT 1');
                    $c->poolLastUsed = $now;
                    $this->idle->push($c, 0.001);
                } catch (\Throwable $e) {
                    $this->destroy($c);
                }
            }

            while ($this->created < $this->min && !$this->closed) {
                try {
                    $this->idle->push($this->make(), 0.001);
                } catch (\Throwable $e) {
                    break;
                }
            }
        }
    }

    public function close(): void
    {
        $this->closed = true;
        if ($this->idle === null) {
            return;
        }
        while (!$this->idle->isEmpty()) {
            $c = $this->idle->pop(0.001);
            if ($c === false) {
                break;
            }
            $this->destroy($c);
        }
        $this->idle->close();
    }

    public function stats(): array
    {
        return [
            'created' => $this->created,
            'max' => $this->max,
            'min' => $this->min,
            'idle' => $this->idle?->length() ?? 0,
            'waiting' => $this->waiting,
            'acquired' => $this->statAcquired,
            'timeouts' => $this->statTimeouts,
            'tx_leaks' => $this->statTxLeaks,
            'discarded' => $this->statDiscarded,
        ];
    }
}
