<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Database;

class PoolClosedException extends \RuntimeException
{
}
