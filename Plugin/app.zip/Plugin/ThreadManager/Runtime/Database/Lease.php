<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Database;

final class Lease
{
    public bool $released = false;

    public $onDestruct = null;

    public function __construct(public TaskConnection $connection) {}

    public function __destruct()
    {
        if (!$this->released && $this->onDestruct !== null) {
            try {
                ($this->onDestruct)($this);
            } catch (\Throwable $e) {
            }
        }
    }
}
