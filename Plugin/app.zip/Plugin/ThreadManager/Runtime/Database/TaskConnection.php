<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Database;

use Illuminate\Database\MySqlConnection;

class TaskConnection extends MySqlConnection
{
    public float $poolBornAt = 0.0;
    public float $poolLastUsed = 0.0;

    public bool $poolBroken = false;

    public bool $sessionPoisoned = false;

    public ?int $ownerCid = null;

    public bool $inPool = true;

    public static bool $strictOwner = true;

    public static $onViolation = null;

    protected function run($query, $bindings, \Closure $callback)
    {
        $this->assertOwner();
        return parent::run($query, $bindings, $callback);
    }

    public function statement($query, $bindings = [])
    {
        $this->sniff((string)$query);
        return parent::statement($query, $bindings);
    }

    public function unprepared($query)
    {
        $this->sniff((string)$query);
        return parent::unprepared($query);
    }

    private function assertOwner(): void
    {
        if (!class_exists('Swoole\Coroutine')) {
            return;
        }

        if ($this->inPool) {
            $this->violation(
                '连接已归还池中却仍被使用：说明有代码把 Connection/Builder 的引用'
                . '存到了协程之外。这条连接随时可能被另一个协程借走，两边并发使用会导致'
                . 'MySQL 报文交错。请不要把连接或 Builder 存进对象属性跨协程复用。'
            );
            return;
        }

        if ($this->ownerCid === null) {
            return;
        }
        $cid = \Swoole\Coroutine::getCid();
        if ($cid < 0 || $cid === $this->ownerCid) {
            return;
        }

        $this->violation(sprintf(
            '连接被跨协程使用：借出方 cid=%d，当前 cid=%d。'
            . '常见成因是 Builder 在一个协程里构造、却在另一个协程里执行。',
            $this->ownerCid,
            $cid
        ));
    }

    private function violation(string $msg): void
    {
        if (self::$onViolation !== null) {
            (self::$onViolation)($msg);
        }
        if (self::$strictOwner) {
            throw new CrossCoroutineConnectionException($msg);
        }
    }

    private function sniff(string $q): void
    {
        if (preg_match('/^\s*(lock\s+tables|unlock\s+tables|create\s+temporary|select\s+get_lock|do\s+get_lock|set\s+session|set\s+@)/i', $q)) {
            $this->sessionPoisoned = true;
        }
    }

    public function rawPdo(): ?\PDO
    {
        try {
            $pdo = $this->getPdo();
            return $pdo instanceof \PDO ? $pdo : null;
        } catch (\Throwable $e) {
            return null;
        }
    }
}
