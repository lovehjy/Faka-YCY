<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Database;

use Illuminate\Database\Capsule\Manager;

final class PooledCapsule extends Manager
{
    private ?CoroutineConnectionResolver $tmResolver = null;

    public function setResolver(CoroutineConnectionResolver $resolver): void
    {
        $this->tmResolver = $resolver;
    }

    public function getConnection($name = null)
    {
        if ($this->tmResolver === null) {
            return parent::getConnection($name);
        }
        return $this->tmResolver->connection($name);
    }
}
