<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Database;

use App\Plugin\ThreadManager\Service\Log;
use Illuminate\Database\ConnectionResolverInterface;
use Swoole\Coroutine;

final class CoroutineConnectionResolver implements ConnectionResolverInterface
{
    private const SLOT = 'tm.db';

    private array $cidsInTransaction = [];

    public function __construct(
        private DbPool $pool,
        private string $default = 'default',
        public bool $warnNestedCoroutineTransaction = true,
    ) {}

    public function connection($name = null)
    {
        $name = $name ?: $this->default;

        if (!class_exists('Swoole\Coroutine')) {
            return $this->pool->bootstrapConnection();
        }

        $cid = Coroutine::getCid();
        if ($cid < 0) {

            return $this->pool->bootstrapConnection();
        }

        $ctx = Coroutine::getContext();
        $slot = self::SLOT . '.' . $name;

        if (isset($ctx[$slot])) {

            $lease = $ctx[$slot];
            return $lease->connection;
        }

        $this->warnIfAncestorInTransaction($cid);

        $lease = $this->pool->acquire();
        $lease->onDestruct = fn(Lease $l) => $this->releaseLease($l);
        $ctx[$slot] = $lease;
        Coroutine::defer(fn() => $this->releaseLease($lease));

        return $lease->connection;
    }

    private function releaseLease(Lease $lease): void
    {
        $cid = $lease->connection->ownerCid;
        if ($cid !== null) {
            unset($this->cidsInTransaction[$cid]);
        }
        $this->pool->release($lease);
    }

    private function warnIfAncestorInTransaction(int $cid): void
    {
        if (!$this->warnNestedCoroutineTransaction || $this->cidsInTransaction === []) {
            return;
        }
        $p = Coroutine::getPcid($cid);
        for ($depth = 0; $p !== false && $p > 0 && $depth < 32; $depth++) {
            if (isset($this->cidsInTransaction[$p])) {
                Log::warn(sprintf(
                    '协程 %d 在祖先协程 %d 的事务内部借了另一条连接：'
                    . '它的写入**不属于**那个事务，也不会随之回滚。'
                    . '请不要在 DB::transaction() 里 go() 新协程做写操作。',
                    $cid,
                    $p
                ));
                return;
            }
            $p = Coroutine::getPcid($p);
        }
    }

    public function noteTransaction(int $cid, bool $inTransaction): void
    {
        if ($inTransaction) {
            $this->cidsInTransaction[$cid] = true;
        } else {
            unset($this->cidsInTransaction[$cid]);
        }
    }

    public function getDefaultConnection()
    {
        return $this->default;
    }

    public function setDefaultConnection($name)
    {
        $this->default = (string)$name;
    }
}
