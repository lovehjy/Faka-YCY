<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Database;

class PoolTimeoutException extends \RuntimeException
{
    public function __construct(public array $stats)
    {
        parent::__construct(sprintf(
            '获取数据库连接超时：已创建 %d/%d，空闲 %d，等待 %d。请调大 max，或降低任务并发。',
            $stats['created'] ?? 0,
            $stats['max'] ?? 0,
            $stats['idle'] ?? 0,
            $stats['waiting'] ?? 0
        ));
    }
}
