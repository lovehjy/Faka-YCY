<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Database;

use App\Plugin\ThreadManager\Runtime\Db;
use App\Plugin\ThreadManager\Service\Log;
use Illuminate\Database\Connection;
use Illuminate\Database\Eloquent\Model;
use Swoole\Coroutine;

final class Pool
{
    private static ?DbPool $pool = null;
    private static ?CoroutineConnectionResolver $resolver = null;
    private static bool $installed = false;

    public static function installed(): bool { return self::$installed; }
    public static function pool(): ?DbPool { return self::$pool; }

    public static function install(array $opt = []): void
    {
        if (self::$installed) {
            return;
        }

        if (!class_exists('Swoole\Coroutine')) {
            Log::warn('无协程环境，跳过连接池安装');
            return;
        }

        $capsuleBoot = Db::connect();
        $waitTimeout = Db::serverVar('wait_timeout');
        $maxConn = Db::serverVar('max_connections');

        $cfg = Db::config();

        Connection::resolverFor('mysql', static function ($pdo, $database, $prefix, $config) {
            return new TaskConnection($pdo, $database, $prefix, $config);
        });

        TaskConnection::$strictOwner = (bool)($opt['strict_owner'] ?? true);
        TaskConnection::$onViolation = static fn(string $m) => Log::error('[连接池] ' . $m);

        $pool = new DbPool(
            config: $cfg,
            container: $capsuleBoot->getContainer(),
            min: max(0, (int)($opt['min'] ?? 1)),
            max: max(1, (int)($opt['max'] ?? 8)),
            acquireTimeout: (float)($opt['acquire_timeout'] ?? 3.0),
            maxIdleSeconds: (float)($opt['max_idle'] ?? 55.0),
            maxLifetimeSeconds: (float)($opt['max_lifetime'] ?? 3600.0),
            heartbeatSeconds: (float)($opt['heartbeat'] ?? 30.0),
        );

        $clamped = $pool->clampToServer($waitTimeout);
        if ($clamped < $pool->maxIdleSeconds) {
            Log::info(sprintf(
                '按服务端 wait_timeout=%d 把空闲上限从 %.0fs 收紧到 %.0fs',
                (int)$waitTimeout,
                $pool->maxIdleSeconds,
                $clamped
            ));
        }

        $pool->init();
        $resolver = new CoroutineConnectionResolver($pool);

        $capsule = new PooledCapsule();
        $capsule->addConnection($cfg);
        $capsule->setAsGlobal();
        $capsule->setResolver($resolver);
        $capsule->bootEloquent();
        Model::setConnectionResolver($resolver);

        self::$pool = $pool;
        self::$resolver = $resolver;
        self::$installed = true;

        Log::info('数据库连接池已安装', [
            'min' => $pool->min,
            'max' => $pool->max,
            'wait_timeout' => $waitTimeout,
            'max_connections' => $maxConn,
        ]);
    }

    public static function start(callable $shouldRun): void
    {
        if (!self::$installed || self::$pool === null) {
            return;
        }
        self::$pool->fill();
        $pool = self::$pool;
        Coroutine::create(static function () use ($pool, $shouldRun): void {
            try {
                $pool->janitor($shouldRun);
            } catch (\Throwable $e) {
                Log::exception($e, '[janitor]');
            }
        });
    }

    public static function checkBudget(int $threads, ?int $maxConnections = null): array
    {
        if (self::$pool === null) {
            return ['ok' => true, 'msg' => '连接池未安装'];
        }
        $maxConnections ??= Db::serverVar('max_connections');
        if ($maxConnections === null || $maxConnections <= 0) {
            return ['ok' => true, 'msg' => '读不到 max_connections，跳过预算校验'];
        }
        $total = $threads * self::$pool->max;
        $limit = (int)floor($maxConnections * 0.7);
        return $total > $limit
            ? ['ok' => false, 'msg' => sprintf(
                '连接预算超限：%d 工作进程 × 每池 %d = %d 条，超过 max_connections(%d) 的 70%%（%d）。'
                . '请调小池的 max 或减少任务副本数。',
                $threads, self::$pool->max, $total, $maxConnections, $limit)]
            : ['ok' => true, 'msg' => sprintf('连接预算 %d/%d 条（上限 %d）', $total, $maxConnections, $limit)];
    }

    public static function release(): bool
    {
        if (!class_exists('Swoole\Coroutine') || Coroutine::getCid() < 0) {
            return false;
        }
        $ctx = Coroutine::getContext();
        $slot = 'tm.db.default';
        if (!isset($ctx[$slot])) {
            return false;
        }

        $lease = $ctx[$slot];
        if ($lease->connection->transactionLevel() > 0) {
            Log::warn('事务未结束，拒绝提前归还连接');
            return false;
        }
        self::$pool?->release($lease);
        unset($ctx[$slot]);
        return true;
    }

    public static function stats(): array
    {
        return self::$pool?->stats() ?? [];
    }

    public static function shutdown(): void
    {
        self::$pool?->close();
        self::$installed = false;
    }
}
