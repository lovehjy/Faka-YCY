<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Redis;

final class Compat
{
    public const CLASS_NAME = 'App\Plugin\Redis\Redis';

    public static function check(): array
    {
        if (!extension_loaded('redis')) {
            return ['ok' => false, 'reason' => 'PHP 未安装 redis 扩展'];
        }
        if (!class_exists(self::CLASS_NAME)) {
            return ['ok' => false, 'reason' => 'Redis 插件未安装'];
        }

        try {
            $rc = new \ReflectionClass(self::CLASS_NAME);

            if ($rc->isFinal()) {
                return ['ok' => false, 'reason' => 'Redis 插件的类被标记为 final，无法继承'];
            }
            if (!$rc->hasMethod('getRedis')) {
                return ['ok' => false, 'reason' => 'Redis 插件没有 getRedis() 方法'];
            }
            $m = $rc->getMethod('getRedis');
            if ($m->isFinal()) {
                return ['ok' => false, 'reason' => 'getRedis() 被标记为 final，无法覆盖'];
            }
            if (!$m->isPublic() || $m->isStatic()) {
                return ['ok' => false, 'reason' => 'getRedis() 不是 public 实例方法'];
            }
            if (!$rc->hasProperty('instance')) {
                return ['ok' => false, 'reason' => 'Redis 插件没有 Singleton 的 $instance 静态属性'];
            }
            if (!$rc->getProperty('instance')->isStatic()) {
                return ['ok' => false, 'reason' => '$instance 不是静态属性'];
            }
        } catch (\Throwable $e) {
            return ['ok' => false, 'reason' => '反射检查失败：' . $e->getMessage()];
        }

        return ['ok' => true, 'reason' => ''];
    }

    public static function swap(object $instance): void
    {
        $p = new \ReflectionProperty(self::CLASS_NAME, 'instance');
        $p->setAccessible(true);
        $p->setValue(null, $instance);
    }

    public static function restore(): void
    {
        try {
            $p = new \ReflectionProperty(self::CLASS_NAME, 'instance');
            $p->setAccessible(true);

            $p->setValue(null, null);
        } catch (\Throwable $e) {
        }
    }

    public static function config(): array
    {
        try {
            return \App\Util\Plugin::getConfig('Redis', false);
        } catch (\Throwable $e) {
            return [];
        }
    }

    public static function pluginEnabled(): bool
    {
        return (string)(self::config()['STATUS'] ?? '0') === '1';
    }
}
