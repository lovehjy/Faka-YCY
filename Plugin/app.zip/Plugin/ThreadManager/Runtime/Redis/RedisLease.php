<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Redis;

final class RedisLease
{
    public bool $released = false;

    public $onDestruct = null;

    public function __construct(public \Redis $redis) {}

    public function __destruct()
    {
        if (!$this->released && $this->onDestruct !== null) {
            try {
                ($this->onDestruct)($this);
            } catch (\Throwable $e) {
            }
        }
    }
}
