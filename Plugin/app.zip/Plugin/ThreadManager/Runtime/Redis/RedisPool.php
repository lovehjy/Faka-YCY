<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Redis;

use App\Plugin\ThreadManager\Runtime\Database\PoolClosedException;
use App\Plugin\ThreadManager\Runtime\Database\PoolTimeoutException;
use App\Plugin\ThreadManager\Service\Log;
use Swoole\Coroutine;
use Swoole\Coroutine\Channel;

final class RedisPool
{
    private ?Channel $idle = null;
    private int $created = 0;
    private int $waiting = 0;
    private bool $closed = false;
    private ?\Redis $bootstrapConn = null;

    private int $statAcquired = 0;
    private int $statTimeouts = 0;
    private int $statDiscarded = 0;

    public function __construct(
        private array $config,
        private int $min = 1,
        private int $max = 8,
        private float $acquireTimeout = 3.0,
        private float $maxIdleSeconds = 55.0,
        private float $heartbeatSeconds = 30.0,
    ) {}

    public function max(): int { return $this->max; }

    public function init(): void
    {
        if ($this->idle === null) {
            $this->idle = new Channel($this->max);
        }
    }

    public function fill(): void
    {
        $this->init();
        while ($this->created < $this->min) {
            try {
                $this->idle->push($this->make());
            } catch (\Throwable $e) {
                Log::warn('Redis 池预热失败：' . $e->getMessage());
                break;
            }
        }
    }

    private function make(): \Redis
    {

        $this->created++;
        try {
            return $this->build();
        } catch (\Throwable $e) {
            $this->created = max(0, $this->created - 1);
            throw $e;
        }
    }

    private function build(): \Redis
    {
        $r = new \Redis();
        $host = (string)($this->config['host'] ?? '127.0.0.1');
        $port = (int)($this->config['port'] ?? 6379);

        if (!$r->connect($host, $port, 2.0, null, 0, 0.0)) {
            throw new \RuntimeException("连接 Redis 失败：{$host}:{$port}");
        }

        $r->setOption(\Redis::OPT_SERIALIZER, \Redis::SERIALIZER_PHP);

        $auth = (string)($this->config['auth'] ?? '');
        if ($auth !== '') {
            $r->auth($auth);
        }
        if (isset($this->config['db']) && $this->config['db'] !== '') {
            $r->select((int)$this->config['db']);
        }

        RedisState::mark($r);
        return $r;
    }

    public function acquire(): RedisLease
    {
        $this->init();
        if ($this->closed) {
            throw new PoolClosedException('Redis 池正在关闭');
        }

        $deadline = microtime(true) + $this->acquireTimeout;

        while (true) {
            if ($this->idle->isEmpty() && $this->created < $this->max) {
                $conn = $this->make();
            } else {
                $this->waiting++;
                try {
                    $got = $this->idle->pop(max(0.001, $deadline - microtime(true)));
                } finally {
                    $this->waiting--;
                }
                if ($got === false) {
                    if ($this->idle->errCode === SWOOLE_CHANNEL_CLOSED) {
                        throw new PoolClosedException('Redis 池已关闭');
                    }
                    $this->statTimeouts++;
                    throw new PoolTimeoutException($this->stats());
                }
                $conn = $got;
            }

            if (!$this->ping($conn)) {
                $this->destroy($conn);
                if (microtime(true) >= $deadline) {
                    $this->statTimeouts++;
                    throw new PoolTimeoutException($this->stats());
                }
                continue;
            }

            RedisState::touch($conn);
            RedisState::setInPool($conn, false);
            $this->statAcquired++;
            return new RedisLease($conn);
        }
    }

    private function ping(\Redis $r): bool
    {
        if (microtime(true) - RedisState::lastUsed($r) < $this->heartbeatSeconds) {
            return true;
        }
        try {
            $r->ping();
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function release(RedisLease $lease): void
    {
        if ($lease->released) {
            return;
        }
        $lease->released = true;
        $r = $lease->redis;
        RedisState::setInPool($r, true);

        if ($this->closed || RedisState::isPoisoned($r)) {
            $this->destroy($r);
            return;
        }

        try {
            $r->unwatch();
        } catch (\Throwable $e) {
            $this->destroy($r);
            return;
        }

        RedisState::touch($r);
        if (!$this->idle->push($r, 0.001)) {
            $this->destroy($r);
        }
    }

    private function destroy(\Redis $r): void
    {
        $this->statDiscarded++;
        try {
            $r->close();
        } catch (\Throwable $e) {
        }
        $this->created = max(0, $this->created - 1);
    }

    public function probe(): void
    {
        $r = $this->make();
        try {
            $r->ping();
        } finally {
            $this->destroy($r);
        }
    }

    public function bootstrapConnection(): \Redis
    {
        if ($this->bootstrapConn === null) {
            $this->bootstrapConn = $this->make();
            RedisState::setInPool($this->bootstrapConn, false);
        }
        return $this->bootstrapConn;
    }

    public function janitor(callable $shouldRun): void
    {
        while (!$this->closed && $shouldRun()) {
            if (!$this->nap($shouldRun)) {
                break;
            }
            $n = $this->idle->length();
            for ($i = 0; $i < $n; $i++) {
                $c = $this->idle->pop(0.001);
                if ($c === false) {
                    break;
                }
                if ($this->created > $this->min && microtime(true) - RedisState::lastUsed($c) > $this->maxIdleSeconds) {
                    $this->destroy($c);
                    continue;
                }
                try {
                    $c->ping();
                    RedisState::touch($c);
                    $this->idle->push($c, 0.001);
                } catch (\Throwable $e) {
                    $this->destroy($c);
                }
            }
        }
    }

    private function nap(callable $shouldRun): bool
    {
        $deadline = microtime(true) + $this->heartbeatSeconds;
        while (microtime(true) < $deadline) {
            if ($this->closed || !$shouldRun()) {
                return false;
            }
            $left = $deadline - microtime(true);
            if ($left < 0.001) {
                break;
            }
            Coroutine::sleep(min(0.5, $left));
        }
        return !$this->closed && $shouldRun();
    }

    public function close(): void
    {
        $this->closed = true;
        if ($this->idle === null) {
            return;
        }
        while (!$this->idle->isEmpty()) {
            $c = $this->idle->pop(0.001);
            if ($c === false) {
                break;
            }
            $this->destroy($c);
        }
        $this->idle->close();
    }

    public function stats(): array
    {
        return [
            'created' => $this->created,
            'max' => $this->max,
            'min' => $this->min,
            'idle' => $this->idle?->length() ?? 0,
            'waiting' => $this->waiting,
            'acquired' => $this->statAcquired,
            'timeouts' => $this->statTimeouts,
            'discarded' => $this->statDiscarded,
        ];
    }
}
