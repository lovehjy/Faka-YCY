<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Redis;

use App\Plugin\ThreadManager\Service\Log;
use Swoole\Coroutine;

final class Pool
{
    private static ?RedisPool $pool = null;
    private static bool $installed = false;
    private static string $skipReason = '';

    public static function installed(): bool { return self::$installed; }
    public static function skipReason(): string { return self::$skipReason; }
    public static function pool(): ?RedisPool { return self::$pool; }

    public static function install(array $opt = []): bool
    {
        if (self::$installed) {
            return true;
        }

        if (!class_exists('Swoole\Coroutine')) {
            self::$skipReason = '没有协程环境';
            return false;
        }

        $compat = Compat::check();
        if (!$compat['ok']) {

            self::$skipReason = $compat['reason'];
            Log::info('Redis 连接池未启用：' . $compat['reason']);
            return false;
        }

        $cfg = Compat::config();

        try {
            $pool = new RedisPool(
                $cfg,
                max(0, (int)($opt['min'] ?? 1)),
                max(1, (int)($opt['max'] ?? 8)),
                (float)($opt['acquire_timeout'] ?? 3.0),
                (float)($opt['max_idle'] ?? 55.0),
                (float)($opt['heartbeat'] ?? 30.0),
            );
            $pool->init();

            $pool->probe();

            $releaser = static function (RedisLease $l) use ($pool): void {
                $pool->release($l);
            };
            Compat::swap(new PooledRedis($pool, $releaser));

            self::$pool = $pool;
            self::$installed = true;
            Log::info('Redis 连接池已安装', ['max' => $pool->max(), 'host' => $cfg['host'] ?? '?']);
            return true;
        } catch (\Throwable $e) {

            self::$skipReason = '连接失败：' . $e->getMessage();
            Log::warn('Redis 连接池未启用：' . $e->getMessage());
            self::$pool = null;
            self::$installed = false;
            return false;
        }
    }

    public static function start(callable $shouldRun): void
    {
        if (!self::$installed || self::$pool === null) {
            return;
        }
        self::$pool->fill();
        $pool = self::$pool;
        Coroutine::create(static function () use ($pool, $shouldRun): void {
            try {
                $pool->janitor($shouldRun);
            } catch (\Throwable $e) {
                Log::exception($e, '[redis-janitor]');
            }
        });
    }

    public static function stats(): array
    {
        return self::$pool?->stats() ?? ['installed' => false, 'reason' => self::$skipReason];
    }

    public static function shutdown(): void
    {
        self::$pool?->close();
        if (self::$installed) {
            Compat::restore();
        }
        self::$pool = null;
        self::$installed = false;
    }
}
