<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Redis;

final class RedisState
{
    private static ?\WeakMap $map = null;

    private static function map(): \WeakMap
    {
        return self::$map ??= new \WeakMap();
    }

    public static function mark(\Redis $r): void
    {
        self::map()[$r] = ['last' => microtime(true), 'inPool' => true, 'poisoned' => false, 'owner' => null];
    }

    public static function touch(\Redis $r): void
    {
        $s = self::map()[$r] ?? ['inPool' => true, 'poisoned' => false, 'owner' => null];
        $s['last'] = microtime(true);
        self::map()[$r] = $s;
    }

    public static function lastUsed(\Redis $r): float
    {
        return (float)((self::map()[$r]['last'] ?? 0.0));
    }

    public static function setInPool(\Redis $r, bool $v): void
    {
        $s = self::map()[$r] ?? ['last' => microtime(true), 'poisoned' => false, 'owner' => null];
        $s['inPool'] = $v;
        $s['owner'] = $v ? null : (class_exists('Swoole\Coroutine') ? \Swoole\Coroutine::getCid() : null);
        self::map()[$r] = $s;
    }

    public static function isInPool(\Redis $r): bool
    {
        return (bool)(self::map()[$r]['inPool'] ?? true);
    }

    public static function owner(\Redis $r): ?int
    {
        return self::map()[$r]['owner'] ?? null;
    }

    public static function poison(\Redis $r): void
    {
        $s = self::map()[$r] ?? ['last' => microtime(true), 'inPool' => false, 'owner' => null];
        $s['poisoned'] = true;
        self::map()[$r] = $s;
    }

    public static function isPoisoned(\Redis $r): bool
    {
        return (bool)(self::map()[$r]['poisoned'] ?? false);
    }
}
