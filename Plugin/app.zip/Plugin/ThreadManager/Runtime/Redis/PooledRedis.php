<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime\Redis;

final class PooledRedis extends \App\Plugin\Redis\Redis
{
    private RedisPool $pool;

    private $releaser;

    public function __construct(RedisPool $pool, callable $releaser)
    {
        $this->pool = $pool;
        $this->releaser = $releaser;
    }

    public function getRedis(): \Redis
    {
        if (!class_exists('Swoole\Coroutine')) {
            return $this->pool->bootstrapConnection();
        }
        $cid = \Swoole\Coroutine::getCid();
        if ($cid < 0) {
            return $this->pool->bootstrapConnection();
        }

        $ctx = \Swoole\Coroutine::getContext();
        if (isset($ctx['tm.redis'])) {

            $l = $ctx['tm.redis'];
            return $l->redis;
        }

        $lease = $this->pool->acquire();
        $lease->onDestruct = $this->releaser;
        $ctx['tm.redis'] = $lease;
        \Swoole\Coroutine::defer(function () use ($lease) {
            ($this->releaser)($lease);
        });

        return $lease->redis;
    }
}
