<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime;

use App\Plugin\ThreadManager\Service\Log;

final class Guard
{
    private static bool $installed = false;
    private static string $scope = 'thread';

    private static bool $iterationClean = true;

    private static $reporter = null;

    public static function install(string $scope, ?callable $reporter = null): void
    {
        self::$scope = $scope;
        self::$reporter = $reporter;

        if (self::$installed) {
            return;
        }
        self::$installed = true;

        error_reporting(E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED);
        ini_set('display_errors', '0');

        set_error_handler(static function (int $no, string $msg, string $file = '', int $line = 0): bool {
            if ((error_reporting() & $no) === 0) {
                return true;
            }
            Log::warn(sprintf('PHP[%d] %s', $no, $msg), ['at' => $file . ':' . $line]);
            return true;
        });

        set_exception_handler(static function (\Throwable $e): void {
            self::report('exception', $e);
        });

        register_shutdown_function(static function (): void {
            $err = error_get_last();
            if ($err !== null && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
                Log::error('致命错误：' . $err['message'], ['at' => ($err['file'] ?? '?') . ':' . ($err['line'] ?? 0)]);
                self::emit(['kind' => 'fatal', 'message' => $err['message'], 'at' => ($err['file'] ?? '') . ':' . ($err['line'] ?? 0)]);
                return;
            }
            if (!self::$iterationClean) {

                Log::error('任务未收尾即退出，可能触发了 exit()/die()');
                self::emit(['kind' => 'exit', 'message' => '任务被 exit() 中断']);
            }
        });
    }

    public static function beginIteration(): void { self::$iterationClean = false; }

    public static function endIteration(): void { self::$iterationClean = true; }

    public static function report(string $kind, \Throwable $e): void
    {
        Log::exception($e, "[{$kind}]");
        self::emit([
            'kind' => $kind,
            'class' => get_class($e),
            'message' => $e->getMessage(),
            'at' => $e->getFile() . ':' . $e->getLine(),
            'trace' => Log::shortTrace($e),
        ]);
    }

    private static function emit(array $payload): void
    {
        $payload['ts'] = microtime(true);
        $payload['scope'] = self::$scope;
        if (self::$reporter !== null) {
            try {
                (self::$reporter)($payload);
            } catch (\Throwable $e) {

            }
        }
    }
}
