<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Runtime;

final class StateReset
{

    private static array $accessors = [];

    private const KEEP_KERNEL_CONTEXT = [
        \Kernel\Consts\Base::LOCK,
        \Kernel\Consts\Base::IS_INSTALL,
        \Kernel\Consts\Base::OPCACHE,
        \Kernel\Consts\Base::STORE_STATUS,
        \Kernel\Consts\Base::ROUTE,
        \Kernel\Consts\Base::LANGUAGE,
    ];

    public static function run(): void
    {

        \Kernel\Annotation\Interceptor::$run = [];

        \Kernel\Util\Lang::reset(\Kernel\Util\Lang::SOURCE);

        self::pruneKernelContext();

        self::wipe(\App\Util\Context::class, 'context', []);

        self::wipe(\App\Util\File::class, 'cache', []);

        self::wipe(\Kernel\Util\File::class, 'files', []);

        \Kernel\Util\Plugin::$currentPluginName = null;
        \Kernel\Util\Plugin::$currentControllerPluginName = null;

    }

    private static function pruneKernelContext(): void
    {
        $ctx = self::read(\Kernel\Util\Context::class, 'context');
        if (!is_array($ctx)) {
            return;
        }
        foreach (array_keys($ctx) as $key) {
            $k = (string)$key;
            if (in_array($k, self::KEEP_KERNEL_CONTEXT, true) || str_starts_with($k, 'config_')) {
                continue;
            }
            \Kernel\Util\Context::del($k);
        }
    }

    private static function accessor(string $class, string $prop): ?\ReflectionProperty
    {
        $key = $class . '::' . $prop;
        if (array_key_exists($key, self::$accessors)) {
            return self::$accessors[$key];
        }
        try {
            $rp = new \ReflectionProperty($class, $prop);
            $rp->setAccessible(true);
            return self::$accessors[$key] = $rp;
        } catch (\Throwable $e) {
            return self::$accessors[$key] = null;
        }
    }

    private static function read(string $class, string $prop): mixed
    {
        $rp = self::accessor($class, $prop);
        return $rp?->getValue();
    }

    private static function wipe(string $class, string $prop, mixed $value): void
    {
        self::accessor($class, $prop)?->setValue(null, $value);
    }
}
