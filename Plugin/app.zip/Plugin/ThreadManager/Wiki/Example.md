# 示例代码

复制后把 `你的插件` 换成自己的插件名。规则说明见[接入指南](Develop.md)。

## 注册

`app/Plugin/你的插件/Hook/TaskRegister.php`

```php
<?php
declare(strict_types=1);

namespace App\Plugin\你的插件\Hook;

use App\Plugin\ThreadManager\Task\Task;
use App\Plugin\你的插件\Task\SyncTask;

class TaskRegister
{
    // 0x7A100 = \App\Plugin\ThreadManager\Consts\Hook::TASK_REGISTER
    // 必须写字面量，不能引用常量（ThreadManager 未安装时会导致本插件无法启用）
    #[\Kernel\Annotation\Hook(point: 0x7A100)]
    public function register(): array
    {
        return [
            Task::make('stock-sync', SyncTask::class)
                ->args(['channel' => 'default'])
                ->interval(30)
                ->bootFull(),

            Task::make('reconcile', ReconcileTask::class)
                ->cron('17 4 * * *')
                ->restartOnFailure()
                ->bootDb(),
        ];
    }

    // 可选：任务生命周期广播。$event: started|finished|failed|restarted|hung
    // 0x7A101 = \App\Plugin\ThreadManager\Consts\Hook::TASK_EVENT
    #[\Kernel\Annotation\Hook(point: 0x7A101)]
    public function event(string $event, array $payload): void
    {
        if ($event === 'failed') {
            // 通知管理员
        }
    }
}
```

只注册一个时可直接返回实体：

```php
public function register(): Task
{
    return Task::make('stock-sync', SyncTask::class)->interval(30)->bootFull();
}
```

### 链式方法

| 分类 | 方法 |
|---|---|
| 身份 | `make($name, $handler)` `method()` `args()` |
| 调度 | `interval($秒)` `cron($表达式)` `loop()` `once()` `delay()` `concurrency()` `disabled()` |
| 监管 | `restartAlways()` `restartOnFailure()` `restartNever()` `maxRestarts()` `backoff($min,$max,$factor,$jitter)` `successAfter()` `hungAfter()` |
| 运行时 | `bootFull()` `bootDb()` `bootNone()` `priority()` `raw($键,$值)` |

## interval 模式（推荐）

`app/Plugin/你的插件/Task/SyncTask.php`

```php
<?php
declare(strict_types=1);

namespace App\Plugin\你的插件\Task;

use App\Model\Commodity;
use App\Plugin\你的插件\Service\Sync;
use Kernel\Annotation\Inject;

class SyncTask
{
    #[Inject] private Sync $sync;

    /** 本方法即「一轮」，不要写 while(true) */
    public function run(object $ctx): void
    {
        Commodity::query()
            ->where('status', 1)
            ->chunkById(200, function ($rows) use ($ctx) {
                foreach ($rows as $row) {
                    $this->sync->one($row);
                }
                $ctx->heartbeat();   // 单轮耗时长时主动续命
            });

        $ctx->log('同步完成', ['channel' => $ctx->arg('channel')]);
    }
}
```

## loop 模式

事件驱动场景（`BLPOP`、websocket `recv`）专用。契约反转：循环与心跳由你自己负责。

```php
class QueueWorker
{
    public function run(object $ctx): void
    {
        $redis = \App\Plugin\Redis\Redis::inst()->getRedis();   // 自动池化

        while ($ctx->shouldContinue()) {      // 缺它则关不掉、也重载不了
            $job = $redis->blPop(['my:queue'], 2);
            $ctx->heartbeat();                // 缺它会被判定卡死

            if ($job) {
                $this->handle($job[1]);
            }
        }
    }
}
```

阻塞命令可用（读超时未设限），但超时值不宜过大，否则关闭时需等待其返回。

## 任务内并发

工作进程内协程 hook 已启用，`go()` 出去即真并发，Eloquent 与 Redis 同样适用。

```php
$wg = new \Swoole\Coroutine\WaitGroup();
foreach ($urls as $url) {
    $wg->add();
    go(function () use ($url, $wg) {
        try {
            $c = new \Swoole\Coroutine\Http\Client($host, 443, true);
            $c->get($path);
            $c->close();
        } finally {
            $wg->done();
        }
    });
}
$wg->wait();
```
