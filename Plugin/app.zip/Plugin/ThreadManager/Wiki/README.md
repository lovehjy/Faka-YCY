# 线程管理器（ThreadManager）

给 acg-faka 提供常驻任务能力的基础设施插件。其他插件把需要长期运行的代码注册进来，
由它统一调度、监管、崩溃重启，并提供数据库与 Redis 连接池。

本插件不提供任何面向买家的功能。

## 安装

一条命令搞定：下载 swoole-cli（认架构、校验 sha256、功能自检）→ 装好 → 启动守护进程。

```bash
cd /你的站点/app/Plugin/ThreadManager
chmod +x service.sh
./service.sh install
```

装完到后台「通用插件」启用「线程管理器」，左侧即可看到它的面板。二进制不随插件包发布（122MB，且与架构相关），由安装过程自动下载。

`install` 会自己看环境：**有 systemd 就注册成 systemd 服务；没有（Docker 等容器）就直接把守护进程拉起来**，
并打印用容器托管它的写法。两种环境下 `start｜stop｜restart｜status｜log` 都是同一套命令。

| | |
|---|---|
| 指定版本 | `./service.sh install v6.2.0.0`（默认 v6.1.7.0） |
| GitHub 不通 | `TM_MIRRORS="https://前缀/" ./service.sh install` |
| 自备地址 | `./service.sh install https://…/swoole-cli-v6.1.7-linux-x64.tar.xz` |
| 服务管理 | `./service.sh start｜stop｜restart｜status｜log｜uninstall` |
| 前台运行 | `./service.sh run`（容器 CMD / supervisord / s6 用这个） |
| 指定运行用户 | `TM_USER=www ./service.sh install`（默认取 `runtime/` 属主） |
| 强制运行模式 | `TM_MODE=systemd` 或 `TM_MODE=container`（默认自动判断） |

装 systemd 服务需要 SSH，仅此一次。之后任务启停、重载、乃至重启守护进程本身，
都可在后台面板操作 —— 插件代码中没有 `shell_exec` / `proc_open`，
面板与守护进程之间只通过命令文件通信。

## Docker / 容器部署

守护进程本体对 systemd 没有任何依赖 —— unit 里用的是 `Type=simple`，它本来就是个前台进程，
`./service.sh run` 就是它的容器入口。容器里唯一不同的是「谁在它退出后拉起它」。

先在**站点所在的容器里**装好二进制（只需一次，二进制落在站点目录里，跟着卷走）：

```bash
docker exec -it <容器名> bash
cd /你的站点 && chmod +x ./app/Plugin/ThreadManager/service.sh && ./app/Plugin/ThreadManager/service.sh install
```

这样起的进程活不过容器重建。要让它自己回来，二选一：

**① 给守护进程单独一个容器（推荐）**

```yaml
threadmanager:
  image: <和 php 容器同一个镜像>
  restart: always
  working_dir: /var/www/html
  command: ./app/Plugin/ThreadManager/service.sh run
  volumes:
    - ./站点目录:/var/www/html
  depends_on: [ mysql, redis ]
```

面板判断守护进程死活看的是 `runtime/plugin/ThreadManager/status.json` 的时间戳，**不是进程号**，
所以守护进程和 php-fpm 分在两个容器里也能正常识别，只要站点目录是同一个卷。
`docker stop` 会发 SIGTERM，守护进程收到后按 `stop_timeout` 优雅收尾。

**② 留在 php 容器里，交给 supervisord / s6 托管**

```ini
[program:threadmanager]
command=/var/www/html/app/Plugin/ThreadManager/service.sh run
directory=/var/www/html
user=www-data
autostart=true
autorestart=true
```

几个容器里特有的坑，脚本已经替你处理了：

- **别用 root 跑**。容器里默认就是 root，而站点文件多半属于 `www-data`；用 root 跑守护进程会在
  `runtime/` 下写出 root 属主的文件，php-fpm 之后就写不动了，表现是面板一切正常但配置怎么改都不生效。
  `service.sh` 在检测到「自己是 root、但 `runtime/` 属主不是 root」时会自动用 `setpriv`（没有就退回 `su`）降权，
  `TM_USER` 可以指定。用 `USER` 指令或 compose 的 `user:` 直接以站点属主启动容器也可以。
- **Alpine 镜像要先 `apk add bash`**，`service.sh` 是 bash 脚本。
- **swoole-cli 是全静态链接**（`static-pie`），glibc / musl 都能跑，不挑基础镜像。
- **面板上的「重启守护进程」**是让它优雅退出、等外面的人拉起来。所以它只在有 systemd、
  或守护进程是容器 1 号进程时才保证能自己回来；跑成容器里的第二个进程且没有 supervisord 托管时，
  面板会在确认框里先提醒你。

## 同一台服务器部署多套程序

互不干扰，不需要任何额外配置。

守护进程用到的东西全部按站点隔离：单例锁 `runtime/plugin/ThreadManager/daemon.lock`、状态与任务注册表、命令队列、日志、swoole-cli 二进制都在各自的站点目录下。守护进程**不监听任何端口**，也不使用 MySQL 命名锁（`GET_LOCK` 是整个 MySQL 实例级的，不分库，用了必然跨站互锁）、System V IPC 和 `/tmp`。进程间共享内存用的是 fork 继承的匿名 `Swoole\Table`，只在自己的进程树里。

唯一写到主机全局位置的是 systemd 的 unit 文件（容器模式下连这个都没有，什么都不往主机上写），名字形如：

```
/etc/systemd/system/<站点目录名>-threadmanager-<路径指纹>.service
```

指纹取自**项目根目录绝对路径**的 sha256 前 6 位。1.0.2 之前的版本只用目录名，两套程序装在同名目录里（比如 `/www/wwwroot/a.com/acgshop` 和 `/www/wwwroot/b.com/acgshop`）会算出同一个服务名，后装的直接覆盖先装的 unit —— 先装那站再执行 `start`/`restart`，启动的其实是另一个站的守护进程，而自己的面板一直显示"守护进程未运行"。

**从旧版本升级**：重新跑一次 `./service.sh install` 即可，它会自动停掉并删除旧命名的服务再装新的。判断依据是旧 unit 的 `ExecStart` 是否指向本站的 `Bin/Daemon.php`，同名但属于别的部署的服务一个字都不会动。升级前旧服务名仍然可用（`start`/`stop`/`status`/`log` 会自动回退到它），不会出现"命令突然找不到服务"的情况。

## 配置

| 配置项 | 默认 | 说明 |
|---|---|---|
| `log_level` | `info` | debug / info / warn / error |
| `tick_ms` | `250` | 调和循环周期 |
| `stop_timeout` | `20` | 优雅关闭等待秒数。改后需重新 `./service.sh install` |
| `hung_action` | `log` | 任务卡死时：`log` 只记录 / `kill` 收掉并重启 / `restart-daemon` |
| `pool_min` / `pool_max` | `1` / `6` | 每个工作进程的连接池上下限 |

**连接预算**：总连接数 = 工作进程数 × `pool_max`，工作进程数 = 各任务副本数之和。
启动时会读 MySQL 的 `max_connections`，超过 70% 直接拒绝启动。

## 面板

- **守护进程** — 运行状态、启动时间、PID、工作进程数、代数、常驻内存、运行时指纹、二进制状态
- **任务表** — 来源插件、模式、状态、副本、轮次、耗时（含走势）、重启次数、最近异常、最后运行时间，可单独启停/重启。已注册但未运行的任务同样列出
- **异常** — 按任务+消息归并计数，可清空
- **日志** — 按级别过滤、全文搜索、跟随尾部

守护进程未运行时，页面顶部给出可直接复制的安装命令。

## 卸载

停用插件会向守护进程投递 drain 命令使其优雅退出。彻底卸载先执行 `./service.sh uninstall`。
卸载插件不会删除 swoole-cli。
