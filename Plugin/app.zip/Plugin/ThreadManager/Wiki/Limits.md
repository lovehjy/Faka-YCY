# 能力边界

每个任务副本运行在独立子进程中。

## IO 并发

任务内照常写 Eloquent、`DB::`、`Redis::inst()->getRedis()`，工作进程内协程 hook 已启用，
`go()` 出去即真并发 —— 4 个协程各跑一条 `SELECT SLEEP(1)`，墙钟 1.00 秒。

curl、`file_get_contents`、`stream_*` 以及 `Swoole\Coroutine\*` 原生客户端同样适用。

## 任务隔离

| 场景 | 行为 |
|---|---|
| 任务卡死 | 可强杀。`hung_action=kill` 时先 SIGTERM 后 SIGKILL，其持有的连接与文件锁由内核回收 |
| 任务段错误 | 只影响自身，其余任务照常运行，supervisor 按重启策略拉起 |
| 任务 OOM | 同上 |

## 连接预算

总连接数 = 工作进程数 × `pool_max`。启动时读取 MySQL `max_connections`，
超过 70% 拒绝启动。面板守护进程卡片显示当前预算。

连接池同时负责：连接复用、健康检查、空闲淘汰、最大生命期、协程级租约隔离、
事务泄漏兜底回滚、归还时会话重置、跨协程误用拦截。

## `flock` 与协程

`flock` 按进程计算，同一进程内两个协程对同一文件加排他锁会**双双成功**。
影响面最大的是 `App\Model\Config::useExclusiveLock()`。

不同任务之间无此问题（各自独立进程）。仅需注意：不要在单个任务内部并发写
`Config::put*()`。

## 部署

- **systemd 与容器都支持**。`service.sh install` 自动判断：有 systemd 注册 unit，
  没有（Docker 等容器）改用脚本自带的前台/后台模式，`TM_MODE` 可强制指定。
  装卸需要 SSH（容器里是 `docker exec`），一次性操作。之后任务启停、重载、
  重启守护进程均可在面板完成 —— 插件代码中没有 `shell_exec` / `proc_open`，
  面板与守护进程通过命令文件通信。
- **容器里「重启守护进程」不一定能自己回来**。这个动作是让守护进程优雅退出、等外部拉起，
  有 systemd 或守护进程是容器 1 号进程时没问题；跑成容器里的第二个进程又没有
  supervisord / s6 托管时，退出即停机，面板会在确认框里提醒。
- **二进制不随包发布**。`swoole-cli` 122MB 且与架构相关，由 `./service.sh install` 自动下载，
  强制校验 sha256，仅允许 https，GitHub 不通时自动走镜像。面板不提供下载入口。

## 运行环境

后台面板运行在站点的 php-fpm，守护进程运行在插件自带的 `swoole-cli`
（PHP 8.4 / Swoole 6.1.7）。两者是不同的 PHP 进程与版本，排查问题时注意区分：
面板报错看 php-fpm 日志，任务报错看面板里的运行日志。
