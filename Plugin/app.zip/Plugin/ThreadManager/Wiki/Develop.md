# 接入指南

## 三条规则

**一、`#[Hook(point:)]` 必须写十六进制字面量。**

```php
#[\Kernel\Annotation\Hook(point: 0x7A100)]              // 对
#[\Kernel\Annotation\Hook(point: Hook::TASK_REGISTER)]  // 错
```

kernel 在插件启用时会对属性求值。ThreadManager 未安装时常量不存在，
求值抛 `Error`，你的插件会卡在「START 已执行、STATUS 未写入」的半启用状态。

**二、优先用 `interval` 模式。** 循环、计时、心跳、异常捕获、退避重启由 supervisor 负责，
handler 只写单轮逻辑，不要写 `while(true)`。

**三、`loop` 模式必须自己 `shouldContinue()` + `heartbeat()`。**
缺前者任务关不掉也重载不了，缺后者会被判定卡死。
`hung_action=kill` 只是兜底，强杀时任务没有收尾机会。

## 接入

两个文件。可复制的完整版见[示例代码](Example.md)。

**注册** — `Hook/Task.php`

```php
use App\Plugin\ThreadManager\Task\Task;

// 0x7A100 = \App\Plugin\ThreadManager\Consts\Hook::TASK_REGISTER
#[\Kernel\Annotation\Hook(point: 0x7A100)]
public function register(): Task
{
    return Task::make('stock-sync', SyncTask::class)->interval(30)->bootFull();
}
```

多个任务返回数组。旧写法 `register(array &$tasks): void` + `$tasks[] = [...]` 仍兼容。

**执行** — `Task/SyncTask.php`

```php
class SyncTask
{
    #[Inject] private Sync $sync;

    public function run(object $ctx): void
    {
        Commodity::query()->where('status', 1)->chunkById(200, function ($rows) use ($ctx) {
            foreach ($rows as $row) { $this->sync->one($row); }
            $ctx->heartbeat();
        });
    }
}
```

`$ctx` 声明为 `object`，不要 type-hint ThreadManager 的类 —— 这样你的插件在
ThreadManager 未安装时仍可正常安装启用。（注册钩子里 `use` 实体是安全的，
钩子不触发时方法体不会执行。）

改完到后台点「重载注册表」。

## 描述符

`Task` 实体的链式方法覆盖全部字段，下表为底层键名与校验规则。

| 字段 | 默认 | 说明 |
|---|---|---|
| `name` | 必填 | 插件内唯一 |
| `handler` | 必填 | FQCN，必须在本插件命名空间下 |
| `method` | `run` | |
| `args` | `[]` | 必须 JSON 可往返 |
| `mode` | `interval` | `interval` / `loop` / `once` / `cron` |
| `interval` | `30` | 秒 |
| `cron` | — | 五段式 |
| `delay` | `0` | 首次执行前延迟 |
| `concurrency` | `1` | 副本数，每副本一个独立子进程 |
| `enabled` | `true` | |
| `restart` | `always` | `always` / `on-failure` / `never` |
| `max_restarts` | `0` | 0 为不限 |
| `backoff` | `min=1, max=60, factor=2.0, jitter=0.2` | |
| `success_after` | `30` | 稳定运行满 N 秒重置重启计数 |
| `hung_after` | `0` | 0 = `max(3×interval, 60)` |
| `boot` | `full` | `full` / `db`（仅 Eloquent，启动更快）/ `none` |

任务 ID = `插件名:任务名`，副本后缀 `#0`、`#1`。

## `$ctx`

```php
$ctx->shouldContinue()          // loop 模式必查
$ctx->heartbeat()               // 单轮耗时长时主动续命
$ctx->log() / debug() / warn() / error()
$ctx->config()                  // 本插件配置，始终最新
$ctx->arg('channel', '默认值')
$ctx->id / plugin / name / replica
```

## 数据库与 Redis

连接池对调用方透明，照常写即可：

```php
Commodity::query()->where(...)->get();
DB::transaction(function () { ... });
\App\Plugin\Redis\Redis::inst()->getRedis();
```

连接为协程级借出、协程结束自动归还，`interval` 模式下每轮即一个租约边界。
池负责连接复用、健康检查、空闲淘汰、最大生命期、归还时会话重置、事务泄漏回滚，
以及跨协程误用连接的拦截。

唯一限制：不要把连接对象带到协程外使用，归还后再用会抛异常 ——
那一刻它可能已被其他协程借走。

## 注意事项

- **handler 不能是闭包**：描述符要写入 `registry.json` 再读回，闭包无法 JSON 往返
- **不要 `exit()`**：工作进程会直接消失，supervisor 视为异常退出并按策略重启
- **任务内 `go()` 即真并发**（Eloquent、Redis 均可），需要更多并行则加 `concurrency`
- **不要在任务内并发写 `Config::put*()`**：`flock` 在同进程的协程间不互斥；不同任务之间无此问题
