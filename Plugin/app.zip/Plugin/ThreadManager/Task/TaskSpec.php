<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Task;

final class TaskSpec
{
    public const MODE_INTERVAL = 'interval';
    public const MODE_LOOP = 'loop';
    public const MODE_ONCE = 'once';
    public const MODE_CRON = 'cron';

    public const RESTART_ALWAYS = 'always';
    public const RESTART_ON_FAILURE = 'on-failure';
    public const RESTART_NEVER = 'never';

    public const BOOT_NONE = 'none';
    public const BOOT_DB = 'db';
    public const BOOT_FULL = 'full';

    private const MODES = [self::MODE_INTERVAL, self::MODE_LOOP, self::MODE_ONCE, self::MODE_CRON];
    private const RESTARTS = [self::RESTART_ALWAYS, self::RESTART_ON_FAILURE, self::RESTART_NEVER];
    private const BOOTS = [self::BOOT_NONE, self::BOOT_DB, self::BOOT_FULL];

    public const MAX_CONCURRENCY = 16;

    public const MIN_INTERVAL = 0.05;

    public string $plugin = '';
    public string $name = '';
    public string $handler = '';
    public string $method = 'run';
    public array $args = [];

    public string $mode = self::MODE_INTERVAL;
    public float $interval = 30.0;
    public ?string $cron = null;
    public float $delay = 0.0;
    public int $concurrency = 1;

    public bool $enabled = true;
    public string $restart = self::RESTART_ALWAYS;
    public int $maxRestarts = 0;
    public float $backoffMin = 1.0;
    public float $backoffMax = 60.0;
    public float $backoffFactor = 2.0;
    public float $backoffJitter = 0.2;
    public float $successAfter = 30.0;
    public float $hungAfter = 0.0;

    public string $boot = self::BOOT_FULL;
    public bool $singleton = false;
    public int $priority = 100;

    public static function fromArray(array $raw): self
    {
        $s = new self();

        $s->handler = ltrim(trim((string)($raw['handler'] ?? '')), '\\');
        if ($s->handler === '') {
            throw new \InvalidArgumentException('handler 不能为空');
        }
        if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*(\\\\[A-Za-z_][A-Za-z0-9_]*)+$/', $s->handler)) {
            throw new \InvalidArgumentException("handler 不是合法的类名：{$s->handler}");
        }

        if (!preg_match('/^App\\\\Plugin\\\\([A-Za-z0-9_]+)\\\\/', $s->handler, $m)) {
            throw new \InvalidArgumentException("handler 必须在 App\\Plugin\\<插件名>\\ 下：{$s->handler}");
        }
        $s->plugin = $m[1];

        $s->method = trim((string)($raw['method'] ?? 'run')) ?: 'run';
        if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $s->method)) {
            throw new \InvalidArgumentException("method 不是合法的方法名：{$s->method}");
        }

        $s->name = trim((string)($raw['name'] ?? ''));
        if ($s->name === '') {
            throw new \InvalidArgumentException('name 不能为空');
        }
        if (!preg_match('/^[A-Za-z0-9._-]{1,64}$/', $s->name)) {
            throw new \InvalidArgumentException("name 只能是 1-64 位字母数字和 . _ -：{$s->name}");
        }

        $args = $raw['args'] ?? [];
        if (!is_array($args)) {
            throw new \InvalidArgumentException('args 必须是数组');
        }
        $json = json_encode($args, JSON_UNESCAPED_UNICODE);
        if ($json === false || json_decode($json, true) !== $args) {
            throw new \InvalidArgumentException('args 必须可 JSON 往返（不能含对象/闭包/资源）');
        }
        if (strlen($json) > 16384) {
            throw new \InvalidArgumentException('args 序列化后不得超过 16KB');
        }
        $s->args = $args;

        $s->mode = strtolower(trim((string)($raw['mode'] ?? self::MODE_INTERVAL)));
        if (!in_array($s->mode, self::MODES, true)) {
            throw new \InvalidArgumentException("mode 只能是 " . implode('/', self::MODES) . "：{$s->mode}");
        }

        $s->interval = (float)($raw['interval'] ?? 30);
        if ($s->mode === self::MODE_INTERVAL) {
            if (!is_finite($s->interval) || $s->interval < self::MIN_INTERVAL) {
                throw new \InvalidArgumentException(sprintf('interval 不得小于 %.2f 秒', self::MIN_INTERVAL));
            }
            if ($s->interval > 86400 * 7) {
                throw new \InvalidArgumentException('interval 超过 7 天，请改用 cron 模式');
            }
        }

        $cron = $raw['cron'] ?? null;
        $s->cron = ($cron === null || trim((string)$cron) === '') ? null : trim((string)$cron);
        if ($s->mode === self::MODE_CRON) {
            if ($s->cron === null) {
                throw new \InvalidArgumentException('mode=cron 时必须提供 cron 表达式');
            }
            if (count(preg_split('/\s+/', $s->cron) ?: []) !== 5) {
                throw new \InvalidArgumentException("cron 必须是 5 段：{$s->cron}");
            }
        }

        $s->delay = max(0.0, (float)($raw['delay'] ?? 0));

        $s->concurrency = (int)($raw['concurrency'] ?? 1);
        if ($s->concurrency < 1 || $s->concurrency > self::MAX_CONCURRENCY) {
            throw new \InvalidArgumentException('concurrency 必须在 1-' . self::MAX_CONCURRENCY . ' 之间');
        }
        if ($s->concurrency > 1 && $s->mode === self::MODE_ONCE) {
            throw new \InvalidArgumentException('mode=once 不支持多副本');
        }

        $s->enabled = self::boolOf($raw['enabled'] ?? true);

        $s->restart = strtolower(trim((string)($raw['restart'] ?? self::RESTART_ALWAYS)));
        if (!in_array($s->restart, self::RESTARTS, true)) {
            throw new \InvalidArgumentException("restart 只能是 " . implode('/', self::RESTARTS));
        }

        $s->maxRestarts = max(0, (int)($raw['max_restarts'] ?? 0));

        $bo = is_array($raw['backoff'] ?? null) ? $raw['backoff'] : [];
        $s->backoffMin = max(0.1, (float)($bo['min'] ?? 1));
        $s->backoffMax = max($s->backoffMin, (float)($bo['max'] ?? 60));
        $s->backoffFactor = max(1.0, (float)($bo['factor'] ?? 2.0));
        $s->backoffJitter = min(1.0, max(0.0, (float)($bo['jitter'] ?? 0.2)));

        $s->successAfter = max(0.0, (float)($raw['success_after'] ?? 30));
        $s->hungAfter = max(0.0, (float)($raw['hung_after'] ?? 0));

        $s->boot = strtolower(trim((string)($raw['boot'] ?? self::BOOT_FULL)));
        if (!in_array($s->boot, self::BOOTS, true)) {
            throw new \InvalidArgumentException("boot 只能是 " . implode('/', self::BOOTS));
        }

        $s->singleton = self::boolOf($raw['singleton'] ?? false);
        $s->priority = (int)($raw['priority'] ?? 100);

        return $s;
    }

    private static function boolOf(mixed $v): bool
    {
        if (is_bool($v)) return $v;
        if (is_int($v)) return $v !== 0;
        $s = strtolower(trim((string)$v));
        return !in_array($s, ['', '0', 'false', 'no', 'off'], true);
    }

    public function id(): string
    {
        return $this->plugin . ':' . $this->name;
    }

    public function replicaId(int $replica): string
    {
        return $this->id() . '#' . $replica;
    }

    public function hash(): string
    {
        return substr(hash('sha256', json_encode($this->toArray(), JSON_UNESCAPED_UNICODE) ?: ''), 0, 16);
    }

    public function hungThreshold(): float
    {
        if ($this->hungAfter > 0) {
            return $this->hungAfter;
        }
        return max(60.0, $this->interval * 3);
    }

    public function toArray(): array
    {
        return [
            'plugin' => $this->plugin,
            'name' => $this->name,
            'handler' => $this->handler,
            'method' => $this->method,
            'args' => $this->args,
            'mode' => $this->mode,
            'interval' => $this->interval,
            'cron' => $this->cron,
            'delay' => $this->delay,
            'concurrency' => $this->concurrency,
            'enabled' => $this->enabled,
            'restart' => $this->restart,
            'max_restarts' => $this->maxRestarts,
            'backoff' => [
                'min' => $this->backoffMin,
                'max' => $this->backoffMax,
                'factor' => $this->backoffFactor,
                'jitter' => $this->backoffJitter,
            ],
            'success_after' => $this->successAfter,
            'hung_after' => $this->hungAfter,
            'boot' => $this->boot,
            'singleton' => $this->singleton,
            'priority' => $this->priority,
        ];
    }

    public function toJson(): string
    {
        return (string)json_encode($this->toArray(), JSON_UNESCAPED_UNICODE);
    }

    public static function fromJson(string $json): self
    {
        $raw = json_decode($json, true);
        if (!is_array($raw)) {
            throw new \InvalidArgumentException('描述符 JSON 无法解析');
        }
        return self::fromArray($raw);
    }
}
