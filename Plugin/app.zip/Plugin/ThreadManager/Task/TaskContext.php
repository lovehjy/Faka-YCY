<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Task;

use App\Plugin\ThreadManager\Service\Log;

final class TaskContext
{

    private $continueFn;

    private $heartbeatFn;

    public function __construct(
        public string $id,
        public string $plugin,
        public string $name,
        public int $replica,
        public array $args,
        callable $continueFn,
        callable $heartbeatFn,
    ) {
        $this->continueFn = $continueFn;
        $this->heartbeatFn = $heartbeatFn;
    }

    public function shouldContinue(): bool
    {
        return (bool)($this->continueFn)();
    }

    public function heartbeat(): void
    {
        ($this->heartbeatFn)();
    }

    public function log(string $msg, array $ctx = []): void  { Log::info($msg, $ctx); }
    public function debug(string $msg, array $ctx = []): void { Log::debug($msg, $ctx); }
    public function warn(string $msg, array $ctx = []): void  { Log::warn($msg, $ctx); }
    public function error(string $msg, array $ctx = []): void { Log::error($msg, $ctx); }

    public function config(): array
    {
        return \App\Util\Plugin::getConfig($this->plugin, false);
    }

    public function arg(string $key, mixed $default = null): mixed
    {
        return $this->args[$key] ?? $default;
    }
}
