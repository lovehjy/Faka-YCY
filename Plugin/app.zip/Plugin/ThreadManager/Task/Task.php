<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Task;

final class Task
{
    private array $d = [];

    private function __construct(string $name, string $handler)
    {
        $this->d['name'] = $name;
        $this->d['handler'] = $handler;
    }

    public static function make(string $name, string $handler): self
    {
        return new self($name, $handler);
    }

    public function method(string $method): self
    {
        $this->d['method'] = $method;
        return $this;
    }

    public function args(array $args): self
    {
        $this->d['args'] = $args;
        return $this;
    }

    public function interval(float $seconds): self
    {
        $this->d['mode'] = TaskSpec::MODE_INTERVAL;
        $this->d['interval'] = $seconds;
        return $this;
    }

    public function cron(string $expression): self
    {
        $this->d['mode'] = TaskSpec::MODE_CRON;
        $this->d['cron'] = $expression;
        return $this;
    }

    public function loop(): self
    {
        $this->d['mode'] = TaskSpec::MODE_LOOP;
        return $this;
    }

    public function once(): self
    {
        $this->d['mode'] = TaskSpec::MODE_ONCE;
        return $this;
    }

    public function delay(float $seconds): self
    {
        $this->d['delay'] = $seconds;
        return $this;
    }

    public function concurrency(int $n): self
    {
        $this->d['concurrency'] = $n;
        return $this;
    }

    public function disabled(): self
    {
        $this->d['enabled'] = false;
        return $this;
    }

    public function restartAlways(): self
    {
        $this->d['restart'] = TaskSpec::RESTART_ALWAYS;
        return $this;
    }

    public function restartOnFailure(): self
    {
        $this->d['restart'] = TaskSpec::RESTART_ON_FAILURE;
        return $this;
    }

    public function restartNever(): self
    {
        $this->d['restart'] = TaskSpec::RESTART_NEVER;
        return $this;
    }

    public function maxRestarts(int $n): self
    {
        $this->d['max_restarts'] = $n;
        return $this;
    }

    public function backoff(float $min, float $max, float $factor = 2.0, float $jitter = 0.2): self
    {
        $this->d['backoff'] = ['min' => $min, 'max' => $max, 'factor' => $factor, 'jitter' => $jitter];
        return $this;
    }

    public function successAfter(float $seconds): self
    {
        $this->d['success_after'] = $seconds;
        return $this;
    }

    public function hungAfter(float $seconds): self
    {
        $this->d['hung_after'] = $seconds;
        return $this;
    }

    public function bootFull(): self
    {
        $this->d['boot'] = TaskSpec::BOOT_FULL;
        return $this;
    }

    public function bootDb(): self
    {
        $this->d['boot'] = TaskSpec::BOOT_DB;
        return $this;
    }

    public function bootNone(): self
    {
        $this->d['boot'] = TaskSpec::BOOT_NONE;
        return $this;
    }

    public function priority(int $p): self
    {
        $this->d['priority'] = $p;
        return $this;
    }

    public function raw(string $key, mixed $value): self
    {
        $this->d[$key] = $value;
        return $this;
    }

    public function toArray(): array
    {
        return $this->d;
    }
}
