<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Task;

use Kernel\Container\Di;

final class Invoker
{
    private ?object $instance = null;
    private ?\ReflectionMethod $method = null;
    private int $arity = 0;

    public function __construct(private TaskSpec $spec) {}

    public function prepare(): void
    {
        if ($this->instance !== null) {
            return;
        }

        $class = $this->spec->handler;
        if (!class_exists($class)) {
            throw new \RuntimeException("handler 类不存在：{$class}（插件是否已安装？）");
        }

        $rc = new \ReflectionClass($class);
        if ($rc->isAbstract() || $rc->isInterface()) {
            throw new \RuntimeException("handler 不能是抽象类或接口：{$class}");
        }
        $ctor = $rc->getConstructor();
        if ($ctor !== null && $ctor->getNumberOfRequiredParameters() > 0) {

            throw new \RuntimeException("handler 的构造器不能有必填参数：{$class}（依赖请用 #[Inject] 属性注入）");
        }

        if (!$rc->hasMethod($this->spec->method)) {
            throw new \RuntimeException("handler 没有方法 {$this->spec->method}()：{$class}");
        }
        $rm = $rc->getMethod($this->spec->method);
        if (!$rm->isPublic() || $rm->isStatic() || $rm->isAbstract()) {
            throw new \RuntimeException("{$class}::{$this->spec->method}() 必须是 public 非静态方法");
        }
        if ($rm->getNumberOfRequiredParameters() > 1) {
            throw new \RuntimeException("{$class}::{$this->spec->method}() 最多接受一个参数（TaskContext）");
        }

        $obj = $rc->newInstance();
        Di::inst()->inject($obj);

        $this->instance = $obj;
        $this->method = $rm;
        $this->arity = $rm->getNumberOfParameters();
    }

    public function call(TaskContext $ctx): void
    {
        $this->prepare();

        $this->arity > 0
            ? $this->method->invoke($this->instance, $ctx)
            : $this->method->invoke($this->instance);
    }

    public function reset(): void
    {
        $this->instance = null;
        $this->method = null;
    }
}
