<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Task;

use App\Plugin\ThreadManager\Consts\Hook as TmHook;
use App\Plugin\ThreadManager\Service\Log;
use App\Plugin\ThreadManager\Service\Paths;

final class Registry
{

    public static function collect(): array
    {
        $tasks = [];
        $errors = [];

        $pushed = [];
        $returned = null;
        try {
            $returned = hook(TmHook::TASK_REGISTER, $pushed);
        } catch (\Throwable $e) {
            $errors[] = '注册钩子派发失败：' . $e->getMessage();
            Log::exception($e, '[registry]');
            return ['tasks' => [], 'errors' => $errors];
        }

        $raw = array_merge(
            self::flatten($returned),
            is_array($pushed) ? $pushed : []
        );

        $enabledPlugins = self::enabledPlugins();

        foreach ($raw as $i => $item) {

            if ($item instanceof Task) {
                $item = $item->toArray();
            }
            if (!is_array($item)) {
                $errors[] = "第 {$i} 项既不是 Task 实体也不是数组（" . get_debug_type($item) . "），忽略";
                continue;
            }
            try {
                $spec = TaskSpec::fromArray($item);
            } catch (\Throwable $e) {
                $errors[] = "第 {$i} 项非法：" . $e->getMessage();
                continue;
            }

            if (!isset($enabledPlugins[$spec->plugin])) {
                $errors[] = "{$spec->id()}：插件 {$spec->plugin} 未安装或未启用，跳过";
                continue;
            }

            $id = $spec->id();
            if (isset($tasks[$id])) {
                $errors[] = "{$id}：任务名重复，后一条被忽略";
                continue;
            }
            $tasks[$id] = $spec;
        }

        uasort($tasks, static fn(TaskSpec $a, TaskSpec $b) => [$a->priority, $a->id()] <=> [$b->priority, $b->id()]);

        return ['tasks' => $tasks, 'errors' => $errors];
    }

    private static function flatten(mixed $returned): array
    {
        if ($returned instanceof Task) {
            return [$returned];
        }
        if (!is_array($returned)) {
            return [];
        }

        $out = [];
        foreach ($returned as $item) {
            if ($item instanceof Task) {
                $out[] = $item;
                continue;
            }
            if (!is_array($item)) {
                continue;
            }

            if (self::isTaskList($item)) {
                foreach ($item as $sub) {
                    $out[] = $sub;
                }
                continue;
            }

            $out[] = $item;
        }
        return $out;
    }

    private static function isTaskList(array $item): bool
    {
        if ($item === []) {
            return true;
        }
        if (isset($item['name']) || isset($item['handler'])) {
            return false;
        }
        foreach ($item as $v) {
            if ($v instanceof Task || is_array($v)) {
                return true;
            }
        }
        return false;
    }

    private static function enabledPlugins(): array
    {
        $out = [];
        $dir = Paths::base() . 'app/Plugin/';
        foreach (@scandir($dir) ?: [] as $name) {
            if ($name === '.' || $name === '..' || !is_dir($dir . $name)) {
                continue;
            }
            if (!is_file($dir . $name . '/Config/Info.php')) {
                continue;
            }
            try {
                $cfg = \App\Util\Plugin::getConfig($name, false);
                if ((string)($cfg['STATUS'] ?? '0') === '1') {
                    $out[$name] = true;
                }
            } catch (\Throwable $e) {
            }
        }
        return $out;
    }

    public static function collectAndWrite(): array
    {
        $r = self::collect();

        $payload = [
            'v' => 1,
            'ts' => microtime(true),
            'tasks' => array_map(static fn(TaskSpec $s) => $s->toArray() + ['id' => $s->id(), 'hash' => $s->hash()], $r['tasks']),
            'errors' => $r['errors'],
        ];

        self::atomicWrite(Paths::registry(), (string)json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        Log::info('任务注册表已收集', ['tasks' => count($r['tasks']), 'errors' => count($r['errors'])]);
        foreach ($r['errors'] as $e) {
            Log::warn('注册表告警：' . $e);
        }
        return $payload;
    }

    public static function read(): array
    {
        $f = Paths::registry();
        if (!is_file($f)) {
            return ['v' => 1, 'ts' => 0, 'tasks' => [], 'errors' => []];
        }
        $d = json_decode((string)@file_get_contents($f), true);
        return is_array($d) ? $d : ['v' => 1, 'ts' => 0, 'tasks' => [], 'errors' => []];
    }

    public static function atomicWrite(string $path, string $content): bool
    {
        $tmp = $path . '.' . getmypid() . '.tmp';
        if (@file_put_contents($tmp, $content) === false) {
            return false;
        }
        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            return false;
        }
        return true;
    }
}
