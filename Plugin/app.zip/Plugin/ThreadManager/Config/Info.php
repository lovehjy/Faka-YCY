<?php
declare(strict_types=1);

use App\Consts\Plugin;

return [
    Plugin::NAME => '线程管理器',
    Plugin::AUTHOR => '荔枝',
    Plugin::WEB_SITE => '#',
    Plugin::DESCRIPTION => '给其他插件提供常驻任务运行能力，注册进来的任务由它统一调度、监管和崩溃重启，并提供数据库与 Redis 连接池。启动后点这里进行初始化 → <a href="/plugin/ThreadManager/panel/index" target="_blank" style="color:#5b7cfa;font-weight:600;text-decoration:none;"><i class="fa-duotone fa-regular fa-diagram-project"></i> 线程管理</a>',
    Plugin::VERSION => '1.0.8'
];
