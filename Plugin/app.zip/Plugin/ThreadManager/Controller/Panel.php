<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Controller;

use App\Controller\Base\View\ManagePlugin;
use App\Interceptor\ManageSession;
use Kernel\Annotation\Interceptor;
use Kernel\Exception\ViewException;

#[Interceptor(ManageSession::class, Interceptor::TYPE_VIEW)]
class Panel extends ManagePlugin
{

    public function index(): string
    {

        return $this->render("线程管理器", "Panel/Index.html", [], true);
    }
}
