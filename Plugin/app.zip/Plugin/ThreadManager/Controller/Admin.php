<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Controller;

use App\Controller\Base\API\ManagePlugin;
use App\Interceptor\ManageSession;
use App\Interceptor\Waf;
use App\Plugin\ThreadManager\Service\Binary;
use App\Plugin\ThreadManager\Service\Env;
use App\Plugin\ThreadManager\Service\Log;
use App\Plugin\ThreadManager\Service\Paths;
use App\Plugin\ThreadManager\Supervisor\Commands;
use App\Plugin\ThreadManager\Supervisor\Status;
use App\Plugin\ThreadManager\Task\Registry;
use Kernel\Annotation\Interceptor;
use Kernel\Exception\JSONException;

#[Interceptor([Waf::class, ManageSession::class], Interceptor::TYPE_API)]
class Admin extends ManagePlugin
{

    public function status(): array
    {
        $status = Status::read();
        $registry = Registry::read();

        $tickMs = (int)($status['daemon']['tick_ms'] ?? 250);
        $age = $status === null ? null : (microtime(true) - (float)$status['ts']);

        $stale = $status === null || $age > (3 * $tickMs / 1000 + 2);

        $tasks = [];

        //插件的中文名只在 Info.php 里，注册表里存的是目录名（AutoDock 这种）。
        //按需取、取过就记住：一次轮询里同一个插件往往注册了好几个任务。
        $pluginNames = [];
        $pluginName = static function (string $key) use (&$pluginNames): string {
            if ($key === '') {
                return '';
            }
            if (!array_key_exists($key, $pluginNames)) {
                $pluginNames[$key] = '';
                try {
                    $info = \Kernel\Util\Plugin::getPlugin($key);
                    $pluginNames[$key] = (string)($info[\App\Consts\Plugin::NAME] ?? '');
                } catch (\Throwable $e) {
                }
            }
            return $pluginNames[$key];
        };

        foreach ($registry['tasks'] ?? [] as $t) {
            $id = (string)($t['id'] ?? ($t['plugin'] ?? '') . ':' . ($t['name'] ?? ''));
            $tasks[$id] = [
                'id' => $id,
                'plugin' => $t['plugin'] ?? '',
                'plugin_name' => $pluginName((string)($t['plugin'] ?? '')),
                'name' => $t['name'] ?? '',
                'mode' => $t['mode'] ?? 'interval',
                'interval' => $t['interval'] ?? null,
                'cron' => $t['cron'] ?? null,
                'boot' => $t['boot'] ?? 'full',
                'enabled' => (bool)($t['enabled'] ?? true),
                'concurrency' => (int)($t['concurrency'] ?? 1),
                'state' => ($t['enabled'] ?? true) ? 'pending' : 'disabled',
                'replicas' => [],
                'replicas_running' => 0,
                'restarts' => 0,
                'last_error' => null,
                'last_error_ts' => 0,
                'registered' => true,
            ];
        }

        if (!$stale) {
            foreach ($status['tasks'] ?? [] as $id => $t) {
                $tasks[$id] = array_merge($tasks[$id] ?? ['registered' => false], $t, ['registered' => true]);
            }
        } else {

            foreach ($tasks as $id => $t) {
                $tasks[$id]['state'] = $t['enabled'] ? 'daemon-down' : 'disabled';
                $tasks[$id]['replicas_running'] = 0;
            }
        }

        ksort($tasks);

        return $this->json(data: [
            'stale' => $stale,
            'age' => $age,
            'daemon' => $status['daemon'] ?? null,
            'pid' => $status['pid'] ?? null,
            'boot_ts' => $status['boot_ts'] ?? null,
            'uptime' => $status['uptime'] ?? null,
            'ts' => $status['ts'] ?? null,
            'tasks' => array_values($tasks),
            'errors' => $status['errors'] ?? [],
            'commands' => $status['commands'] ?? [],
            'registry_ts' => $registry['ts'] ?? 0,
            'registry_errors' => $registry['errors'] ?? [],

            'binary' => Binary::status(),
            'binary_present' => is_file(Paths::binary()) && is_executable(Paths::binary()),
            'binary_path' => Paths::binary(),

            //面板这一侧的环境（php-fpm 所在的机器/容器），决定安装命令怎么给。
            //守护进程自己那一侧的环境在 daemon.env 里 —— 两者可以不是同一个容器。
            'env' => Env::snapshot(),
            'install_hint' => $this->installHint(),
        ]);
    }

    public function logs(): array
    {
        $lines = (int)($_POST['lines'] ?? 300);
        $lines = max(20, min(2000, $lines));
        $level = (string)($_POST['level'] ?? '');
        $scope = (string)($_POST['scope'] ?? '');

        return $this->json(data: [
            'lines' => Log::tail($lines, $level, $scope),
            'file' => Paths::log(),
            'size' => is_file(Paths::log()) ? filesize(Paths::log()) : 0,
        ]);
    }

    public function clearLog(): array
    {
        $file = Paths::log();
        if (is_file($file) && @file_put_contents($file, '') === false) {
            throw new JSONException('清空失败，请检查 runtime.log 的写入权限');
        }
        return $this->json(200, '日志已清空');
    }

    public function command(): array
    {
        $op = (string)($_POST['op'] ?? '');
        $task = (string)($_POST['task'] ?? '');

        if (!in_array($op, Commands::OPS, true)) {
            throw new JSONException('不支持的操作');
        }
        if (in_array($op, ['start', 'stop', 'restart'], true) && trim($task) === '') {
            throw new JSONException('该操作需要指定任务');
        }

        $status = Status::read();
        if ($status === null) {
            throw new JSONException('守护进程未运行，命令无人处理。请先在服务器上启动它。');
        }

        $manage = $this->getManage();
        $payload = Commands::submit($op, $task, 'admin:' . ($manage->id ?? '?'));

        return $this->json(200, '命令已下发', $payload);
    }

    public function reload(): array
    {
        @touch(Paths::reloadSentinel());
        return $this->json(200, '已请求重新收集注册表');
    }

    public function verifyBinary(): array
    {
        $r = Binary::verify();
        if (!$r['ok']) {
            throw new JSONException($r['reason']);
        }
        return $this->json(200, $r['reason'], $r);
    }

    public function fixBinaryPermission(): array
    {
        if (!is_file(Paths::binary())) {
            throw new JSONException('二进制不存在，请先下载或上传 swoole-cli');
        }
        if (!Binary::ensureExecutable()) {
            throw new JSONException('chmod 失败，请在服务器上执行：chmod +x ' . Paths::binary());
        }
        return $this->json(200, '已补上可执行权限');
    }

    private function installHint(): array
    {
        //realpath 规整掉 BASE_PATH 里的 kernel/.. 。
        $root = realpath(Paths::base()) ?: rtrim(Paths::base(), '/');
        $sh = './app/Plugin/ThreadManager/service.sh';

        //一行搞定：cd 站点根 + 赋权 + install。install 会先下载 swoole-cli，
        //再按环境分叉：有 systemd 就注册 unit，没有（Docker 等容器）就直接把守护进程
        //拉起来，并打印用容器托管它的两种写法。
        $cmd = ['cd ' . $root . ' && chmod +x ' . $sh . ' && ' . $sh . ' install'];

        //容器里这条命令得在站点所在的容器内跑，不是在宿主机上 —— 不写清楚必然有人跑错地方。
        //判据用 inContainer() 而不是 installMode()：非 systemd 的裸机（openrc / runit）
        //同样走容器模式，但对它说「去容器里执行」是错的。
        if (Env::inContainer()) {
            array_unshift($cmd, '# 请在站点所在的容器里执行：docker exec -it <容器名> bash');
        }

        return $cmd;
    }
}
