<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Supervisor;

use App\Plugin\ThreadManager\Service\Log;
use App\Plugin\ThreadManager\Service\Paths;

final class Commands
{
    public const OPS = [
        'start', 'stop', 'restart', 'reload', 'drain', 'restart-daemon', 'clear-errors',
    ];

    public static function submit(string $op, string $task = '', string $actor = 'admin'): array
    {
        $op = strtolower(trim($op));
        if (!in_array($op, self::OPS, true)) {
            throw new \InvalidArgumentException('未知操作：' . $op);
        }
        $id = bin2hex(random_bytes(10));
        $payload = [
            'id' => $id,
            'ts' => time(),
            'op' => $op,
            'task' => trim($task),
            'actor' => $actor,
        ];
        $file = Paths::commands() . $id . '.json';
        @file_put_contents($file, json_encode($payload, JSON_UNESCAPED_UNICODE));
        @chmod($file, 0600);
        return $payload;
    }

    public static function poll(array $knownTasks): array
    {
        $dir = Paths::commands();
        $out = [];

        foreach (glob($dir . '*.json') ?: [] as $file) {
            $raw = (string)@file_get_contents($file);
            @unlink($file);

            if (strlen($raw) > 4096) {
                Log::warn('命令文件过大，已忽略', ['file' => basename($file)]);
                continue;
            }
            $d = json_decode($raw, true);
            if (!is_array($d)) {
                Log::warn('命令文件不是合法 JSON，已忽略', ['file' => basename($file)]);
                continue;
            }

            $op = strtolower(trim((string)($d['op'] ?? '')));
            if (!in_array($op, self::OPS, true)) {
                Log::warn('命令 op 不在白名单内，已忽略', ['op' => $op]);
                continue;
            }

            $task = trim((string)($d['task'] ?? ''));

            if ($task !== '' && !isset($knownTasks[$task])) {
                Log::warn('命令指向未知任务，已忽略', ['op' => $op, 'task' => $task]);
                continue;
            }
            if ($task === '' && in_array($op, ['start', 'stop', 'restart'], true)) {
                Log::warn('任务级命令缺少 task 字段，已忽略', ['op' => $op]);
                continue;
            }

            $out[] = [
                'id' => substr((string)($d['id'] ?? ''), 0, 32),
                'ts' => (int)($d['ts'] ?? time()),
                'op' => $op,
                'task' => $task,
                'actor' => substr((string)($d['actor'] ?? 'unknown'), 0, 64),
            ];
        }

        usort($out, static fn($a, $b) => $a['ts'] <=> $b['ts']);
        return $out;
    }

    public static function flush(): int
    {
        $n = 0;
        foreach (glob(Paths::commands() . '*.json') ?: [] as $f) {
            @unlink($f);
            $n++;
        }
        return $n;
    }
}
