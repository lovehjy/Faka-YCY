<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Supervisor;

use App\Plugin\ThreadManager\Service\Paths;

final class ConfigWatcher
{
    private string $last = '';

    public function __construct(private float $interval = 1.0)
    {
    }

    private float $checkedAt = 0.0;

    public function changed(): bool
    {
        $now = microtime(true);
        if ($now - $this->checkedAt < $this->interval) {
            return false;
        }
        $this->checkedAt = $now;

        $sig = $this->signature();
        if ($this->last === '') {
            $this->last = $sig;
            return false;
        }
        if ($sig === $this->last) {
            return false;
        }
        $this->last = $sig;
        return true;
    }

    public function rebase(): void
    {
        $this->last = $this->signature();
    }

    private function signature(): string
    {
        $parts = [];

        $hook = Paths::base() . 'runtime/plugin/hook';
        $parts[] = 'hook:' . (is_file($hook) ? filemtime($hook) . ':' . filesize($hook) : '0');

        foreach (glob(Paths::base() . 'app/Plugin/*/Config/Config.php') ?: [] as $f) {
            $parts[] = basename(dirname(dirname($f))) . ':' . @filemtime($f);
        }

        $sentinel = Paths::reloadSentinel();
        $parts[] = 'reload:' . (is_file($sentinel) ? @filemtime($sentinel) : '0');

        return md5(implode('|', $parts));
    }
}
