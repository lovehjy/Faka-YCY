<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Supervisor\Shared;

use Swoole\Atomic;
use Swoole\Table;

final class ProcessShared implements SharedState
{

    private const STATE_ROWS = 1024;

    private const STATE_BYTES = 8192;

    private const EVENT_SLOTS = 256;
    private const EVENT_BYTES = 4096;

    private Table $state;
    private Table $events;
    private Atomic $runningFlag;
    private Atomic\Long $generationCounter;

    private Atomic\Long $eventSeq;

    private int $eventRead = 0;

    public function __construct()
    {
        $this->state = new Table(self::STATE_ROWS);
        $this->state->column('json', Table::TYPE_STRING, self::STATE_BYTES);
        $this->state->create();

        $this->events = new Table(self::EVENT_SLOTS * 2);
        $this->events->column('json', Table::TYPE_STRING, self::EVENT_BYTES);
        $this->events->create();

        $this->runningFlag = new Atomic(1);
        $this->generationCounter = new Atomic\Long(1);
        $this->eventSeq = new Atomic\Long(0);
    }

    public function running(): bool { return $this->runningFlag->get() === 1; }

    public function setRunning(bool $v): void { $this->runningFlag->set($v ? 1 : 0); }

    public function generation(): int { return (int)$this->generationCounter->get(); }

    public function bumpGeneration(): int { return (int)$this->generationCounter->add(1); }

    public function taskState(string $replicaId): ?array
    {
        $row = $this->state->get($replicaId);
        if (!is_array($row) || !isset($row['json']) || $row['json'] === '') {
            return null;
        }
        $d = json_decode((string)$row['json'], true);
        return is_array($d) ? $d : null;
    }

    public function allTaskStates(): array
    {
        $out = [];
        foreach ($this->state as $k => $row) {
            $d = json_decode((string)($row['json'] ?? ''), true);
            if (is_array($d)) {
                $out[(string)$k] = $d;
            }
        }
        return $out;
    }

    public function forgetTask(string $replicaId): void
    {
        $this->state->del($replicaId);
    }

    public function putTaskState(string $replicaId, array $state): void
    {
        $this->state->set($replicaId, ['json' => self::encode($state, self::STATE_BYTES)]);
    }

    public function pushEvent(array $event): void
    {

        $seq = (int)$this->eventSeq->add(1);
        $this->events->set((string)($seq % self::EVENT_SLOTS), [
            'json' => self::encode(['seq' => $seq] + $event, self::EVENT_BYTES),
        ]);
    }

    public function drainEvents(int $max = 200): array
    {
        $head = (int)$this->eventSeq->get();
        if ($head <= $this->eventRead) {
            return [];
        }

        $from = max($this->eventRead, $head - self::EVENT_SLOTS);
        $out = [];
        for ($seq = $from + 1; $seq <= $head && count($out) < $max; $seq++) {
            $row = $this->events->get((string)($seq % self::EVENT_SLOTS));
            if (!is_array($row)) {
                continue;
            }
            $d = json_decode((string)($row['json'] ?? ''), true);

            if (is_array($d) && (int)($d['seq'] ?? -1) === $seq) {
                $out[] = $d;
            }
        }
        $this->eventRead = $head;
        return $out;
    }

    private static function encode(array $data, int $limit): string
    {
        $json = (string)json_encode($data, JSON_UNESCAPED_UNICODE);
        if (strlen($json) <= $limit) {
            return $json;
        }
        if (isset($data['err']) && is_string($data['err'])) {
            $over = strlen($json) - $limit;
            $keep = max(0, strlen($data['err']) - $over - 64);
            $data['err'] = substr($data['err'], 0, $keep) . '…(已截断)';
        }
        $json = (string)json_encode($data, JSON_UNESCAPED_UNICODE);
        return strlen($json) <= $limit ? $json : substr($json, 0, $limit);
    }
}
