<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Supervisor\Shared;

interface SharedState
{

    public function running(): bool;
    public function setRunning(bool $v): void;

    public function generation(): int;
    public function bumpGeneration(): int;

    public function taskState(string $replicaId): ?array;

    public function allTaskStates(): array;

    public function forgetTask(string $replicaId): void;

    public function putTaskState(string $replicaId, array $state): void;

    public function pushEvent(array $event): void;

    public function drainEvents(int $max = 200): array;
}
