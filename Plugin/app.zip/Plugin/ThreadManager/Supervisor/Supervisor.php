<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Supervisor;

use App\Plugin\ThreadManager\Runtime\Runner;
use App\Plugin\ThreadManager\Service\Log;
use App\Plugin\ThreadManager\Service\Paths;
use App\Plugin\ThreadManager\Supervisor\Shared\SharedState;
use App\Plugin\ThreadManager\Task\Registry;
use App\Plugin\ThreadManager\Task\TaskSpec;
use Swoole\Process;

final class Supervisor
{

    private array $specs = [];

    private array $workers = [];

    private array $backoffs = [];

    private array $states = [];

    private array $manuallyStopped = [];

    private int $killedCount = 0;
    private float $bootTs;
    private Status $status;
    private Signals $signals;
    private ConfigWatcher $watcher;

    public function __construct(
        private SharedState $shared,
        private array $config = [],
    ) {
        $this->bootTs = microtime(true);
        $this->status = new Status($this->bootTs);
        $this->signals = new Signals();
        $this->watcher = new ConfigWatcher();
    }

    private function tickUs(): int
    {
        return max(50, (int)($this->config['tick_ms'] ?? 250)) * 1000;
    }

    private function hungAction(): string
    {
        return (string)($this->config['hung_action'] ?? 'log');
    }

    public function run(): int
    {
        $this->signals->install();
        Commands::flush();

        Log::info('守护进程启动', [
            'pid' => getmypid(),
            'php' => PHP_VERSION,
            'swoole' => swoole_version(),
            'zts' => ZEND_THREAD_SAFE,
        ]);

        $this->refreshRegistry('启动');
        $this->watcher->rebase();

        $lastPublishedSignature = '';

        while ($this->shared->running() && !$this->signals->stopRequested()) {

            $this->signals->dispatch();
            $this->drainEvents();
            $this->reap();
            $this->detectHung();
            $this->enforceKills();
            $this->pollCommands();

            if ($this->signals->takeReloadRequest() || $this->watcher->changed()) {
                $this->reload('配置或注册表变化');
            }

            $this->reconcile();

            $view = $this->buildTaskView();
            $sig = md5((string)json_encode(array_map(
                static fn($t) => [$t['state'], $t['restarts'], $t['replicas_running']],
                $view
            )));
            $this->status->publish($this->daemonView(), $view, $sig !== $lastPublishedSignature);
            $lastPublishedSignature = $sig;

            usleep($this->tickUs());
        }

        return $this->shutdown();
    }

    private function refreshRegistry(string $why): void
    {
        Log::info('收集任务注册表', ['reason' => $why]);
        try {
            $p = new Process(static function (): void {
                \App\Plugin\ThreadManager\Runtime\WorkerEntry::runRegistry();
            }, false, 0, false);
            $pid = $p->start();
            if ($pid !== false) {
                $this->waitFor((int)$pid, 60.0);
            }
        } catch (\Throwable $e) {
            Log::exception($e, '[registry-process]');
        }

        $payload = Registry::read();
        $specs = [];
        foreach ($payload['tasks'] ?? [] as $raw) {
            try {
                $spec = TaskSpec::fromArray($raw);
                $specs[$spec->id()] = $spec;
            } catch (\Throwable $e) {
                Log::warn('注册表里有非法条目：' . $e->getMessage());
            }
        }
        $this->specs = $specs;

        foreach ($payload['errors'] ?? [] as $err) {
            $this->status->pushError(['ts' => microtime(true), 'task' => '', 'msg' => (string)$err]);
        }

        Log::info('注册表就绪', ['tasks' => count($this->specs)]);
    }

    private function waitFor(int $pid, float $timeout): void
    {
        if (!function_exists('pcntl_waitpid')) {
            return;
        }
        $deadline = microtime(true) + $timeout;
        while (microtime(true) < $deadline) {
            $st = 0;
            $r = pcntl_waitpid($pid, $st, WNOHANG);
            if ($r === $pid || $r === -1) {
                return;
            }
            usleep(20_000);
        }
        Log::error('注册表进程超时未结束，强杀', ['pid' => $pid]);
        @Process::kill($pid, SIGKILL);
        @pcntl_waitpid($pid, $st);
    }

    private function reload(string $why): void
    {
        $gen = $this->shared->bumpGeneration();
        Log::info('热重载', ['gen' => $gen, 'reason' => $why]);
        $this->refreshRegistry($why);
        $this->watcher->rebase();
    }

    private function reconcile(): void
    {
        $gen = $this->shared->generation();
        $wanted = [];

        foreach ($this->specs as $id => $spec) {
            if (!$spec->enabled || isset($this->manuallyStopped[$id])) {
                continue;
            }
            for ($i = 0; $i < $spec->concurrency; $i++) {
                $rid = $spec->replicaId($i);
                $wanted[$rid] = [$spec, $i];
            }
        }

        foreach ($this->workers as $rid => $h) {
            if (!isset($wanted[$rid])) {
                if (!$h->alive()) {
                    unset($this->workers[$rid]);
                    $this->shared->forgetTask($rid);
                }
            }
        }

        foreach ($wanted as $rid => [$spec, $i]) {
            if (isset($this->workers[$rid]) && $this->workers[$rid]->alive()) {
                continue;
            }
            if (isset($this->workers[$rid])) {
                continue;
            }

            $bo = $this->backoffs[$rid] ??= new Backoff($spec);
            if ($bo->exhausted()) {
                $this->states[$rid] = 'failed';
                continue;
            }
            if (!$bo->ready()) {
                $this->states[$rid] = 'backoff';
                continue;
            }

            try {
                $this->workers[$rid] = new ProcessHandle($spec, $i, $gen, $this->shared);
                $this->states[$rid] = 'running';
                Log::info('任务已启动', ['task' => $rid, 'gen' => $gen, 'attempt' => $bo->attempt()]);
            } catch (\Throwable $e) {
                Log::exception($e, '[spawn]');
                $this->status->pushError([
                    'ts' => microtime(true), 'task' => $rid,
                    'msg' => '启动工作进程失败：' . $e->getMessage(),
                ]);
                $bo->fail();
                $this->states[$rid] = 'backoff';
            }
        }
    }

    private function harvest(): void
    {
        while (($st = Process::wait(false)) !== false) {
            $pid = (int)($st['pid'] ?? 0);
            $found = null;
            foreach ($this->workers as $rid => $h) {
                if ($h->pid === $pid) {
                    $found = $rid;
                    break;
                }
            }
            if ($found === null) {

                continue;
            }
            $this->workers[$found]->markReaped($st);
        }

        foreach ($this->workers as $rid => $h) {
            if (!$h->reaped() && !$h->alive()) {
                Log::warn('工作进程丢失，按异常退出处理', ['task' => $rid, 'pid' => $h->pid]);
                $h->markReaped(['pid' => $h->pid, 'code' => 1, 'signal' => 0]);
            }
        }
    }

    private function reap(): void
    {
        $this->harvest();

        foreach ($this->workers as $rid => $h) {
            if (!$h->reaped()) {
                continue;
            }

            $st = $this->shared->taskState($rid);
            $exit = (string)($st['exit'] ?? Runner::EXIT_ERROR);
            $err = $st['err'] ?? null;

            if ($h->killedBySignal()) {
                $sig = (int)($h->exitStatus()['signal'] ?? 0);
                $exit = Runner::EXIT_ERROR;
                $err = $sig === SIGKILL
                    ? '进程被强制终止（SIGKILL，多半是判定卡死后由监管层收掉的）'
                    : "进程被信号 {$sig} 终止";
            }

            $uptime = $h->uptime();
            $spec = $this->specs[$h->spec->id()] ?? $h->spec;
            $bo = $this->backoffs[$rid] ??= new Backoff($spec);

            unset($this->workers[$rid]);

            $reloadDriven = $h->generation !== $this->shared->generation()
                || !isset($this->specs[$h->spec->id()]);

            if ($reloadDriven || $exit === Runner::EXIT_RELOAD || $exit === Runner::EXIT_STOP) {
                $bo->noteUptime($uptime);
                $this->states[$rid] = 'running';
                Log::debug('任务因换代退出，将重启', ['task' => $rid]);
                continue;
            }

            if ($exit === Runner::EXIT_OK) {
                $bo->noteUptime($uptime);
                if ($spec->mode === TaskSpec::MODE_ONCE || $spec->restart === TaskSpec::RESTART_NEVER) {
                    $this->states[$rid] = 'finished';
                    $this->manuallyStopped[$spec->id()] = true;
                    Log::info('任务已完成，不再重启', ['task' => $rid]);
                    continue;
                }
                if ($spec->restart === TaskSpec::RESTART_ON_FAILURE) {
                    $this->states[$rid] = 'finished';
                    $this->manuallyStopped[$spec->id()] = true;
                    continue;
                }
                $this->states[$rid] = 'running';
                continue;
            }

            $this->status->pushError([
                'ts' => microtime(true),
                'task' => $rid,
                'msg' => (string)($err ?: '任务异常退出'),
            ]);
            if ($spec->restart === TaskSpec::RESTART_NEVER) {
                $this->states[$rid] = 'failed';
                $this->manuallyStopped[$spec->id()] = true;
                continue;
            }
            $next = $bo->fail();
            $this->states[$rid] = $bo->exhausted() ? 'failed' : 'backoff';
            Log::warn('任务异常退出，安排重启', [
                'task' => $rid,
                'attempt' => $bo->attempt(),
                'in' => round($next - microtime(true), 1) . 's',
                'err' => $err,
            ]);
        }
    }

    private function enforceKills(): void
    {
        $grace = max(3.0, (float)($this->config['stop_timeout'] ?? 20));
        foreach ($this->workers as $rid => $h) {
            if (!$h->signalled() || $h->reaped() || !$h->alive()) {
                continue;
            }
            if ($h->sinceKillSignal() < $grace) {
                continue;
            }
            Log::error('SIGTERM 之后仍未退出，强杀', ['task' => $rid, 'pid' => $h->pid]);
            $h->kill();
        }
    }

    private function detectHung(): void
    {
        $now = microtime(true);
        foreach ($this->workers as $rid => $h) {
            if (!$h->alive()) {
                continue;
            }
            $spec = $this->specs[$h->spec->id()] ?? $h->spec;
            $st = $this->shared->taskState($rid);
            $ts = (float)($st['ts'] ?? $h->startedAt);
            $age = $now - $ts;
            if ($age < $spec->hungThreshold()) {
                //心跳回来了就把 hung 摘掉。以前只标不摘，任务恢复正常之后面板还会
                //一直挂着"卡死"，只有重启才消得掉（GitHub #884）。
                if (($this->states[$rid] ?? '') === 'hung') {
                    $this->states[$rid] = 'running';
                    unset($this->lastHungLog[$rid]);
                    Log::info('任务心跳已恢复', ['task' => $rid]);
                }
                continue;
            }

            $this->states[$rid] = 'hung';
            $msg = sprintf('任务心跳已停止 %.0f 秒（阈值 %.0f）', $age, $spec->hungThreshold());

            switch ($this->hungAction()) {
                case 'replace':
                case 'kill':

                    if (!$h->signalled()) {
                        $h->terminate();
                        $this->killedCount++;
                        Log::error($msg . '，已发送 SIGTERM', ['task' => $rid, 'pid' => $h->pid]);
                        $this->status->pushError(['ts' => $now, 'task' => $rid, 'msg' => $msg . '（已终止并重启）']);
                    }
                    break;

                case 'restart-daemon':
                    Log::error($msg . '，重启守护进程', ['task' => $rid]);
                    $this->status->pushError(['ts' => $now, 'task' => $rid, 'msg' => $msg . '（触发守护进程重启）']);
                    $this->shared->setRunning(false);
                    break;

                default:

                    if (($this->lastHungLog[$rid] ?? 0) < $now - 60) {
                        $this->lastHungLog[$rid] = $now;
                        Log::error($msg, ['task' => $rid, 'hung_action' => 'log']);
                        $this->status->pushError(['ts' => $now, 'task' => $rid, 'msg' => $msg]);
                    }
            }
        }
    }

    private array $lastHungLog = [];

    private function drainEvents(): void
    {
        foreach ($this->shared->drainEvents() as $ev) {
            if (($ev['err'] ?? null) !== null) {
                $this->status->pushError([
                    'ts' => (float)($ev['ts'] ?? microtime(true)),
                    'task' => (string)($ev['task'] ?? ''),
                    'msg' => (string)$ev['err'],
                ]);
            }
        }
    }

    private function pollCommands(): void
    {
        $known = [];
        foreach ($this->specs as $id => $spec) {
            $known[$id] = true;
            for ($i = 0; $i < $spec->concurrency; $i++) {
                $known[$spec->replicaId($i)] = true;
            }
        }

        foreach (Commands::poll($known) as $cmd) {
            $ok = true;
            $msg = '';

            switch ($cmd['op']) {
                case 'stop':
                    $this->manuallyStopped[$this->taskIdOf($cmd['task'])] = true;
                    $this->stopReplicasOf($cmd['task']);
                    $msg = '已请求停止';
                    break;

                case 'start':
                    unset($this->manuallyStopped[$this->taskIdOf($cmd['task'])]);
                    foreach ($this->replicaIdsOf($cmd['task']) as $rid) {
                        $this->backoffs[$rid]?->reset();
                        $this->states[$rid] = 'running';
                    }
                    $msg = '已请求启动';
                    break;

                case 'restart':
                    unset($this->manuallyStopped[$this->taskIdOf($cmd['task'])]);
                    foreach ($this->replicaIdsOf($cmd['task']) as $rid) {
                        $this->backoffs[$rid]?->reset();
                    }
                    $this->stopReplicasOf($cmd['task']);
                    $msg = '已请求重启';
                    break;

                case 'reload':
                    $this->reload('面板命令');
                    $msg = '已触发热重载';
                    break;

                case 'clear-errors':
                    $this->status->clearErrors();
                    $msg = '异常记录已清空';
                    break;

                case 'drain':
                case 'restart-daemon':

                    Log::info('收到退出命令', ['op' => $cmd['op'], 'actor' => $cmd['actor']]);
                    $this->shared->setRunning(false);
                    $msg = \App\Plugin\ThreadManager\Service\Env::restartHint();
                    break;

                default:
                    $ok = false;
                    $msg = '未知操作';
            }

            Log::info('执行命令', ['op' => $cmd['op'], 'task' => $cmd['task'], 'actor' => $cmd['actor']]);
            $this->status->pushCommandResult([
                'id' => $cmd['id'], 'op' => $cmd['op'], 'task' => $cmd['task'],
                'ok' => $ok, 'msg' => $msg, 'ts' => microtime(true),
            ]);
        }
    }

    private function taskIdOf(string $s): string
    {
        return explode('#', $s, 2)[0];
    }

    private function replicaIdsOf(string $s): array
    {
        if (str_contains($s, '#')) {
            return [$s];
        }
        $spec = $this->specs[$s] ?? null;
        if ($spec === null) {
            return [];
        }
        $out = [];
        for ($i = 0; $i < $spec->concurrency; $i++) {
            $out[] = $spec->replicaId($i);
        }
        return $out;
    }

    private function stopReplicasOf(string $taskOrReplica): void
    {
        foreach ($this->replicaIdsOf($taskOrReplica) as $rid) {
            $this->states[$rid] = 'stopping';
        }

        $this->shared->bumpGeneration();
    }

    private function daemonView(): array
    {

        $rss = self::rssKb(getmypid());
        foreach ($this->workers as $h) {
            $rss += self::rssKb($h->pid);
        }

        return [
            'state' => 'running',
            'tick_ms' => (int)($this->config['tick_ms'] ?? 250),
            'workers' => count($this->workers),
            'killed' => $this->killedCount,
            'generation' => $this->shared->generation(),
            'mem' => memory_get_usage(true),
            'mem_peak' => memory_get_peak_usage(true),
            'rss' => $rss * 1024,
            'binary' => [
                'php' => PHP_VERSION,
                'swoole' => function_exists('swoole_version') ? swoole_version() : null,
                'zts' => (bool)ZEND_THREAD_SAFE,
                'process' => class_exists('Swoole\Process'),

                'hooked_io_concurrent' => true,
            ],

            //守护进程和面板可能不在同一个容器里，环境必须由守护进程自己上报。
            'env' => \App\Plugin\ThreadManager\Service\Env::snapshot(),
        ];
    }

    private static function rssKb(int $pid): int
    {
        if ($pid <= 0) {
            return 0;
        }
        $f = "/proc/{$pid}/statm";
        $raw = @file_get_contents($f);
        if (!is_string($raw) || $raw === '') {
            return 0;
        }
        $parts = preg_split('/\s+/', trim($raw));

        return (int)(($parts[1] ?? 0) * (int)(function_exists('posix_sysconf') ? 4096 : 4096) / 1024);
    }

    private function buildTaskView(): array
    {
        $out = [];
        foreach ($this->specs as $id => $spec) {
            $replicas = [];
            $running = 0;
            $lastErr = null;
            $lastErrTs = 0.0;
            $restarts = 0;

            for ($i = 0; $i < $spec->concurrency; $i++) {
                $rid = $spec->replicaId($i);
                $st = $this->shared->taskState($rid) ?? [];
                $alive = isset($this->workers[$rid]) && $this->workers[$rid]->alive();
                if ($alive) {
                    $running++;
                }
                $bo = $this->backoffs[$rid] ?? null;
                $restarts = max($restarts, $bo?->attempt() ?? 0);
                if (($st['err'] ?? null) !== null) {
                    $lastErr = (string)$st['err'];
                    $lastErrTs = (float)($st['ts'] ?? 0);
                }

                $replicas[] = [
                    'i' => $i,
                    'state' => $alive ? ($this->states[$rid] ?? 'running') : ($this->states[$rid] ?? 'stopped'),
                    'ts' => $st['ts'] ?? null,
                    'iter' => $st['iter'] ?? 0,
                    'last_ms' => $st['last_ms'] ?? null,
                    'avg_ms' => $st['avg_ms'] ?? null,
                    'mem' => $st['mem'] ?? null,
                    'started_at' => isset($this->workers[$rid]) ? $this->workers[$rid]->startedAt : null,
                    'next_start' => $bo?->nextAt() ?: null,
                ];
            }

            $state = match (true) {
                !$spec->enabled => 'disabled',
                isset($this->manuallyStopped[$id]) => 'stopped',
                $running > 0 => 'running',
                default => $this->states[$spec->replicaId(0)] ?? 'pending',
            };

            $out[$id] = [
                'id' => $id,
                'plugin' => $spec->plugin,
                'name' => $spec->name,
                'mode' => $spec->mode,
                'interval' => $spec->interval,
                'cron' => $spec->cron,
                'boot' => $spec->boot,
                'enabled' => $spec->enabled,
                'concurrency' => $spec->concurrency,
                'state' => $state,
                'replicas' => $replicas,
                'replicas_running' => $running,
                'restarts' => $restarts,
                'last_error' => $lastErr,
                'last_error_ts' => $lastErrTs,
                'spec_hash' => $spec->hash(),
            ];
        }
        return $out;
    }

    private function shutdown(): int
    {
        $timeout = (float)($this->config['stop_timeout'] ?? 20);
        Log::info('开始关闭', ['timeout' => $timeout, 'workers' => count($this->workers)]);

        $this->shared->setRunning(false);
        foreach ($this->workers as $h) {
            $h->terminate();
        }

        $deadline = microtime(true) + $timeout;
        while (microtime(true) < $deadline) {

            $this->signals->dispatch();
            $this->harvest();
            foreach ($this->workers as $rid => $h) {
                if ($h->reaped()) {
                    unset($this->workers[$rid]);
                }
            }
            if ($this->workers === []) {
                break;
            }
            usleep(50_000);
        }

        $stuck = array_keys($this->workers);
        if ($stuck !== []) {
            Log::error('任务超时未退出，强杀', ['tasks' => $stuck]);
            foreach ($this->workers as $h) {
                $h->kill();
            }

            $hardDeadline = microtime(true) + 3.0;
            while ($this->workers !== [] && microtime(true) < $hardDeadline) {
                $this->harvest();
                foreach ($this->workers as $rid => $h) {
                    if ($h->reaped()) {
                        unset($this->workers[$rid]);
                    }
                }
                usleep(50_000);
            }
        }

        $this->status->publish(
            ['state' => 'stopped', 'workers' => 0, 'killed' => $this->killedCount, 'stuck' => $stuck]
                + $this->daemonView(),
            $this->buildTaskView(),
            true
        );

        Log::info('守护进程已退出');
        return $stuck === [] ? 0 : 0;
    }
}
