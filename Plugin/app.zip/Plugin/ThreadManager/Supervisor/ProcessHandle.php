<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Supervisor;

use App\Plugin\ThreadManager\Runtime\WorkerEntry;
use App\Plugin\ThreadManager\Supervisor\Shared\SharedState;
use App\Plugin\ThreadManager\Task\TaskSpec;
use Swoole\Process;

final class ProcessHandle
{
    public string $replicaId;
    public float $startedAt;
    public int $generation;
    public string $specHash;
    public int $pid = 0;

    private ?Process $process = null;
    private bool $reaped = false;
    private ?array $exitStatus = null;
    private float $killedAt = 0.0;

    public function __construct(
        public TaskSpec $spec,
        public int $replica,
        int $generation,
        SharedState $shared,
    ) {
        $this->replicaId = $spec->replicaId($replica);
        $this->generation = $generation;
        $this->specHash = $spec->hash();
        $this->startedAt = microtime(true);

        $specJson = $spec->toJson();

        $this->process = new Process(
            static function (Process $worker) use ($specJson, $replica, $generation, $shared): void {
                WorkerEntry::runTask($specJson, $replica, $generation, $shared);
            },
            false,
            0,
            false
        );

        $pid = $this->process->start();
        if ($pid === false) {
            throw new \RuntimeException("fork 失败：{$this->replicaId}");
        }
        $this->pid = (int)$pid;
    }

    public function alive(): bool
    {
        if ($this->reaped || $this->pid <= 0) {
            return false;
        }
        return Process::kill($this->pid, 0);
    }

    public function markReaped(array $status): void
    {
        $this->reaped = true;
        $this->exitStatus = $status;
        $this->process = null;
    }

    public function reaped(): bool { return $this->reaped; }

    public function exitStatus(): ?array { return $this->exitStatus; }

    public function killedBySignal(): bool
    {
        return (int)($this->exitStatus['signal'] ?? 0) > 0;
    }

    public function terminate(): void
    {
        if ($this->pid > 0 && !$this->reaped) {
            @Process::kill($this->pid, SIGTERM);
            $this->killedAt = microtime(true);
        }
    }

    public function kill(): void
    {
        if ($this->pid > 0 && !$this->reaped) {
            @Process::kill($this->pid, SIGKILL);
            $this->killedAt = microtime(true);
        }
    }

    public function sinceKillSignal(): float
    {
        return $this->killedAt > 0 ? microtime(true) - $this->killedAt : 0.0;
    }

    public function signalled(): bool { return $this->killedAt > 0; }

    public function uptime(): float { return microtime(true) - $this->startedAt; }
}
