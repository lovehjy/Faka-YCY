<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Supervisor;

use App\Plugin\ThreadManager\Service\Paths;
use App\Plugin\ThreadManager\Task\Registry;

final class Status
{
    private float $lastWrite = 0.0;
    private array $errors = [];
    private array $commandResults = [];

    public const MAX_ERRORS = 50;
    public const MAX_COMMAND_RESULTS = 20;

    public function __construct(
        private float $bootTs,
        private float $throttle = 1.0,
    ) {}

    public function pushError(array $err): void
    {
        $this->errors[] = $err;
        if (count($this->errors) > self::MAX_ERRORS) {
            $this->errors = array_slice($this->errors, -self::MAX_ERRORS);
        }
    }

    public function clearErrors(): void { $this->errors = []; }

    public function errors(): array { return $this->errors; }

    public function pushCommandResult(array $r): void
    {
        $this->commandResults[] = $r;
        if (count($this->commandResults) > self::MAX_COMMAND_RESULTS) {
            $this->commandResults = array_slice($this->commandResults, -self::MAX_COMMAND_RESULTS);
        }
    }

    public function publish(array $daemon, array $tasks, bool $force = false): void
    {
        $now = microtime(true);
        if (!$force && ($now - $this->lastWrite) < $this->throttle) {
            return;
        }
        $this->lastWrite = $now;

        $payload = [
            'v' => 1,
            'pid' => getmypid(),
            'boot_ts' => $this->bootTs,
            'ts' => $now,
            'uptime' => $now - $this->bootTs,
            'daemon' => $daemon,
            'tasks' => $tasks,
            'errors' => $this->errors,
            'commands' => $this->commandResults,
        ];

        Registry::atomicWrite(
            Paths::status(),
            (string)json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );
    }

    public static function read(): ?array
    {
        $f = Paths::status();
        if (!is_file($f)) {
            return null;
        }
        $d = json_decode((string)@file_get_contents($f), true);
        return is_array($d) ? $d : null;
    }
}
