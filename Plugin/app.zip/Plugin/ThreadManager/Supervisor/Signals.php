<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Supervisor;

use App\Plugin\ThreadManager\Service\Log;

final class Signals
{
    private bool $stopRequested = false;
    private bool $reloadRequested = false;
    private bool $installed = false;

    private bool $pendingStopLog = false;
    private bool $pendingReloadLog = false;

    public function install(): void
    {
        if (!function_exists('pcntl_signal')) {
            Log::warn('缺少 pcntl 扩展，无法优雅关闭');
            return;
        }

        pcntl_async_signals(false);

        pcntl_signal(SIGTERM, function (): void {
            $this->stopRequested = true;
            $this->pendingStopLog = true;
        });
        pcntl_signal(SIGINT, function (): void {
            $this->stopRequested = true;
            $this->pendingStopLog = true;
        });
        pcntl_signal(SIGHUP, function (): void {
            $this->reloadRequested = true;
            $this->pendingReloadLog = true;
        });

        pcntl_signal(SIGPIPE, SIG_IGN);

        $this->installed = true;
    }

    public function dispatch(): void
    {
        if (!$this->installed) {
            return;
        }
        pcntl_signal_dispatch();

        if ($this->pendingStopLog) {
            $this->pendingStopLog = false;
            Log::info('收到停止信号');
        }
        if ($this->pendingReloadLog) {
            $this->pendingReloadLog = false;
            Log::info('收到 SIGHUP，触发热重载');
        }
    }

    public function stopRequested(): bool { return $this->stopRequested; }

    public function takeReloadRequest(): bool
    {
        if (!$this->reloadRequested) {
            return false;
        }
        $this->reloadRequested = false;
        return true;
    }
}
