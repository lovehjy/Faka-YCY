<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Supervisor;

use App\Plugin\ThreadManager\Task\TaskSpec;

final class Backoff
{
    private int $attempt = 0;
    private float $nextAt = 0.0;

    public function __construct(private TaskSpec $spec) {}

    public function attempt(): int { return $this->attempt; }
    public function nextAt(): float { return $this->nextAt; }

    public function noteUptime(float $uptimeSeconds): void
    {
        if ($uptimeSeconds >= $this->spec->successAfter) {
            $this->attempt = 0;
        }
    }

    public function fail(): float
    {
        $this->attempt++;
        $delay = min(
            $this->spec->backoffMax,
            $this->spec->backoffMin * ($this->spec->backoffFactor ** max(0, $this->attempt - 1))
        );

        $j = $this->spec->backoffJitter;
        if ($j > 0) {
            $delay += $delay * $j * (mt_rand(-1000, 1000) / 1000);
        }
        $delay = max(0.0, $delay);
        return $this->nextAt = microtime(true) + $delay;
    }

    public function reset(): void
    {
        $this->attempt = 0;
        $this->nextAt = 0.0;
    }

    public function ready(): bool { return microtime(true) >= $this->nextAt; }

    public function exhausted(): bool
    {
        return $this->spec->maxRestarts > 0 && $this->attempt >= $this->spec->maxRestarts;
    }
}
