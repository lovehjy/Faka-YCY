#!/usr/bin/env bash
set -euo pipefail
trap 'echo "出错：第 ${LINENO} 行 -> ${BASH_COMMAND}（退出码 $?）" >&2' ERR

PLUGIN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${PLUGIN_DIR}/../../.." && pwd)"
TARGET="${PLUGIN_DIR}/swoole-cli"
HASH_FILE="${PLUGIN_DIR}/swoole-cli.sha256"
STATE_DIR="${PROJECT_ROOT}/runtime/plugin/ThreadManager"
STATE_HASH="${STATE_DIR}/swoole-cli.sha256"

DEF_TAG="v6.1.7.0"
DEF_VER="v6.1.7"

known_hash() {
    case "$1" in
        v6.1.7-x64)   echo "8cedfd58d36f26dbcf9988bc89ae85efcaf6cd8cf2cdd492370236cdd55e8161" ;;
        v6.1.7-arm64) echo "d60b85c5d453b803eb13c552c8a935b80809448aefc13d69d36efee744c13dfb" ;;
        v6.2.0-x64)   echo "17bf4cb5ab223bba71dabb110a4cd9d0f6df320a1eb6dcdadc3bf060b58ab955" ;;
        v6.2.0-arm64) echo "0f1fb2a18eb4c1e8fe4d7ede6a24c3d9ae6bc50b682f95fd90a5c0e5892e540e" ;;
        *) echo "" ;;
    esac
}

say() { echo "  $*"; }
die() { echo "✘ $*" >&2; exit 1; }

[ "$(uname -s)" = "Linux" ] || die "守护进程只在 Linux 上跑（当前 $(uname -s)）"

case "$(uname -m)" in
    x86_64|amd64)  ARCH=x64 ;;
    aarch64|arm64) ARCH=arm64 ;;
    *) die "不支持的架构 $(uname -m)，官方只发 x86-64 和 arm64" ;;
esac

command -v sha256sum >/dev/null 2>&1 || die "找不到 sha256sum"
command -v tar >/dev/null 2>&1 || die "找不到 tar"
if command -v curl >/dev/null 2>&1; then GET() { curl -fL --progress-bar --retry 2 --connect-timeout 15 -o "$1" "$2"; }
elif command -v wget >/dev/null 2>&1; then GET() { wget -q --show-progress --tries=2 -O "$1" "$2"; }
else die "curl 和 wget 都没有，装一个再来"; fi

ARG="${1:-}"
URLS=()
WANT=""

if [ -z "${ARG}" ] || [ "${ARG#v}" != "${ARG}" ] || [[ "${ARG}" =~ ^[0-9] ]]; then
    if [ -z "${ARG}" ]; then
        TAG="${DEF_TAG}"; VER="${DEF_VER}"
    else
        CORE="${ARG#v}"
        if [ "$(echo "${CORE}" | awk -F. '{print NF}')" -eq 3 ]; then CORE="${CORE}.0"; fi
        TAG="v${CORE}"
        VER="v$(echo "${CORE}" | cut -d. -f1-3)"
    fi
    ASSET="swoole-cli-${VER}-linux-${ARCH}.tar.xz"
    WANT="$(known_hash "${VER}-${ARCH}")"

    BASE="https://github.com/swoole/swoole-cli/releases/download/${TAG}/${ASSET}"
    URLS+=("${BASE}")
    for m in ${TM_MIRRORS:-https://ghfast.top/ https://gh-proxy.com/ https://ghproxy.net/}; do
        URLS+=("${m}${BASE}")
    done
else
    case "${ARG}" in
        https://*) ;;
        *) die "只允许 https 地址 —— 明文下载可执行文件等于把守护进程交给中间人" ;;
    esac
    URLS+=("${ARG}")
    WANT="${2:-}"
    VER="custom"
fi

echo "ThreadManager · 安装 swoole-cli"
say "架构   ：linux-${ARCH}"
say "版本   ：${VER}${WANT:+（已知 sha256，会强制校验）}"
[ -n "${WANT}" ] || say "版本   ：未知 sha256，改用功能自检（Swoole\\Process + pcntl）"

if [ -n "${WANT}" ] && [ -f "${TARGET}" ]; then
    CUR="$(sha256sum "${TARGET}" | awk '{print $1}')"
    if [ "${CUR}" = "${WANT}" ]; then
        chmod +x "${TARGET}"
        say "已经是这一版，跳过下载"
        echo "✔ 完成：${TARGET}"
        echo
        echo "下一步： ./service.sh install"
        exit 0
    fi
fi

TMPD="$(mktemp -d)"
trap 'rm -rf "${TMPD}"' EXIT
PKG="${TMPD}/pkg"

OK=0
for u in "${URLS[@]}"; do
    say "下载：${u}"
    if GET "${PKG}" "${u}" && [ -s "${PKG}" ]; then OK=1; break; fi
    say "  ↳ 失败，换下一个源"
    rm -f "${PKG}"
done
[ "${OK}" = "1" ] || die "所有下载源都失败了，检查网络或用 TM_MIRRORS 指定自己的镜像"

BIN="${PKG}"
if head -c 6 "${PKG}" | grep -q "7zXZ" 2>/dev/null || [ "${PKG##*.}" = "xz" ]; then
    say "解包…"
    tar --no-same-owner -xf "${PKG}" -C "${TMPD}" 2>/dev/null || die "解包失败，下到的可能不是 tar.xz"
    BIN="$(find "${TMPD}" -type f -name 'swoole-cli' | head -1)"
    [ -n "${BIN}" ] || die "包里没找到 swoole-cli"
fi

head -c 4 "${BIN}" | grep -q "ELF" || die "下到的不是 ELF 可执行文件（多半拿到了一个错误页）"

ACTUAL="$(sha256sum "${BIN}" | awk '{print $1}')"
if [ -n "${WANT}" ]; then
    [ "${ACTUAL}" = "${WANT}" ] || die "sha256 校验失败，已丢弃。
    期望 ${WANT}
    实际 ${ACTUAL}"
    say "sha256 校验通过"
else
    say "sha256：${ACTUAL}"
fi

chmod +x "${BIN}"

say "自检中…"
"${BIN}" -v 2>/dev/null | head -1 | sed 's/^/  /' || die "这个二进制跑不起来（架构不匹配？）"
"${BIN}" -r 'exit((class_exists("Swoole\\Process") && function_exists("pcntl_fork")) ? 0 : 1);' >/dev/null 2>&1 \
    || die "这个构建缺少 Swoole\\Process 或 pcntl，ThreadManager 用不了它。请换官方 Linux 构建。"
say "Swoole\\Process + pcntl 就绪"

mv -f "${BIN}" "${TARGET}.part"
chmod 0755 "${TARGET}.part"
mv -f "${TARGET}.part" "${TARGET}"

mkdir -p "${STATE_DIR}" 2>/dev/null || true
printf '%s  swoole-cli\n' "${ACTUAL}" > "${STATE_HASH}" 2>/dev/null || true

echo "✔ 完成：${TARGET}（$(du -h "${TARGET}" | awk '{print $1}')）"
echo
echo "下一步： ./service.sh install"
