#!/usr/bin/env bash
set -euo pipefail

trap 'echo "出错：第 ${LINENO} 行 -> ${BASH_COMMAND}（退出码 $?）" >&2' ERR

PLUGIN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${PLUGIN_DIR}/../../.." && pwd)"
PLUGIN_NAME="$(basename "${PLUGIN_DIR}")"
PROJECT_NAME="$(basename "${PROJECT_ROOT}")"

BIN_FILE="${PLUGIN_DIR}/swoole-cli"
DAEMON_FILE="${PLUGIN_DIR}/Bin/Daemon.php"
HASH_FILE="${PLUGIN_DIR}/swoole-cli.sha256"

slug() { printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | sed -E 's/[^a-z0-9_.-]+/-/g; s/^-+//; s/-+$//'; }

# 服务名里必须掺进**项目根绝对路径**的指纹。
# 只用目录名的话，同机部署两套程序时 /www/wwwroot/a.com/acgshop 和 /www/wwwroot/b.com/acgshop
# 会算出同一个服务名，后装的直接覆盖先装的 unit —— 先装那站的 start/restart 从此启动的是别人的守护进程。
path_fingerprint() {
    local h=""
    if command -v sha256sum >/dev/null 2>&1; then h="$(printf '%s' "$1" | sha256sum | cut -c1-6)"
    elif command -v shasum >/dev/null 2>&1; then h="$(printf '%s' "$1" | shasum -a 256 | cut -c1-6)"
    elif command -v openssl >/dev/null 2>&1; then h="$(printf '%s' "$1" | openssl dgst -sha256 | awk '{print $NF}' | cut -c1-6)"
    else h="$(printf '%s' "$1" | cksum | awk '{printf "%06x", $1}' | cut -c1-6)"
    fi
    printf '%s' "${h}"
}

SERVICE_NAME="$(slug "${PROJECT_NAME}-${PLUGIN_NAME}")-$(path_fingerprint "${PROJECT_ROOT}")"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"

# 1.2 之前的命名（不带指纹）。仅用于升级迁移与向后兼容，绝不主动创建。
LEGACY_NAME="$(slug "${PROJECT_NAME}-${PLUGIN_NAME}")"
LEGACY_FILE="/etc/systemd/system/${LEGACY_NAME}.service"

# 老 unit 是不是**本站**装的？靠 ExecStart 指向的守护进程入口判断。
# 同名但指向别的目录 = 隔壁站的服务，一个字都不能动。
legacy_is_ours() {
    [ -f "${LEGACY_FILE}" ] || return 1
    grep -qF "ExecStart=" "${LEGACY_FILE}" 2>/dev/null || return 1
    grep -F "ExecStart=" "${LEGACY_FILE}" 2>/dev/null | grep -qF "${DAEMON_FILE}"
}

# 新名字还没装、但老名字是自己的 —— 让 start/stop/status/log 继续可用，
# 用户下次跑 install 时再自动迁移过去。
resolve_service() {
    if [ ! -f "${SERVICE_FILE}" ] && legacy_is_ours; then
        SERVICE_NAME="${LEGACY_NAME}"
        SERVICE_FILE="${LEGACY_FILE}"
    fi
}

if [ "$(id -u)" -eq 0 ]; then SUDO=""; else SUDO="sudo"; fi

say() { echo "  $*"; }
die() { echo "✘ $*" >&2; exit 1; }

usage() {
    echo "用法: $0 {install|start|stop|restart|status|log|run|uninstall}"
    echo "  install 会先自动下载 swoole-cli 再装并启动；可带版本或自备地址："
    echo "          $0 install [版本 | https地址 [sha256]]"
    echo "  run     前台运行守护进程（容器 CMD / supervisord / s6 用这个）"
    echo
    echo "  有 systemd 时注册为 systemd 服务；没有（Docker 等容器）时自动改用"
    echo "  脚本自带的前台/后台模式，起停照常用上面这些命令。"
    echo "  用 TM_MODE=systemd|container 可以强制指定。"
    exit 1
}

# ---------------- 运行模式判定 ----------------

# systemd 是不是真的在跑。
# 只看 `command -v systemctl` 是不够的：容器镜像里常常装着 systemd 包，
# systemctl 存在但一调就报 "System has not been booted with systemd"。
# /run/systemd/system 只有 systemd 作为 1 号进程起来之后才存在，这是官方推荐判据。
has_systemd() {
    case "${TM_MODE:-auto}" in
        container) return 1 ;;
        systemd)   return 0 ;;
    esac
    command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]
}

in_container() {
    [ ! -f /.dockerenv ] || return 0
    [ ! -f /run/.containerenv ] || return 0
    grep -qaE '(docker|containerd|kubepods|lxc|podman)' /proc/1/cgroup 2>/dev/null && return 0
    return 1
}

ensure_service_file() {
    [ -f "${SERVICE_FILE}" ] || { echo "${SERVICE_NAME}.service 还没装，先跑：$0 install"; exit 1; }
}

# ---------------- swoole-cli 下载（原 install.sh，内联为单文件安装器） ----------------

known_hash() {
    case "$1" in
        v6.1.7-x64)   echo "8cedfd58d36f26dbcf9988bc89ae85efcaf6cd8cf2cdd492370236cdd55e8161" ;;
        v6.1.7-arm64) echo "d60b85c5d453b803eb13c552c8a935b80809448aefc13d69d36efee744c13dfb" ;;
        v6.2.0-x64)   echo "17bf4cb5ab223bba71dabb110a4cd9d0f6df320a1eb6dcdadc3bf060b58ab955" ;;
        v6.2.0-arm64) echo "0f1fb2a18eb4c1e8fe4d7ede6a24c3d9ae6bc50b682f95fd90a5c0e5892e540e" ;;
        *) echo "" ;;
    esac
}

# 有没有可用的 lzma 解码器（python3 自带的 lzma 模块直接链 liblzma）。
#
# 为什么要绕开 xz 这个可执行文件：xz 5.6 起会启用 Landlock 沙箱，某些容器运行时
# （seccomp 白名单没放行相关系统调用）会让它直接失败并打印
#   xz: Failed to enable the sandbox
# 包本身完全正常，纯粹是环境限制。tar 解 .xz 也是 fork 出 xz，一样中招。
# python3 的 lzma 不经过那个二进制，不受影响。
have_pylzma() {
    command -v python3 >/dev/null 2>&1 && python3 -c 'import lzma, tarfile' >/dev/null 2>&1
}

# 下载回来的包是不是完整的。
#
# 只看 curl 退出码是不够的：GitHub 直连经常在中途断流，curl 照样退出 0、进度条也走到
# 100%，拿到的却是个截断的文件。不在这里拦住的话，① 镜像源永远轮不到（因为第一个源
# "成功"了），② 一直到解包才炸，还报"下到的可能不是 tar.xz"这种驴唇不对马嘴的错。
archive_ok() {
    # 自备地址给的是裸二进制时不是压缩包，直接放行
    head -c 6 "$1" | grep -q "7zXZ" 2>/dev/null || return 0

    if have_pylzma; then
        python3 - "$1" <<'PY' >/dev/null 2>&1
import lzma, sys
with lzma.open(sys.argv[1]) as f:
    while f.read(1 << 20):
        pass
PY
        return $?
    fi

    # 没有 python3 才退回 xz。它要是因为沙箱失败，这里会误判成"包不完整"，
    # 所以下面解包失败时会把真实报错打出来。
    xz -t "$1" >/dev/null 2>&1
}

# 解包。先用 tar（走系统的 xz），不行再用 python3 兜底。
extract_pkg() {
    local pkg="$1" dest="$2" err="$3"

    if tar --no-same-owner -xf "${pkg}" -C "${dest}" 2>"${err}"; then
        return 0
    fi

    if have_pylzma; then
        say "tar 解包失败（$(head -1 "${err}" 2>/dev/null | cut -c1-70)），改用 python3 解包"
        if python3 - "${pkg}" "${dest}" <<'PY' 2>>"${err}"
import lzma, sys, tarfile
with lzma.open(sys.argv[1]) as fh:
    with tarfile.open(fileobj=fh) as tf:
        try:
            tf.extractall(sys.argv[2], filter="tar")
        except TypeError:      # Python < 3.12 没有 filter 参数
            tf.extractall(sys.argv[2])
PY
        then
            return 0
        fi
    fi

    return 1
}

# 下载并装好 swoole-cli。参数：[版本 | https地址 [sha256]]。已是目标版本则跳过（幂等）。
download_binary() {
    local TARGET="${BIN_FILE}"
    local STATE_DIR="${PROJECT_ROOT}/runtime/plugin/${PLUGIN_NAME}"
    local STATE_HASH="${STATE_DIR}/swoole-cli.sha256"
    local DEF_TAG="v6.1.7.0" DEF_VER="v6.1.7"

    [ "$(uname -s)" = "Linux" ] || die "守护进程只在 Linux 上跑（当前 $(uname -s)）"
    local ARCH
    case "$(uname -m)" in
        x86_64|amd64)  ARCH=x64 ;;
        aarch64|arm64) ARCH=arm64 ;;
        *) die "不支持的架构 $(uname -m)，官方只发 x86-64 和 arm64" ;;
    esac

    command -v sha256sum >/dev/null 2>&1 || die "找不到 sha256sum"
    command -v tar >/dev/null 2>&1 || die "找不到 tar"
    # 官方包是 .tar.xz，tar 要靠外部的 xz 程序解压。缺了它 tar 只会报
    # "xz: Cannot exec"，而这里看到的是"解包失败"——一定要在下载前就拦住，
    # 否则四个源全试一遍还是同样的错，白等好几分钟。
    command -v xz >/dev/null 2>&1 || die "找不到 xz，解 .tar.xz 需要它。
    Debian / Ubuntu : apt install -y xz-utils
    CentOS / Alma   : yum install -y xz
    Alpine          : apk add xz
    装好后重新执行本命令即可"
    if command -v curl >/dev/null 2>&1; then GET() { curl -fL --progress-bar --retry 2 --connect-timeout 15 -o "$1" "$2"; }
    elif command -v wget >/dev/null 2>&1; then GET() { wget -q --show-progress --tries=2 -O "$1" "$2"; }
    else die "curl 和 wget 都没有，装一个再来"; fi

    local ARG="${1:-}"
    local URLS=() WANT="" TAG VER CORE ASSET BASE m
    if [ -z "${ARG}" ] || [ "${ARG#v}" != "${ARG}" ] || [[ "${ARG}" =~ ^[0-9] ]]; then
        if [ -z "${ARG}" ]; then
            TAG="${DEF_TAG}"; VER="${DEF_VER}"
        else
            CORE="${ARG#v}"
            if [ "$(echo "${CORE}" | awk -F. '{print NF}')" -eq 3 ]; then CORE="${CORE}.0"; fi
            TAG="v${CORE}"
            VER="v$(echo "${CORE}" | cut -d. -f1-3)"
        fi
        ASSET="swoole-cli-${VER}-linux-${ARCH}.tar.xz"
        WANT="$(known_hash "${VER}-${ARCH}")"
        BASE="https://github.com/swoole/swoole-cli/releases/download/${TAG}/${ASSET}"
        URLS+=("${BASE}")
        for m in ${TM_MIRRORS:-https://ghfast.top/ https://gh-proxy.com/ https://ghproxy.net/}; do
            URLS+=("${m}${BASE}")
        done
    else
        case "${ARG}" in
            https://*) ;;
            *) die "只允许 https 地址 —— 明文下载可执行文件等于把守护进程交给中间人" ;;
        esac
        URLS+=("${ARG}")
        WANT="${2:-}"
        VER="custom"
    fi

    echo "ThreadManager · 准备 swoole-cli"
    say "架构   ：linux-${ARCH}"
    if [ -n "${WANT}" ]; then say "版本   ：${VER}（已知 sha256，会强制校验）"; else say "版本   ：${VER}（未知 sha256，改用功能自检：Swoole\\Process + pcntl）"; fi

    if [ -n "${WANT}" ] && [ -f "${TARGET}" ]; then
        local CUR
        CUR="$(sha256sum "${TARGET}" | awk '{print $1}')"
        if [ "${CUR}" = "${WANT}" ]; then
            chmod +x "${TARGET}"
            say "已经是这一版，跳过下载"
            return 0
        fi
    fi

    local TMPD PKG OK u BIN ACTUAL
    TMPD="$(mktemp -d)"
    trap 'rm -rf "${TMPD}"' EXIT
    PKG="${TMPD}/pkg"

    OK=0
    for u in "${URLS[@]}"; do
        say "下载：${u}"
        if ! GET "${PKG}" "${u}" || [ ! -s "${PKG}" ]; then
            say "  ↳ 下载失败，换下一个源"
            rm -f "${PKG}"
            continue
        fi
        if ! archive_ok "${PKG}"; then
            say "  ↳ 包不完整（只下到 $(du -h "${PKG}" 2>/dev/null | cut -f1)，多半是中途断流），换下一个源"
            rm -f "${PKG}"
            continue
        fi
        OK=1
        break
    done
    [ "${OK}" = "1" ] || die "所有下载源都失败了。
    GitHub 直连不稳时可以指定自己的镜像前缀重试：
    TM_MIRRORS=\"https://ghfast.top/\" $0 install"

    BIN="${PKG}"
    if head -c 6 "${PKG}" | grep -q "7zXZ" 2>/dev/null || [ "${PKG##*.}" = "xz" ]; then
        say "解包…"
        if ! extract_pkg "${PKG}" "${TMPD}" "${TMPD}/tar.err"; then
            ERRTXT="$(tr '\n' ' ' < "${TMPD}/tar.err" 2>/dev/null | cut -c1-200)"
            say "报错：${ERRTXT}"
            if printf '%s' "${ERRTXT}" | grep -qi "sandbox"; then
                die "解包失败：这台机器上的 xz 启不了沙箱（容器运行时的 seccomp 拦掉了相关系统调用）。
    包本身是好的，换个解法即可，三选一：
      1) 装 python3（脚本会自动改用它解包）： apt install -y python3
      2) 升级 Docker 到较新版本，其默认 seccomp 白名单已放行
      3) 起容器时加 --security-opt seccomp=unconfined"
            fi
            die "解包失败（包大小 $(du -h "${PKG}" 2>/dev/null | cut -f1)）。
    换个镜像源重试：TM_MIRRORS=\"https://ghfast.top/\" $0 install"
        fi
        BIN="$(find "${TMPD}" -type f -name 'swoole-cli' | head -1)"
        [ -n "${BIN}" ] || die "包里没找到 swoole-cli"
    fi

    head -c 4 "${BIN}" | grep -q "ELF" || die "下到的不是 ELF 可执行文件（多半拿到了一个错误页）"

    ACTUAL="$(sha256sum "${BIN}" | awk '{print $1}')"
    if [ -n "${WANT}" ]; then
        [ "${ACTUAL}" = "${WANT}" ] || die "sha256 校验失败，已丢弃。
    期望 ${WANT}
    实际 ${ACTUAL}"
        say "sha256 校验通过"
    else
        say "sha256：${ACTUAL}"
    fi

    chmod +x "${BIN}"
    say "自检中…"
    "${BIN}" -v 2>/dev/null | head -1 | sed 's/^/  /' || die "这个二进制跑不起来（架构不匹配？）"
    "${BIN}" -r 'exit((class_exists("Swoole\\Process") && function_exists("pcntl_fork")) ? 0 : 1);' >/dev/null 2>&1 \
        || die "这个构建缺少 Swoole\\Process 或 pcntl，ThreadManager 用不了它。请换官方 Linux 构建。"
    say "Swoole\\Process + pcntl 就绪"

    mv -f "${BIN}" "${TARGET}.part"
    chmod 0755 "${TARGET}.part"
    mv -f "${TARGET}.part" "${TARGET}"

    mkdir -p "${STATE_DIR}" 2>/dev/null || true
    printf '%s  swoole-cli\n' "${ACTUAL}" > "${STATE_HASH}" 2>/dev/null || true

    say "完成：${TARGET}（$(du -h "${TARGET}" | awk '{print $1}')）"
    rm -rf "${TMPD}"; trap - EXIT
}

# 下载后的健壮性复检：可执行、Swoole\Process/pcntl 就绪、sha 一致、守护进程入口在。
ensure_binary() {
    if [ ! -f "${BIN_FILE}" ]; then
        echo "找不到 swoole-cli：${BIN_FILE}" >&2
        echo "重新跑一次： $0 install（会自动下载）" >&2
        exit 1
    fi

    [ -x "${BIN_FILE}" ] || { echo "补上可执行权限：${BIN_FILE}"; ${SUDO} chmod +x "${BIN_FILE}"; }

    if ! "${BIN_FILE}" -r 'exit((class_exists("Swoole\\Process") && function_exists("pcntl_fork")) ? 0 : 1);' >/dev/null 2>&1; then
        echo "这个 swoole-cli 跑不起来，或者缺少 Swoole\\Process / pcntl"
        echo "      版本信息：$("${BIN_FILE}" -v 2>&1 | head -1 || echo '无法执行')"
        exit 1
    fi

    if [ -f "${HASH_FILE}" ] && command -v sha256sum >/dev/null 2>&1; then
        if ! (cd "${PLUGIN_DIR}" && sha256sum -c --status "${HASH_FILE}" 2>/dev/null); then
            echo "提示：swoole-cli 的 sha256 与插件记录的不一致。"
            echo "      自己换过构建的话属正常，忽略即可；否则建议重新下载。"
        fi
    fi

    [ -f "${DAEMON_FILE}" ] || { echo "守护进程入口不存在：${DAEMON_FILE}"; exit 1; }
}

detect_user() {
    local dir="${PROJECT_ROOT}/runtime"
    if [ ! -d "${dir}" ]; then dir="${PROJECT_ROOT}"; fi
    RUN_USER="${TM_USER:-$(stat -c '%U' "${dir}" 2>/dev/null || echo root)}"
    RUN_GROUP="${TM_GROUP:-$(stat -c '%G' "${dir}" 2>/dev/null || echo root)}"
    if [ "${RUN_USER}" = "UNKNOWN" ] || [ -z "${RUN_USER}" ]; then RUN_USER="root"; fi
    if [ "${RUN_GROUP}" = "UNKNOWN" ] || [ -z "${RUN_GROUP}" ]; then RUN_GROUP="root"; fi
    return 0
}

detect_stop_timeout() {
    local v=""
    v="$("${BIN_FILE}" -r '$c=@include getenv("TM_CFG"); echo (int)($c["stop_timeout"] ?? 20);' 2>/dev/null || true)"
    case "${v}" in
        ''|*[!0-9]*) v=20 ;;
    esac
    if [ "${v}" -lt 5 ]; then v=20; fi
    STOP_TIMEOUT="${v}"
    return 0
}

# 把老命名的 unit 收掉。只处理确认属于本站的那一个；同名但属于别的部署的原样保留。
migrate_legacy_unit() {
    [ "${SERVICE_NAME}" != "${LEGACY_NAME}" ] || return 0
    if [ -f "${LEGACY_FILE}" ] && ! legacy_is_ours; then
        echo "提示：/etc/systemd/system/${LEGACY_NAME}.service 属于另一个部署，未做改动。"
        return 0
    fi
    legacy_is_ours || return 0

    say "发现旧命名的服务 ${LEGACY_NAME}.service，正在迁移到 ${SERVICE_NAME}.service"
    ${SUDO} systemctl stop "${LEGACY_NAME}" >/dev/null 2>&1 || true
    ${SUDO} systemctl disable "${LEGACY_NAME}" >/dev/null 2>&1 || true
    ${SUDO} rm -f "${LEGACY_FILE}"
    ${SUDO} systemctl reset-failed "${LEGACY_NAME}" >/dev/null 2>&1 || true
    ${SUDO} systemctl daemon-reload
    say "旧服务已移除（守护进程稍后由新服务拉起）"
}

write_service() {
    detect_user
    TM_CFG="${PLUGIN_DIR}/Config/Config.php" detect_stop_timeout

    local tmp
    tmp="$(mktemp)"
    cat > "${tmp}" <<SERVICE
[Unit]
Description=ThreadManager @ ${PROJECT_ROOT}
Documentation=file://${PLUGIN_DIR}
After=network.target mysql.service mariadb.service redis.service
Wants=network.target

[Service]
Type=simple
User=${RUN_USER}
Group=${RUN_GROUP}
WorkingDirectory=${PROJECT_ROOT}

ExecStart=${BIN_FILE} -d opcache.enable_cli=1 -d opcache.jit=off -d memory_limit=-1 ${DAEMON_FILE}

Restart=always
RestartSec=3

SuccessExitStatus=0

KillSignal=SIGTERM
KillMode=mixed
TimeoutStopSec=$((STOP_TIMEOUT + 10))

TimeoutStartSec=0

StandardInput=null
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${SERVICE_NAME}

LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
SERVICE

    ${SUDO} cp "${tmp}" "${SERVICE_FILE}"
    rm -f "${tmp}"
    ${SUDO} systemctl daemon-reload
    echo "unit 已写入 ${SERVICE_FILE}（User=${RUN_USER}:${RUN_GROUP}, TimeoutStopSec=$((STOP_TIMEOUT + 10))）"
}

# ---------------- 容器 / 无 systemd 模式 ----------------
#
# 守护进程本体从来就不依赖 systemd —— unit 用的是 Type=simple，它就是个前台进程。
# 所以容器里不需要任何特殊改造，只是「谁在它退出后拉起它」换成了 Docker 的重启策略
# （或者 supervisord / s6）。下面这组函数把 systemd 那份能力用 PID 文件重做一遍。

STATE_DIR_ABS="${PROJECT_ROOT}/runtime/plugin/${PLUGIN_NAME}"
LOCK_FILE="${STATE_DIR_ABS}/daemon.lock"
OUT_FILE="${STATE_DIR_ABS}/daemon.out"
RUNTIME_LOG="${PLUGIN_DIR}/runtime.log"

# 守护进程的 PID。Daemon.php 启动时会把自己的 pid 写进 daemon.lock（并持有排他 flock），
# 干净退出时删掉它。崩溃退出时文件会留下 → 再用 /proc/<pid>/cmdline 复核一遍，
# 免得 PID 被复用之后把别人的进程当成自己的守护进程。
daemon_pid() {
    local pid=""
    [ -f "${LOCK_FILE}" ] || return 1
    pid="$(head -c 32 "${LOCK_FILE}" 2>/dev/null | tr -dc '0-9' || true)"
    [ -n "${pid}" ] || return 1
    kill -0 "${pid}" 2>/dev/null || return 1
    if [ -r "/proc/${pid}/cmdline" ]; then
        tr '\0' ' ' < "/proc/${pid}/cmdline" 2>/dev/null | grep -qF "${DAEMON_FILE}" || return 1
    fi
    printf '%s' "${pid}"
}

# 收掉本站残留的守护进程/工作进程。
#
# 主进程被 SIGKILL 时（supervisord 在 stopwaitsecs 超时后就会这么干），Swoole 的
# 工作进程会变成孤儿，并且**继续持有 daemon.lock 的 flock**（fork 时继承了那个 fd）。
# 于是新实例永远拿不到锁、退出码 4，supervisord 连试三次直接 FATAL，守护进程永久停摆。
#
# 只在确认没有活着的主进程时才收——靠 cmdline 精确匹配本站的 Daemon.php，
# 不会误伤同机其它站点的守护进程。
reap_orphans() {
    [ -d /proc ] || return 0
    local p pid
    for p in /proc/[0-9]*; do
        pid="${p#/proc/}"
        [ -r "${p}/cmdline" ] || continue
        tr '\0' ' ' < "${p}/cmdline" 2>/dev/null | grep -qF "${DAEMON_FILE}" || continue
        kill -9 "${pid}" 2>/dev/null || true
    done
}

DAEMON_ARGV=()

# 拼出守护进程的完整命令行，必要时包一层降权。
#
# 容器里默认就是 root，而站点文件多半属于 www / www-data。
# 用 root 跑守护进程 → runtime/ 下写出 root 属主的文件，php-fpm 之后就写不动了，
# 表现为面板一切正常但配置怎么改都不生效。systemd 那条路靠 unit 里的 User= 解决，
# 这里得自己来。
build_daemon_argv() {
    DAEMON_ARGV=("${BIN_FILE}" -d opcache.enable_cli=1 -d opcache.jit=off -d memory_limit=-1 "${DAEMON_FILE}")

    [ "$(id -u)" -eq 0 ] || return 0
    detect_user
    [ "${RUN_USER}" != "root" ] || return 0

    if command -v setpriv >/dev/null 2>&1 && setpriv --help 2>&1 | grep -q -- '--reuid'; then
        DAEMON_ARGV=(setpriv --reuid "${RUN_USER}" --regid "${RUN_GROUP}" --init-groups "${DAEMON_ARGV[@]}")
        say "降权运行：${RUN_USER}:${RUN_GROUP}（setpriv）"
    elif command -v su >/dev/null 2>&1; then
        local q="" a
        for a in "${DAEMON_ARGV[@]}"; do q="${q} $(printf '%q' "${a}")"; done
        DAEMON_ARGV=(su -s /bin/sh -c "exec ${q# }" "${RUN_USER}")
        say "降权运行：${RUN_USER}（su）"
    else
        say "警告：当前是 root，但 runtime/ 属主是 ${RUN_USER}，且 setpriv / su 都没有。"
        say "      守护进程只能以 root 运行，它写出的文件 php-fpm 可能读写不了。"
        say "      建议给容器加 USER，或整站统一用 root（TM_USER=root 可消除本提示）。"
    fi
}

# 前台运行。容器的 CMD / supervisord / s6 用这个 —— 日志直接吐 stdout，docker logs 能看见。
container_run() {
    ensure_binary
    # 锁文件里的 PID 已经死了却还有进程在跑 = 上一轮被强杀留下的孤儿，收掉再起
    if [ -z "$(daemon_pid || true)" ]; then
        reap_orphans
    fi
    build_daemon_argv
    export TM_FOREGROUND="${TM_FOREGROUND:-1}"
    cd "${PROJECT_ROOT}"
    exec "${DAEMON_ARGV[@]}"
}

container_start() {
    ensure_binary

    # 镜像提供了托管钩子就交给它（官方镜像用 supervisord）：容器重建自动拉起、
    # 崩溃自动重启、docker stop 时优雅收尾，比下面 nohup 出来的野进程可靠得多。
    if [ -x /usr/local/bin/acg-supervise-threadmanager ]; then
        say "交给容器的进程管理器托管…"
        if /usr/local/bin/acg-supervise-threadmanager; then
            local i=0
            while [ "${i}" -lt 20 ]; do
                if [ -n "$(daemon_pid || true)" ]; then
                    echo "✔ 守护进程已启动并被容器托管（PID $(daemon_pid)）"
                    return 0
                fi
                sleep 1
                i=$((i + 1))
            done
            say "托管已登记，但守护进程还没起来，回退到直接启动"
        fi
    fi

    local pid
    pid="$(daemon_pid || true)"
    if [ -z "${pid}" ]; then
        reap_orphans
    fi
    if [ -n "${pid}" ]; then
        echo "守护进程已经在运行（PID ${pid}），无需重复启动"
        return 0
    fi

    mkdir -p "${STATE_DIR_ABS}" 2>/dev/null || true
    : > "${OUT_FILE}" 2>/dev/null || true

    build_daemon_argv

    # 上面这些目录是以 root 建的，而守护进程会降权到站点属主跑。
    # 不把属主改过来，它连自己的单例锁文件都创建不了（"无法打开锁文件"）。
    if [ "$(id -u)" -eq 0 ] && [ -n "${RUN_USER:-}" ] && [ "${RUN_USER}" != "root" ]; then
        chown -R "${RUN_USER}:${RUN_GROUP}" "${STATE_DIR_ABS}" 2>/dev/null || true
    fi

    # stdout/stderr 单独落到 daemon.out：启动阶段的致命错误（缺 pcntl、锁被占、
    # 连接数超预算）只会写到 stderr，不进 runtime.log，捞不到就等于什么线索都没有。
    if command -v setsid >/dev/null 2>&1; then
        ( cd "${PROJECT_ROOT}" && exec setsid "${DAEMON_ARGV[@]}" >>"${OUT_FILE}" 2>&1 ) &
    else
        ( cd "${PROJECT_ROOT}" && exec nohup "${DAEMON_ARGV[@]}" >>"${OUT_FILE}" 2>&1 ) &
    fi

    local i=0
    while [ "${i}" -lt 15 ]; do
        pid="$(daemon_pid || true)"
        [ -z "${pid}" ] || break
        sleep 1
        i=$((i + 1))
    done

    if [ -z "${pid}" ]; then
        echo "✘ 守护进程没能起来。它的输出：" >&2
        if [ -s "${OUT_FILE}" ]; then
            sed 's/^/    /' "${OUT_FILE}" >&2
        else
            echo "    （一个字都没输出，检查 ${BIN_FILE} 是否可执行、架构是否匹配）" >&2
        fi
        exit 1
    fi

    # 锁写完之后才轮到连数据库、算连接预算，那一段挂掉的话前面已经报「启动成功」了。
    # 再等两秒复核一次，避免报喜之后进程其实已经没了。
    sleep 2
    if [ -z "$(daemon_pid || true)" ]; then
        echo "✘ 守护进程起来之后又退出了。它的输出：" >&2
        [ -s "${OUT_FILE}" ] && sed 's/^/    /' "${OUT_FILE}" >&2 || true
        exit 1
    fi

    echo "✔ 守护进程已启动（PID ${pid}）"
}

container_stop() {
    local pid t deadline
    pid="$(daemon_pid || true)"
    if [ -z "${pid}" ]; then
        echo "守护进程没有在运行"
        return 0
    fi

    TM_CFG="${PLUGIN_DIR}/Config/Config.php" detect_stop_timeout
    deadline=$((STOP_TIMEOUT + 10))

    echo "正在停止（PID ${pid}，最多等 ${deadline} 秒让任务收尾）…"
    kill -TERM "${pid}" 2>/dev/null || true

    t=0
    while [ "${t}" -lt "${deadline}" ]; do
        if ! kill -0 "${pid}" 2>/dev/null; then
            echo "✔ 已停止"
            return 0
        fi
        sleep 1
        t=$((t + 1))
    done

    say "超时未退出，强制 KILL"
    kill -KILL "${pid}" 2>/dev/null || true
    echo "✔ 已强制停止"
}

container_status() {
    local pid
    pid="$(daemon_pid || true)"

    echo "运行模式：容器 / 无 systemd（TM_MODE=${TM_MODE:-auto}）"
    echo "站点根  ：${PROJECT_ROOT}"
    if [ -x "${BIN_FILE}" ]; then
        echo "二进制  ：${BIN_FILE}"
    else
        echo "二进制  ：${BIN_FILE}  ← 不存在或没有可执行权限"
    fi

    if [ -n "${pid}" ]; then
        echo "守护进程：运行中（PID ${pid}）"
        echo
        echo "任务的实时状态请看后台面板：通用插件 → 线程管理器 → 线程管理"
        return 0
    fi

    echo "守护进程：未运行"
    if [ -s "${OUT_FILE}" ]; then
        echo
        echo "最后一次启动的输出（${OUT_FILE}）："
        tail -n 20 "${OUT_FILE}" | sed 's/^/    /'
    fi
}

container_log() {
    if [ -s "${OUT_FILE}" ]; then
        echo "—— 启动输出 ${OUT_FILE} ——"
        tail -n 30 "${OUT_FILE}"
        echo
    fi
    echo "—— 运行日志 ${RUNTIME_LOG} ——"
    if [ -f "${RUNTIME_LOG}" ]; then
        tail -n 100 "${RUNTIME_LOG}"
    else
        echo "（还没有日志）"
    fi
}

container_install_note() {
    # 已经被容器的进程管理器接管时，下面那套"自己想办法保活"的说明就是错的
    if [ -x /usr/local/bin/acg-supervise-threadmanager ]; then
        echo
        echo "✔ 守护进程已由容器的进程管理器（supervisord）托管。"
        echo "  容器重启会自动拉起，崩溃会自动重启，docker stop 时按 stop_timeout 优雅收尾。"
        echo "  到后台「通用插件」启用「线程管理器」，左侧即可看到它的面板。"
        return 0
    fi

    echo
    echo "✔ 已在当前环境启动守护进程（没有检测到 systemd，走容器模式）。"
    echo "  到后台「通用插件」启用「线程管理器」，左侧即可看到它的面板。"
    echo
    echo "  ⚠ 这样起的进程活不过容器重建 —— 容器一重启就没了，面板会显示「守护进程未运行」。"
    echo "     想让它自己回来，二选一："
    echo
    echo "  ① 给守护进程单独一个容器（推荐，最干净）："
    echo
    echo "     threadmanager:"
    echo "       image: <和 php 容器同一个镜像>"
    echo "       restart: always"
    echo "       working_dir: ${PROJECT_ROOT}"
    echo "       command: ./app/Plugin/ThreadManager/service.sh run"
    echo "       volumes: [ '<站点目录>:${PROJECT_ROOT}' ]"
    echo
    echo "     面板判活看的是 runtime 里状态文件的时间戳而不是进程号，"
    echo "     所以守护进程和 php-fpm 不在同一个容器里也能正常识别，只要站点目录是同一个卷。"
    echo
    echo "  ② 留在 php 容器里，交给 supervisord / s6 托管："
    echo
    echo "     [program:threadmanager]"
    echo "     command=${PLUGIN_DIR}/service.sh run"
    echo "     directory=${PROJECT_ROOT}"
    echo "     autostart=true"
    echo "     autorestart=true"
    if [ "$(id -u)" -eq 0 ]; then
        detect_user
        echo "     user=${RUN_USER}"
    fi
}

case "${1:-}" in
    install)
        # 下二进制这件事跟 systemd 一点关系都没有，必须排在模式判断前面 ——
        # 1.0.5 之前 ensure_systemctl 卡在最前面，容器用户连 swoole-cli 都下不下来。
        download_binary "${@:2}"
        ensure_binary

        if has_systemd; then
            migrate_legacy_unit          # 先收掉旧命名，免得两个 unit 抢同一个 daemon.lock 互相重启
            write_service
            ${SUDO} systemctl enable "${SERVICE_NAME}"
            ${SUDO} systemctl restart "${SERVICE_NAME}"
            echo
            echo "✔ ${SERVICE_NAME}.service 已安装并启动，守护进程已在运行。"
            echo "  服务名带了项目路径指纹，同一台服务器上多套程序互不干扰。"
            echo "  到后台「通用插件」启用「线程管理器」，左侧即可看到它的面板。"
        else
            echo
            # 对齐 systemd 分支结尾的 `systemctl restart`：升级完二进制必须换掉正在跑的旧进程，
            # 直接 start 的话会撞上「已经在运行」而静默跳过，旧二进制一直跑到下次重启。
            container_stop
            container_start
            container_install_note
        fi
        ;;
    run)
        # 前台运行，不分模式：容器 CMD、supervisord、s6，或者只是想看着它跑一遍。
        container_run
        ;;
    start)
        if has_systemd; then
            resolve_service; ensure_service_file
            ${SUDO} systemctl start "${SERVICE_NAME}"; echo "已启动（${SERVICE_NAME}）"
        else
            container_start
        fi
        ;;
    stop)
        if has_systemd; then
            resolve_service
            ${SUDO} systemctl stop "${SERVICE_NAME}" || true; echo "已停止（${SERVICE_NAME}）"
        else
            container_stop
        fi
        ;;
    restart)
        if has_systemd; then
            resolve_service; ensure_service_file
            ${SUDO} systemctl restart "${SERVICE_NAME}"; echo "已重启（${SERVICE_NAME}）"
        else
            container_stop
            container_start
        fi
        ;;
    status)
        if has_systemd; then
            resolve_service; ensure_service_file
            # 服务停着的时候 systemctl 返回 3，别让 set -e 把脚本崩掉再吐一行看不懂的 ERR
            ${SUDO} systemctl status "${SERVICE_NAME}" --no-pager || true
        else
            container_status
        fi
        ;;
    log)
        if has_systemd; then
            resolve_service
            ${SUDO} journalctl -u "${SERVICE_NAME}" -n 100 --no-pager || true
        else
            container_log
        fi
        ;;
    uninstall)
        if ! has_systemd; then
            container_stop
            echo "容器模式下没有往主机上装任何东西，停掉进程即可。"
            echo "（swoole-cli 和 runtime/ 都保留，插件本身不受影响）"
            exit 0
        fi
        # 新旧两个名字都清掉，但旧的只清属于本站的那个
        removed=""
        for svc in "${SERVICE_NAME}" "${LEGACY_NAME}"; do
            file="/etc/systemd/system/${svc}.service"
            [ -f "${file}" ] || continue
            if [ "${svc}" = "${LEGACY_NAME}" ] && [ "${svc}" != "${SERVICE_NAME}" ] && ! legacy_is_ours; then
                echo "跳过 ${svc}.service：属于另一个部署"
                continue
            fi
            ${SUDO} systemctl stop "${svc}" >/dev/null 2>&1 || true
            ${SUDO} systemctl disable "${svc}" >/dev/null 2>&1 || true
            ${SUDO} rm -f "${file}"
            ${SUDO} systemctl reset-failed "${svc}" >/dev/null 2>&1 || true
            removed="${removed} ${svc}.service"
        done
        ${SUDO} systemctl daemon-reload
        if [ -n "${removed}" ]; then
            echo "已卸载：${removed# }（swoole-cli 和 runtime/ 都保留，插件本身不受影响）"
        else
            echo "没有找到本站的服务，无需卸载"
        fi
        ;;
    *)
        usage
        ;;
esac
