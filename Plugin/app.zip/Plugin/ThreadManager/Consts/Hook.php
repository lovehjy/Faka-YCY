<?php
declare(strict_types=1);

namespace App\Plugin\ThreadManager\Consts;

interface Hook
{

    public const TASK_REGISTER = 0x7A100;

    public const TASK_EVENT = 0x7A101;
}
