[
    {
        name: "客服浮窗",
        form: [
            {
                title: false,
                name: "widget_icon_image",
                type: "custom",
                complete: function (form, dom) {
                    var assigned = form && form.opt && form.opt.assign ? form.opt.assign : {};
                    var value = String(assigned.widget_icon_image || "/app/Plugin/KFFS/TB/cshtb.jpg");
                    var esc = function (value) {
                        return $("<div>").text(String(value == null ? "" : value)).html();
                    };
                    var upload = function (file, target) {
                        if (!file) return;
                        if (file.size > 2097152) {
                            window.layer && window.layer.msg("图片不能超过 2MB");
                            return;
                        }
                        var data = new FormData();
                        data.append("file", file);
                        $.ajax({
                            url: "/plugin/KFFS/api/upload",
                            method: "POST",
                            data: data,
                            processData: false,
                            contentType: false,
                            success: function (res) {
                                var url = res && res.data && res.data.url;
                                if (res && res.code === 200 && url) {
                                    target.val(url).trigger("change");
                                    window.layer && window.layer.msg("图片上传成功");
                                } else {
                                    window.layer && window.layer.msg((res && res.msg) || "图片上传失败");
                                }
                            },
                            error: function () {
                                window.layer && window.layer.msg("图片上传失败");
                            }
                        });
                    };

                    dom.html(
                        '<div class="kffs-ios-shell kffs-ios-image">' +
                        '<div class="kffs-ios-image-preview"><img class="kffs-ios-preview" src="' + esc(value) + '" alt=""></div>' +
                        '<div class="kffs-ios-image-main">' +
                        '<div class="kffs-ios-caption">浮窗入口图片</div>' +
                        '<input class="form-control kffs-ios-image-url" name="widget_icon_image" value="' + esc(value) + '" placeholder="输入图床 URL">' +
                        '<label class="kffs-ios-upload"><span>选择本地图片</span><input class="kffs-ios-file" type="file" accept="image/*"></label>' +
                        '<div class="kffs-ios-help">本地图片自动保存到 KFFS/TB</div>' +
                        '</div>' +
                        '</div>' +
                        '<style>' +
                        '.kffs-ios-image{display:flex;align-items:center;gap:16px;padding:16px;border:1px solid rgba(118,145,180,.22);border-radius:18px;background:linear-gradient(135deg,rgba(255,255,255,.82),rgba(235,243,253,.62));box-shadow:0 8px 24px rgba(46,75,112,.08);box-sizing:border-box}' +
                        '.kffs-ios-image-preview{width:78px;height:78px;flex:0 0 78px;border-radius:20px;overflow:hidden;background:#edf3fa;box-shadow:0 5px 14px rgba(36,62,96,.12);border:3px solid rgba(255,255,255,.9)}' +
                        '.kffs-ios-preview{display:block;width:100%;height:100%;object-fit:cover}' +
                        '.kffs-ios-image-main{min-width:0;flex:1}.kffs-ios-caption{margin-bottom:8px;color:#20324a;font-size:14px;font-weight:700}' +
                        '.kffs-ios-image-url{height:42px!important;line-height:42px!important;border-radius:12px!important;border:1px solid rgba(118,145,180,.28)!important;background:rgba(255,255,255,.72)!important;box-sizing:border-box!important}' +
                        '.kffs-ios-upload{display:inline-flex;align-items:center;min-height:34px;margin-top:9px;border-radius:10px;padding:0 13px;background:#1677e8;color:#fff;font-size:12px;cursor:pointer;box-shadow:0 5px 12px rgba(22,119,232,.2)}' +
                        '.kffs-ios-upload input{display:none}.kffs-ios-help{margin-top:7px;color:#8291a4;font-size:11px}' +
                        '@media(max-width:520px){.kffs-ios-image{align-items:flex-start;flex-direction:column}.kffs-ios-image-preview{width:88px;height:88px;flex-basis:88px}}' +
                        '</style>'
                    );

                    var input = dom.find(".kffs-ios-image-url");
                    var preview = dom.find(".kffs-ios-preview");
                    input.on("input change", function () {
                        var src = String(input.val() || "").trim();
                        preview.attr("src", src || "/app/Plugin/KFFS/TB/cshtb.jpg");
                    });
                    dom.find(".kffs-ios-file").on("change", function () {
                        upload(this.files && this.files[0], input);
                    });
                }
            },
            {
                title: "浮窗标题",
                name: "title",
                type: "input",
                default: "联系客服",
                placeholder: "例如：联系客服"
            },
            {
                title: "浮窗说明",
                name: "subtitle",
                type: "input",
                default: "请选择一种联系方式",
                placeholder: "例如：请选择一种联系方式"
            },
            {
                title: "显示位置",
                name: "position",
                type: "select",
                dict: [
                    {id: "right", name: "右下角"},
                    {id: "left", name: "左下角"}
                ],
                default: "right"
            },
            {
                title: "图标宽度（px）",
                name: "icon_width",
                type: "number",
                default: "56",
                placeholder: "32 - 200"
            },
            {
                title: "图标高度（px）",
                name: "icon_height",
                type: "number",
                default: "56",
                placeholder: "32 - 200"
            },
            {
                title: "面板宽度（px）",
                name: "panel_width",
                type: "number",
                default: "350",
                placeholder: "220 - 600"
            },
            {
                title: "面板高度",
                name: "panel_height",
                type: "input",
                default: "auto",
                placeholder: "auto 或 200 - 900"
            },
            {
                title: "水平偏移（px）",
                name: "offset_x",
                type: "number",
                default: "20",
                placeholder: "距离屏幕边缘"
            },
            {
                title: "导航栏上移距离（px）",
                name: "offset_y",
                type: "number",
                default: "16",
                placeholder: "自动避开底部导航"
            },
            {
                title: "主题颜色",
                name: "accent",
                type: "input",
                default: "#2563eb",
                placeholder: "#2563eb"
            },
            {
                title: false,
                name: "contacts_editor",
                type: "custom",
                complete: function (form, dom) {
                    var assigned = form && form.opt && form.opt.assign ? form.opt.assign : {};
                    var list = [];
                    try {
                        list = JSON.parse(String(assigned.contacts || "[]"));
                    } catch (error) {
                        list = [];
                    }
                    if (!Array.isArray(list) || list.length === 0) {
                        list = [{
                            icon_image: "/app/Plugin/KFFS/TB/cshtb.jpg",
                            name: "新客服",
                            button: "联系",
                            action: "url",
                            target: ""
                        }];
                    }

                    var esc = function (value) {
                        return $("<div>").text(String(value == null ? "" : value)).html();
                    };
                    var upload = function (file, target) {
                        if (!file) return;
                        if (file.size > 2097152) {
                            window.layer && window.layer.msg("图片不能超过 2MB");
                            return;
                        }
                        var data = new FormData();
                        data.append("file", file);
                        $.ajax({
                            url: "/plugin/KFFS/api/upload",
                            method: "POST",
                            data: data,
                            processData: false,
                            contentType: false,
                            success: function (res) {
                                var url = res && res.data && res.data.url;
                                if (res && res.code === 200 && url) {
                                    target.val(url).trigger("change");
                                    window.layer && window.layer.msg("图片上传成功");
                                } else {
                                    window.layer && window.layer.msg((res && res.msg) || "图片上传失败");
                                }
                            },
                            error: function () {
                                window.layer && window.layer.msg("图片上传失败");
                            }
                        });
                    };
                    var sync = function () {
                        var result = [];
                        dom.find(".kffs-ios-contact").each(function () {
                            var row = $(this);
                            result.push({
                                icon_image: row.find(".kffs-contact-image").val() || "/app/Plugin/KFFS/TB/cshtb.jpg",
                                name: row.find(".kffs-contact-name").val() || "客服",
                                button: row.find(".kffs-contact-button").val() || "联系",
                                action: row.find(".kffs-contact-action").val() || "url",
                                target: row.find(".kffs-contact-target").val() || ""
                            });
                        });
                        dom.find(".kffs-contact-value").val(JSON.stringify(result)).trigger("change");
                    };
                    var render = function () {
                        var html = '<div class="kffs-ios-contacts">';
                        list.forEach(function (item) {
                            item = item || {};
                            html += '<div class="kffs-ios-contact">';
                            html += '<div class="kffs-ios-contact-head"><strong>客服方式</strong><button type="button" class="kffs-contact-remove">移除</button></div>';
                            html += '<div class="kffs-ios-contact-grid">';
                            html += '<input class="form-control kffs-contact-image" placeholder="图标图片 URL" value="' + esc(item.icon_image || "/app/Plugin/KFFS/TB/cshtb.jpg") + '">';
                            html += '<input class="form-control kffs-contact-file" type="file" accept="image/*">';
                            html += '<input class="form-control kffs-contact-name" placeholder="联系方式名称" value="' + esc(item.name || "") + '">';
                            html += '<input class="form-control kffs-contact-button" placeholder="按钮文字" value="' + esc(item.button || "") + '">';
                            html += '<select class="form-control kffs-contact-action" aria-label="按钮行为"><option value="url">打开链接</option><option value="copy">复制内容</option><option value="phone">拨号</option><option value="email">发邮件</option></select>';
                            html += '<input class="form-control kffs-contact-target" placeholder="链接、号码或复制内容" value="' + esc(item.target || "") + '">';
                            html += '</div></div>';
                        });
                        html += '<button type="button" class="kffs-contact-add">＋ 添加联系方式</button>';
                        html += '<textarea name="contacts" class="kffs-contact-value" style="display:none" data-kffs-persist="1"></textarea>';
                        html += '<style>' +
                            '.kffs-ios-contacts{padding:16px;border:1px solid rgba(118,145,180,.22);border-radius:18px;background:rgba(255,255,255,.56);box-shadow:0 7px 20px rgba(46,75,112,.06)}' +
                            '.kffs-ios-contact{padding:13px;border:1px solid rgba(118,145,180,.2);border-radius:14px;background:rgba(255,255,255,.64);margin-bottom:10px}' +
                            '.kffs-ios-contact-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;color:#20324a;font-size:13px}.kffs-contact-remove{border:0;border-radius:8px;padding:5px 9px;background:rgba(231,76,60,.1);color:#c94b42;font-size:11px;cursor:pointer}' +
                            '.kffs-ios-contact-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}.kffs-ios-contact-grid input,.kffs-ios-contact-grid select{box-sizing:border-box;min-width:0;width:100%;height:42px!important;border-radius:11px!important;border:1px solid rgba(118,145,180,.24)!important;background:rgba(255,255,255,.78)!important}.kffs-contact-action{display:block!important;appearance:auto!important;-webkit-appearance:auto!important;padding:0 12px!important;color:#172033!important;font-size:13px!important;opacity:1!important;visibility:visible!important}.kffs-contact-file{padding:8px!important;color:#2676d3;font-size:12px!important}.kffs-contact-add{width:100%;height:42px;border:0;border-radius:12px;background:#1677e8;color:#fff;font-size:13px;cursor:pointer;box-shadow:0 7px 16px rgba(22,119,232,.2)}' +
                            '@media(max-width:560px){.kffs-ios-contact-grid{grid-template-columns:1fr}}' +
                            '</style></div>';
                        dom.html(html);
                        list.forEach(function (item, index) {
                            var action = item.action || "url";
                            var select = dom.find(".kffs-ios-contact").eq(index).find(".kffs-contact-action");
                            select.val(action);
                            if (select.val() !== action) {
                                select.find('option[value="' + action + '"]').prop("selected", true);
                            }
                        });
                        sync();
                    };

                    dom.off(".kffs-ios");
                    dom.on("input.kffs-ios change.kffs-ios", "input,select", sync);
                    dom.on("change.kffs-ios", ".kffs-contact-file", function () {
                        var row = $(this).closest(".kffs-ios-contact");
                        upload(this.files && this.files[0], row.find(".kffs-contact-image"));
                        this.value = "";
                    });
                    dom.on("click.kffs-ios", ".kffs-contact-add", function (event) {
                        event.preventDefault();
                        sync();
                        try {
                            list = JSON.parse(dom.find(".kffs-contact-value").val() || "[]");
                        } catch (error) {
                            list = [];
                        }
                        list.push({
                            icon_image: "/app/Plugin/KFFS/TB/cshtb.jpg",
                            name: "新客服",
                            button: "联系",
                            action: "url",
                            target: ""
                        });
                        render();
                    });
                    dom.on("click.kffs-ios", ".kffs-contact-remove", function (event) {
                        event.preventDefault();
                        sync();
                        list.splice($(this).closest(".kffs-ios-contact").index(), 1);
                        if (list.length === 0) {
                            list.push({
                                icon_image: "/app/Plugin/KFFS/TB/cshtb.jpg",
                                name: "新客服",
                                button: "联系",
                                action: "url",
                                target: ""
                            });
                        }
                        render();
                    });
                    render();
                }
            },
            {
                title: "说明",
                name: "kffs_help",
                type: "explain",
                placeholder: "所有图标使用图片，不需要图片类名。本地图片上传到 KFFS/TB，浮窗会自动避开手机和电脑底部导航。"
            }
        ]
    }
]