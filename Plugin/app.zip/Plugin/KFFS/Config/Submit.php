<?php
declare(strict_types=1);

return [
    ['title' => '浮窗图标', 'name' => 'widget_icon_image', 'type' => 'custom', 'default' => '/app/Plugin/KFFS/TB/cshtb.jpg', 'tips' => '支持图床 URL；选择本地图片后会上传到 /app/Plugin/KFFS/TB/。'],
    ['title' => '浮窗标题', 'name' => 'title', 'type' => 'input', 'default' => '联系客服'],
    ['title' => '浮窗说明', 'name' => 'subtitle', 'type' => 'input', 'default' => '请选择一种联系方式'],
    [
        'title' => '显示位置',
        'name' => 'position',
        'type' => 'select',
        'dict' => [['id' => 'right', 'name' => '右下角'], ['id' => 'left', 'name' => '左下角']],
        'default' => 'right'
    ],
    ['title' => '图标宽度（px）', 'name' => 'icon_width', 'type' => 'number', 'default' => '56', 'placeholder' => '32 - 200'],
    ['title' => '图标高度（px）', 'name' => 'icon_height', 'type' => 'number', 'default' => '56', 'placeholder' => '32 - 200'],
    ['title' => '面板宽度（px）', 'name' => 'panel_width', 'type' => 'number', 'default' => '350', 'placeholder' => '220 - 600'],
    ['title' => '面板高度（px）', 'name' => 'panel_height', 'type' => 'number', 'default' => 'auto', 'placeholder' => 'auto 或 200 - 900'],
    ['title' => '水平偏移（px）', 'name' => 'offset_x', 'type' => 'number', 'default' => '20'],
    ['title' => '导航栏上移距离（px）', 'name' => 'offset_y', 'type' => 'number', 'default' => '16'],
    ['title' => '主题颜色', 'name' => 'accent', 'type' => 'input', 'default' => '#2563eb'],
    ['title' => false, 'name' => 'contacts_editor', 'type' => 'custom', 'tips' => '点击“添加联系方式”新增；上传按钮支持动态新增的联系方式。'],
    ['title' => '说明', 'name' => 'kffs_help', 'type' => 'explain', 'placeholder' => '所有图标使用图片，不需要图片类名。本地图片上传到 KFFS/TB。']
];