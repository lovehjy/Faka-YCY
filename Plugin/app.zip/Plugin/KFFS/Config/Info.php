<?php
declare(strict_types=1);

use App\Consts\Plugin;

return [
    Plugin::NAME => '客服方式',
    Plugin::AUTHOR => '自定义',
    Plugin::WEB_SITE => '#',
    Plugin::DESCRIPTION => '在网站右下角显示可配置的客服联系方式浮窗。',
    Plugin::VERSION => '1.0.0'
];