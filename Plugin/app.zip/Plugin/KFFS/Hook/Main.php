<?php
declare(strict_types=1);

namespace App\Plugin\KFFS\Hook;

use App\Controller\Base\View\UserPlugin;
use Kernel\Annotation\Hook;

final class Main extends UserPlugin
{
    private const PLUGIN = 'KFFS';
    #[Hook(point: \App\Consts\Hook::USER_GLOBAL_VIEW_BODY)]
    public function body(): string
    {
        return $this->renderWidget();
    }

    private function renderWidget(): string
    {
        $config = getPluginConfig(self::PLUGIN);
        $contacts = json_decode((string)($config['contacts'] ?? '[]'), true);

        if (!is_array($contacts)) {
            $contacts = [];
        }

        $safeContacts = [];
        foreach ($contacts as $contact) {
            if (!is_array($contact)) {
                continue;
            }

            $action = (string)($contact['action'] ?? 'url');
            if (!in_array($action, ['url', 'copy', 'phone', 'email'], true)) {
                $action = 'url';
            }

            $target = trim((string)($contact['target'] ?? ''));

            $iconImage = trim((string)($contact['icon_image'] ?? $contact['icon'] ?? '/app/Plugin/KFFS/TB/cshtb.jpg'));
            if ($iconImage === '' || !preg_match('#^(?:https?:)?//|^/#i', $iconImage)) {
                $iconImage = '/app/Plugin/KFFS/TB/cshtb.jpg';
            }

            $safeContacts[] = [
                'iconImage' => htmlspecialchars($iconImage, ENT_QUOTES, 'UTF-8'),
                'name' => htmlspecialchars(trim((string)($contact['name'] ?? '客服')), ENT_QUOTES, 'UTF-8'),
                'button' => htmlspecialchars(trim((string)($contact['button'] ?? '联系')), ENT_QUOTES, 'UTF-8'),
                'action' => $action,
                'target' => htmlspecialchars($target, ENT_QUOTES, 'UTF-8'),
            ];
        }

        if ($safeContacts === []) {
            return '';
        }

        $accent = trim((string)($config['accent'] ?? '#2563eb'));
        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $accent)) {
            $accent = '#2563eb';
        }

        $widgetIcon = trim((string)($config['widget_icon_image'] ?? '/app/Plugin/KFFS/TB/cshtb.jpg'));
        if ($widgetIcon === '' || !preg_match('#^(?:https?:)?//|^/#i', $widgetIcon)) {
            $widgetIcon = '/app/Plugin/KFFS/TB/cshtb.jpg';
        }
        $iconWidth = max(32, min(200, (int)($config['icon_width'] ?? $config['icon_size'] ?? 56)));
        $iconHeight = max(32, min(200, (int)($config['icon_height'] ?? $config['icon_size'] ?? 56)));
        $panelWidth = max(220, min(600, (int)($config['panel_width'] ?? 350)));
        $panelHeightRaw = trim((string)($config['panel_height'] ?? 'auto'));
        $panelHeight = strtolower($panelHeightRaw) === 'auto' ? 'auto' : max(200, min(900, (int)$panelHeightRaw)) . 'px';
        $offsetX = max(0, min(200, (int)($config['offset_x'] ?? 20)));
        $offsetY = max(0, min(400, (int)($config['offset_y'] ?? 16)));

        return $this->render(null, 'Widget.html', [
            'kffsIconImage' => htmlspecialchars($widgetIcon, ENT_QUOTES, 'UTF-8'),
            'kffsTitle' => htmlspecialchars(trim((string)($config['title'] ?? '联系客服')), ENT_QUOTES, 'UTF-8'),
            'kffsSubtitle' => htmlspecialchars(trim((string)($config['subtitle'] ?? '请选择一种联系方式')), ENT_QUOTES, 'UTF-8'),
            'kffsPosition' => ($config['position'] ?? 'right') === 'left' ? 'left' : 'right',
            'kffsAccent' => $accent,
            'kffsIconWidth' => $iconWidth,
            'kffsIconHeight' => $iconHeight,
            'kffsPanelWidth' => $panelWidth,
            'kffsPanelHeight' => $panelHeight,
            'kffsOffsetX' => $offsetX,
            'kffsOffsetY' => $offsetY,
            'kffsContacts' => $safeContacts,
        ], false);
    }
}