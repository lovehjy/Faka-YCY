<?php
declare(strict_types=1);

namespace App\Plugin\KFFS\Controller;

use App\Controller\Base\API\ManagePlugin;
use App\Interceptor\ManageSession;
use App\Service\Upload;
use Kernel\Annotation\Inject;
use Kernel\Annotation\Interceptor;
use Kernel\Context\Interface\Request;
use Kernel\Exception\JSONException;

#[Interceptor(ManageSession::class, Interceptor::TYPE_API)]
final class Api extends ManagePlugin
{
    #[Inject]
    private Upload $upload;

    public function upload(Request $request): array
    {
        if (!isset($_FILES['file'])) {
            throw new JSONException('请选择图片');
        }

        $dir = BASE_PATH . '/app/Plugin/KFFS/TB';
        $originalName = (string)($_FILES['file']['name'] ?? '');
        $extension = strtolower((string)pathinfo($originalName, PATHINFO_EXTENSION));
        if (!in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
            throw new JSONException('仅支持 jpg、jpeg、png、gif、webp 图片');
        }

        $fileName = 'kffs_' . date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $extension;
        $handle = $this->upload->handle(
            $_FILES['file'],
            $dir,
            ['jpg', 'jpeg', 'png', 'gif', 'webp'],
            2048,
            $fileName
        );

        if (!is_array($handle)) {
            throw new JSONException((string)$handle);
        }

        $storedFile = basename((string)($handle['dir'] ?? ''));
        if ($storedFile === '' || !is_file($dir . '/' . $storedFile)) {
            throw new JSONException('图片上传成功，但无法定位保存的文件');
        }

        $path = '/app/Plugin/KFFS/TB/' . $storedFile;
        @chmod(BASE_PATH . $path, 0644);

        return $this->json(200, '客服图标上传成功', ['url' => $path]);
    }
}