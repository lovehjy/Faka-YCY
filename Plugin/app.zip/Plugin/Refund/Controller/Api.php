<?php
declare (strict_types=1);

namespace App\Plugin\Refund\Controller;

use App\Controller\Base\API\ManagePlugin;
use App\Interceptor\ManageSession;
use App\Interceptor\Waf;
use App\Model\Bill;
use App\Model\ManageLog;
use App\Model\Order;
use App\Model\User;
use Illuminate\Database\Capsule\Manager as DB;
use Kernel\Annotation\Interceptor;
use Kernel\Exception\JSONException;
use Kernel\Util\Decimal;

#[Interceptor([Waf::class, ManageSession::class], Interceptor::TYPE_API)]
class Api extends ManagePlugin
{
    /**
     * 把订单金额退回下单会员的余额，并把订单标记为已退款。
     *
     * @return array
     * @throws JSONException
     */
    public function make(): array
    {
        $orderId = (int)($_POST['order_id'] ?? 0);
        if ($orderId <= 0) {
            throw new JSONException("订单ID为空");
        }

        $refunded = '0.00';

        DB::transaction(function () use ($orderId, &$refunded) {
            /** @var Order|null $order */
            $order = Order::query()->lockForUpdate()->find($orderId);
            if (!$order) {
                throw new JSONException("订单不存在");
            }
            if ((int)$order->status !== 1) {
                throw new JSONException("该订单未支付");
            }
            if ((int)$order->refund_status !== 0) {
                throw new JSONException("该订单已经退过款了");
            }

            $owner = User::query()->find((int)$order->owner);
            if (!$owner instanceof User) {
                throw new JSONException("游客订单没有余额账户，无法退款");
            }

            //issue #932：order.amount 是「商品价 + 支付手续费」（下单时 Order::trade 里
            //  pay_cost = 按支付接口费率算出来的手续费
            //  amount   = amount + pay_cost
            //这笔手续费随付款一起进了支付通道，退款走的是会员余额、通道并不会退回来。
            //退不退由管理员在弹窗里逐单决定（发不出货是站长的问题就全退，买家反悔就扣），
            //这里只认前端传上来的选择，默认扣除。余额支付的订单 pay_cost 恒为 0，两种一样。
            $refundFee = (string)($_POST['refund_fee'] ?? '0') === '1';
            $payCost = (string)($order->pay_cost ?? '0');

            $amount = new Decimal((string)$order->amount, 2);
            if (!$refundFee) {
                $amount = $amount->sub($payCost);
            }
            $refunded = $amount->getAmount();

            //模型没有 casts，金额取出来是字符串；Bill::create 在 strict_types 下只收 float
            $value = (float)$refunded;
            if ($value <= 0) {
                throw new JSONException("可退金额为 0，无需退款");
            }

            //带条件的更新：两个管理员同时点，也只会有一次改成功
            $updated = Order::query()
                ->where("id", $order->id)
                ->where("refund_status", 0)
                ->update(["refund_status" => 1]);
            if ($updated !== 1) {
                throw new JSONException("该订单已经退过款了");
            }

            //退到余额；最后一个 false：退款不计入累计充值
            Bill::create($owner, $value, Bill::TYPE_ADD, "订单退款[{$order->trade_no}]", 0, false);

            //日志写清口径：事后对账要能看出这单退了多少、以及管理员当时选的是扣还是不扣
            $note = "";
            if ((float)$payCost > 0) {
                $note = $refundFee
                    ? "，订单金额 {$order->amount}，支付手续费 {$payCost} 一并退还"
                    : "，订单金额 {$order->amount}，已扣除支付手续费 {$payCost}";
            }
            ManageLog::log($this->getManage(), "订单退款：{$order->trade_no}，{$refunded} 已退回会员 {$owner->username} 的余额{$note}");
        });

        return $this->json(200, "退款成功，已退回 {$refunded}");
    }
}
