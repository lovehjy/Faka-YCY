<?php
declare (strict_types=1);

namespace App\Plugin\Refund\Hook;

use App\Controller\Base\View\ManagePlugin;
use Illuminate\Database\Capsule\Manager;
use Illuminate\Database\Schema\Blueprint;
use Kernel\Annotation\Hook;
use Kernel\Consts\Base;
use Kernel\Plugin\Entity\Column;
use Kernel\Util\Context;

class Main extends ManagePlugin
{
    #[\Kernel\Annotation\Plugin(state: \Kernel\Annotation\Plugin::START)]
    public function init(): void
    {
        if (!Manager::schema()->hasColumn("order", "refund_status")) {
            Manager::schema()->table("order", function (Blueprint $blueprint) {
                $blueprint->tinyInteger("refund_status", false, true)->nullable(false)->default(0);
            });
        }
    }

    /**
     * 给后台订单列表末尾加一列退款按钮（已退款的显示绿色勾）。
     *
     * 旧版靠 ADMIN_VIEW_ORDER_TABLE 把一段列定义直接拼进模板里的 JS。后台重构后订单列表的
     * 列定义搬进了 trade/order.js，那个埋点再没有人输出，插件启动了也什么都不显示。
     * 现在改走 HACK_ROUTE_TABLE_COLUMNS：只声明「哪个接口的表、哪一列旁边、插什么」，
     * 由核心的 Table 组件建表时拼进去，整页加载和 pjax 切页都能拿到。
     *
     * @return array|null
     */
    #[Hook(point: \App\Consts\Hook::HACK_ROUTE_TABLE_COLUMNS)]
    public function column(): ?array
    {
        //同一个钩子前台 Helper 也会调，只对后台路由返回
        if (!str_starts_with((string)Context::get(Base::ROUTE), "/admin")) {
            return null;
        }

        $code = <<<'JS'
{
    field: '_refund_button_hook', title: '', type: 'button', buttons: [
        {
            icon: 'fa-duotone fa-regular fa-money-bill-transfer',
            class: 'text-primary',
            title: '退款',
            click: (event, value, row, index) => {
                //escapeHtml 是 order.js 里的模块内函数，这里拿不到，自己转义
                const esc = s => String(s).replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
                const symbol = (typeof format === 'object' && typeof format.currencySymbol === 'function') ? format.currencySymbol() : '';
                const money = v => symbol + ((typeof format === 'object' && typeof format.amountRemoveTrailingZeros === 'function') ? format.amountRemoveTrailingZeros(v.toFixed(2)) : v.toFixed(2));

                //订单金额是「商品价 + 支付手续费」（下单时 Order::trade 把 pay_cost 加进了 amount）
                const amt = parseFloat(row.amount) || 0;
                const fee = parseFloat(row.pay_cost) || 0;
                const tradeNo = esc(row.trade_no || '-');

                const submit = refundFee => {
                    util.post("/plugin/refund/api/make", {order_id: row.id, refund_fee: refundFee}, res => {
                        message.success(res.msg);
                        $("#order-table").bootstrapTable('refresh', {silent: true});
                    });
                };

                //没收过手续费（余额支付、或支付接口没配费率）就没什么可选的，别多问一句
                if (fee <= 0 || amt - fee <= 0) {
                    message.ask(
                        `${i18n('将把订单')} <b>${tradeNo}</b> ${i18n('的')} <b>${money(amt)}</b> ${i18n('退回该会员的余额，退款后无法撤销。确认继续吗？')}`,
                        () => submit(1),
                        i18n('确认退款'),
                        i18n('确认退款')
                    );
                    return;
                }

                //收过手续费的单，退多少只能站长自己定：发不出货是站长的问题、该全退；
                //买家自己反悔，手续费已经交给通道了、该扣。做成全局开关的话遇到例外
                //就得先跑去改配置，所以把两个金额直接摆在按钮上让他点。
                Swal.fire({
                    title: i18n('确认退款'),
                    icon: 'warning',
                    html: `<div style="text-align:left;font-size:14px;line-height:1.9">
    <div>${i18n('订单')} <b>${tradeNo}</b></div>
    <div>${i18n('订单金额')} <b>${money(amt)}</b>${i18n('，其中支付手续费')} <b>${money(fee)}</b></div>
    <div style="margin-top:10px;font-size:12px;opacity:.72">${i18n('手续费在用户付款时已随款项进入支付通道，退款走的是会员余额，通道不会把这笔钱退回来。')}</div>
    <div style="margin-top:4px;font-size:12px;opacity:.72">${i18n('退款后无法撤销。')}</div>
</div>`,
                    showDenyButton: true,
                    showCancelButton: true,
                    confirmButtonText: `${i18n('扣手续费，退')} ${money(amt - fee)}`,
                    denyButtonText: `${i18n('全额退')} ${money(amt)}`,
                    denyButtonColor: '#6c757d',
                    cancelButtonText: i18n('取消')
                }).then(r => {
                    if (r.isConfirmed) submit(0);
                    else if (r.isDenied) submit(1);
                });
            },
            //未支付没得退；游客单没有余额账户可退
            show: row => Number(row?.status) === 1 && Number(row?.refund_status) !== 1
                && !!((row?.owner && typeof row.owner === 'object') ? row.owner.id : row?.owner)
        },
        {
            icon: 'fa-duotone fa-regular fa-circle-check',
            class: 'text-success',
            title: '已退款',
            click: () => message.warning(i18n('该订单已经退过款了')),
            show: row => Number(row?.refund_status) === 1
        }
    ]
}
JS;

        //放到最后一列，和补单小插件一样的按钮样式
        return (new Column("/admin/api/order/data", $code, "widget", "after"))->toArray();
    }
}
