<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Support;

use App\Plugin\TranslationBot\Service\Paths;

/**
 * 每日用量计数（flock 互斥）。仅作面板展示，不做任何拦截——
 * 想控制成本请直接看面板数字，按需停用插件或调小批次。
 */
class Quota
{
    /**
     * @param string $key calls|items
     * @param int $units 本次累加单位数
     * @return void
     */
    public static function count(string $key, int $units = 1): void
    {
        if ($units <= 0) {
            return;
        }
        $file = Paths::runtime() . '/quota.json';
        $today = date('Ymd');

        $fp = @fopen($file, 'c+');
        if (!$fp) {
            return;
        }
        try {
            flock($fp, LOCK_EX);
            $data = json_decode((string)stream_get_contents($fp), true);
            if (!is_array($data) || ($data['date'] ?? '') !== $today) {
                $data = ['date' => $today, 'counts' => []];
            }
            $data['counts'][$key] = (int)($data['counts'][$key] ?? 0) + $units;
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE));
        } catch (\Throwable $e) {
        } finally {
            if (is_resource($fp)) {
                @flock($fp, LOCK_UN);
                fclose($fp);
            }
        }
    }

    /**
     * @return array ['date'=>Ymd,'counts'=>['calls'=>n,'items'=>n]]
     */
    public static function today(): array
    {
        $file = Paths::runtime() . '/quota.json';
        $data = is_file($file) ? json_decode((string)@file_get_contents($file), true) : null;
        if (!is_array($data) || ($data['date'] ?? '') !== date('Ymd')) {
            return ['date' => date('Ymd'), 'counts' => []];
        }
        return $data;
    }
}
