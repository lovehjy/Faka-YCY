<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Hook;

use App\Plugin\TranslationBot\Service\Paths;
use App\Plugin\TranslationBot\Service\Queue;
use Kernel\Annotation\Hook;
use Kernel\Plugin\Entity\Tab;

class Main
{
    /**
     * 翻译库未命中：只做入队，必须微秒级返回（本钩子发生在响应输出之前）。
     * 消费完全交给「线程管理器」的 consume 常驻任务，本插件不再自发任何 HTTP 请求。
     * @param array $sources
     * @param array $targetLangs
     * @return void
     */
    #[Hook(point: \App\Consts\Hook::LANG_MISS)]
    public function LANG_MISS(array $sources, array $targetLangs): void
    {
        try {
            Queue::push($sources, $targetLangs);
        } catch (\Throwable $e) {
            //任何异常都不允许影响主流程
        }
    }

    /**
     * 后台左侧菜单：翻译队列面板入口（此前 Panel 页只能手输 URL 访问）
     * @return void
     */
    #[Hook(point: \App\Consts\Hook::ADMIN_VIEW_MENU)]
    public function ADMIN_VIEW_MENU(): void
    {
        try {
            $active = getLocalRouter() == "/plugin/TranslationBot/panel/index" ? "active" : "";
            $title = lang("翻译队列", "tpl");
            echo <<<HTML
<div class="menu-item">
    <a class="menu-link {$active}" href="/plugin/TranslationBot/panel/index">
        <span class="menu-icon"><span class="svg-icon svg-icon-2"><i class="fa-duotone fa-regular fa-language"></i></span></span>
        <span class="menu-title">{$title}</span>
    </a>
</div>
HTML;
        } catch (\Throwable $e) {
        }
    }

    /**
     * @return void
     */
    #[\Kernel\Annotation\Plugin(state: \Kernel\Annotation\Plugin::INSTALL)]
    public function install(): void
    {
        $this->bootstrap();
    }

    /**
     * 启用时同样兜底：插件若是直接放入目录（未走应用商店安装），INSTALL 不会触发
     * @return void
     */
    #[\Kernel\Annotation\Plugin(state: \Kernel\Annotation\Plugin::START)]
    public function start(): void
    {
        $this->bootstrap();
    }

    /**
     * 建队列目录，可重复执行
     * @return void
     */
    private function bootstrap(): void
    {
        Paths::inbox();
        Paths::index();
    }

    /**
     * @return void
     */
    #[\Kernel\Annotation\Plugin(state: \Kernel\Annotation\Plugin::STOP)]
    public function stop(): void
    {
        Queue::clearInflight();
    }

    /**
     * @return void
     */
    #[\Kernel\Annotation\Plugin(state: \Kernel\Annotation\Plugin::UNINSTALL)]
    public function uninstall(): void
    {
        $dir = Paths::runtime();
        foreach (glob($dir . '/{,.}*', GLOB_BRACE) ?: [] as $item) {
            if (is_file($item)) {
                @unlink($item);
            }
        }
        foreach ([Paths::inbox(), Paths::index()] as $sub) {
            foreach (glob($sub . '/*') ?: [] as $item) {
                @unlink($item);
            }
            @rmdir($sub);
        }
        @rmdir($dir);
    }

    /**
     * 商品编辑弹窗里的「多语言」标签页。
     *
     * 这一页归本插件所有：核心只负责翻译库本身，按商品维护译文、一键 AI 翻译是本插件的能力，
     * 插件没装/没启用就不该出现（GitHub #888）。
     *
     * @return array|null
     */
    #[Hook(point: \App\Consts\Hook::HACK_SUBMIT_TAB)]
    public function commodityLangTab(): ?array
    {
        try {
            if (!str_starts_with((string)getLocalRouter(), "/admin")) {
                return null;
            }
            //站点只有源语言时这一页什么都做不了
            if (\Kernel\Util\Lang::targets() === []) {
                return null;
            }
            return (new Tab("/admin/api/commodity/save", $this->commodityLangCode()))->toArray();
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * 标签页的前端代码。会被 component.popup 求值成一个 tab 对象。
     * @return string
     */
    private function commodityLangCode(): string
    {
        $title = lang("多语言", "tpl");
        $t = static fn(string $text): string => addslashes(lang($text, "tpl"));

        return <<<JS
        {
            name: util.icon("fa-duotone fa-regular fa-language") + " {$title}",
            form: [
                {
                    title: false, name: "tb_commodity_lang", type: "custom", submit: false,
                    complete: (form, dom) => {
                        const id = Number(form?.opt?.assign?.id || 0);
                        const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({
                            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
                        })[c]);

                        if (!id) {
                            dom.html('<div class="alert alert-primary" style="margin:0">{$t('先保存商品，再回来编辑它的多语言译文。')}</div>');
                            return;
                        }

                        const load = () => {
                            dom.html('<div class="text-gray-600" style="padding:12px 0">{$t('加载中...')}</div>');
                            util.post({
                                url: '/plugin/TranslationBot/admin/commodityLang',
                                data: {id: id},
                                loader: false,
                                done: res => {
                                    const d = res.data || {};
                                    const langs = d.langs || [], fields = d.fields || [];
                                    if (fields.length === 0) {
                                        dom.html('<div class="alert alert-warning" style="margin:0">{$t('这个商品没有可翻译的文案。')}</div>');
                                        return;
                                    }

                                    const tabs = langs.map((l, i) =>
                                        '<li class="nav-item"><a class="nav-link ' + (i === 0 ? 'active' : '') + ' tb-tab" data-code="' + esc(l.code) + '" href="javascript:;">' + esc(l.name) + '</a></li>').join('');

                                    const panes = langs.map((l, i) => {
                                        const items = fields.map(f => {
                                            const tr = (f.trans || {})[l.code] || {};
                                            const badge = tr.status === 2
                                                ? '<span class="badge badge-light-success ms-2">{$t('人工确认')}</span>'
                                                : (tr.text ? '<span class="badge badge-light-primary ms-2">{$t('机器翻译')}</span>'
                                                           : '<span class="badge badge-light-danger ms-2">{$t('待翻译')}</span>');
                                            const rows = f.field === 'description' ? 10 : 3;
                                            return '<div class="mb-4">'
                                                + '<div class="fw-bold mb-1">' + esc(f.title) + badge + '</div>'
                                                + '<div class="text-gray-600 fs-8 mb-2" style="white-space:pre-wrap;word-break:break-word;max-height:88px;overflow:auto;background:var(--md-surface-2,#f6f6f9);border-radius:6px;padding:6px 8px;">' + esc(f.source) + '</div>'
                                                + '<textarea class="layui-textarea tb-input" data-code="' + esc(l.code) + '" data-field="' + esc(f.field) + '" rows="' + rows + '" style="min-height:' + (rows * 26) + 'px">' + esc(tr.text) + '</textarea>'
                                                + '</div>';
                                        }).join('');
                                        return '<div class="tb-pane" data-code="' + esc(l.code) + '" style="display:' + (i === 0 ? 'block' : 'none') + '">' + items + '</div>';
                                    }).join('');

                                    dom.html('<ul class="nav nav-tabs mb-4">' + tabs + '</ul>'
                                        + '<div class="tb-panes">' + panes + '</div>'
                                        + '<div class="d-flex gap-2 mt-2">'
                                        + '<button type="button" class="btn btn-sm btn-primary tb-save">{$t('保存译文')}</button>'
                                        + '<button type="button" class="btn btn-sm btn-light-info tb-ai">{$t('AI 翻译本商品')}</button>'
                                        + '<button type="button" class="btn btn-sm btn-light-warning tb-ai-force">{$t('AI 重译并覆盖')}</button>'
                                        + '<button type="button" class="btn btn-sm btn-light tb-reload">{$t('刷新')}</button>'
                                        + '</div>'
                                        + '<div class="text-gray-600 fs-8 mt-3">{$t('译文按原文共享：两个商品文案完全相同就共用同一条译文，只需翻译一次。改动商品文案后旧译文会自动回收。')}</div>');

                                    dom.find('.tb-tab').on('click', function () {
                                        const code = \$(this).data('code');
                                        dom.find('.tb-tab').removeClass('active');
                                        \$(this).addClass('active');
                                        dom.find('.tb-pane').each(function () {
                                            \$(this).css('display', \$(this).data('code') === code ? 'block' : 'none');
                                        });
                                    });

                                    dom.find('.tb-save').on('click', () => {
                                        const data = {id: id};
                                        dom.find('.tb-input').each(function () {
                                            data['trans[' + \$(this).data('code') + '][' + \$(this).data('field') + ']'] = \$(this).val();
                                        });
                                        util.post('/plugin/TranslationBot/admin/commodityLangSave', data, r2 => {
                                            message.success(r2.msg || '{$t('保存成功')}');
                                            load();
                                        });
                                    });

                                    const ai = override => {
                                        message.ask(override
                                            ? '{$t('会先清空这个商品已有的译文（含人工确认过的），再重新翻译。确认？')}'
                                            : '{$t('把这个商品的文案交给翻译队列，已有译文不会被覆盖。确认？')}', () => {
                                            util.post('/plugin/TranslationBot/admin/commodityLangTranslate', {id: id, override: override ? 1 : 0}, r2 => {
                                                message.success(r2.msg || '{$t('已提交')}');
                                            });
                                        });
                                    };
                                    dom.find('.tb-ai').on('click', () => ai(false));
                                    dom.find('.tb-ai-force').on('click', () => ai(true));
                                    dom.find('.tb-reload').on('click', load);
                                }
                            });
                        };
                        load();
                    }
                }
            ]
        }
        JS;
    }
}
