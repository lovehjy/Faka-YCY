<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Hook;

use App\Plugin\TranslationBot\Service\Paths;
use App\Plugin\TranslationBot\Task\ConsumeTask;
use App\Util\Plugin;

class TaskRegister
{
    public const INTERVAL_DEFAULT = 15;

    // 0x7A100 = \App\Plugin\ThreadManager\Consts\Hook::TASK_REGISTER
    // 必须写字面量，不能引用常量：ThreadManager 未安装时会导致本插件无法启用
    #[\Kernel\Annotation\Hook(point: 0x7A100)]
    public function register(): array
    {
        try {
            $config = (array)Plugin::getConfig(Paths::NAME, false);
            if ((string)($config['STATUS'] ?? '0') !== '1') {
                return [];
            }

            $interval = (int)($config['task_interval'] ?? self::INTERVAL_DEFAULT);
            $interval = $interval > 0 ? max(5, min(3600, $interval)) : self::INTERVAL_DEFAULT;

            //「并发数」配置在任务内部以协程实现（见 Consumer::translateWave）：
            //文件队列是单消费者模型（独占锁 + pending 整文件重写），多副本进程只会在锁上
            //互斥空转，所以这里副本恒为 1，不透传 concurrency 给线程管理器。
            return [
                \App\Plugin\ThreadManager\Task\Task::make('consume', ConsumeTask::class)
                    ->interval($interval)
                    ->bootFull()
                    ->restartAlways()
                    ->hungAfter(300),
            ];
        } catch (\Throwable $e) {
            return [];
        }
    }
}
