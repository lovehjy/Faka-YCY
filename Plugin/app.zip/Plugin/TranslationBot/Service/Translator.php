<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Service;

/**
 * 提示词构建与模型响应解析。纯函数，无 IO，可独立单测。
 */
class Translator
{
    /**
     * 内置语言的目标描述。仅作兜底——正常应由核心的语言注册表提供，
     * 站长自己加的语言（韩语、葡语……）也是从那里拿名字的。
     */
    public const LANG_NAMES = [
        'zh-tw' => '繁體中文（台灣用語）',
        'en' => 'English',
        'ja' => '日本語',
    ];

    /**
     * 目标语言在提示词里的称呼。
     * 优先问核心注册表（站长可改、可加语言），老核心没有这个方法时回落到内置表。
     * @param string $lang
     * @return string
     */
    public static function langName(string $lang): string
    {
        if (method_exists(\Kernel\Util\Lang::class, 'promptName')) {
            $name = trim(\Kernel\Util\Lang::promptName($lang));
            if ($name !== '') {
                return $name;
            }
        }
        return self::LANG_NAMES[$lang] ?? $lang;
    }

    /**
     * @param string $lang 目标语言
     * @param string $brandWords 逗号/换行分隔的免翻词
     * @param bool $rich 是否富文本档
     * @return string
     */
    public static function systemPrompt(string $lang, string $brandWords = '', bool $rich = false): string
    {
        $name = self::langName($lang);
        $brands = self::brandList($brandWords);
        $brandLine = $brands === []
            ? ''
            : "\n- 以下词汇原样保留，不要翻译：" . implode('、', $brands);

        $richLine = $rich
            ? "\n- 输入是 HTML 富文本：必须原样保留所有 HTML 标签、属性、URL 与图片地址，只翻译标签之间的可见文字。"
            : "\n- 输入是界面短语：保持简短，符合电商界面用语习惯，不要添加标点或解释。";

        return "你是电商发卡平台的专业本地化翻译。把用户给出的简体中文条目逐条翻译成{$name}。

规则：
- 严格逐条对应，输入 N 条就输出 N 条，顺序不变。
- 保留占位符与变量，例如 {name}、%s、{0}、#{...}，位置可按目标语言语序调整但不得删改内容。
- 保留数字、金额、单位、订单号等原样。{$richLine}{$brandLine}
- 商品与营销文案使用自然地道的表达，不要逐字直译。
- 只输出 JSON，格式为 {\"t\":[\"译文1\",\"译文2\"]}，不要输出任何解释、注释或代码围栏。";
    }

    /**
     * @param string[] $sources
     * @return string
     */
    public static function userMessage(array $sources): string
    {
        $lines = [];
        foreach (array_values($sources) as $i => $source) {
            $lines[] = ($i + 1) . '. ' . $source;
        }
        return "请翻译以下 " . count($sources) . " 条内容：\n\n" . implode("\n", $lines);
    }

    /**
     * @param string $brandWords
     * @return string[]
     */
    public static function brandList(string $brandWords): array
    {
        $parts = preg_split('/[,，\r\n]+/u', $brandWords) ?: [];
        $out = [];
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part !== '') {
                $out[] = $part;
            }
        }
        return $out;
    }

    /**
     * 解析模型响应，逐条校验；返回 [译文数组(与 sources 同序，失败项为 null), 失败原因]
     * @param string $raw
     * @param string[] $sources
     * @return array{0: array<int, string|null>, 1: string}
     */
    public static function parse(string $raw, array $sources): array
    {
        $count = count($sources);
        $json = self::extractJson($raw);
        if ($json === null) {
            return [array_fill(0, $count, null), '响应不是有效 JSON'];
        }

        $list = $json['t'] ?? null;
        if (!is_array($list)) {
            //容忍模型直接返回数组
            $list = array_is_list($json) ? $json : null;
        }
        if (!is_array($list)) {
            return [array_fill(0, $count, null), '响应缺少 t 数组'];
        }
        if (count($list) !== $count) {
            return [array_fill(0, $count, null), '条目数量不匹配：期望 ' . $count . ' 实际 ' . count($list)];
        }

        $out = [];
        foreach (array_values($sources) as $i => $source) {
            $text = $list[$i] ?? null;
            $out[] = is_string($text) && self::validate($source, $text) ? trim($text) : null;
        }
        return [$out, ''];
    }

    /**
     * 单条译文校验：非空、长度合理、HTML 标签集合一致
     * @param string $source
     * @param string $text
     * @return bool
     */
    public static function validate(string $source, string $text): bool
    {
        $text = trim($text);
        if ($text === '') {
            return false;
        }
        if (mb_strlen($text) > mb_strlen($source) * 4 + 200) {
            return false;
        }
        return self::tagSignature($source) === self::tagSignature($text);
    }

    /**
     * HTML 标签名多重集合签名（顺序无关，数量敏感）
     * @param string $html
     * @return string
     */
    public static function tagSignature(string $html): string
    {
        preg_match_all('/<\s*([a-zA-Z][a-zA-Z0-9]*)/', $html, $m);
        $tags = array_map('strtolower', $m[1] ?? []);
        sort($tags);
        return implode(',', $tags);
    }

    /**
     * 从可能带围栏/前后缀的响应中提取 JSON
     * @param string $raw
     * @return array|null
     */
    public static function extractJson(string $raw): ?array
    {
        $raw = trim($raw);
        if ($raw === '') {
            return null;
        }
        //剥离 ```json ... ``` 围栏
        if (preg_match('/```(?:json)?\s*(.+?)\s*```/s', $raw, $m)) {
            $raw = trim($m[1]);
        }
        $data = json_decode($raw, true);
        if (is_array($data)) {
            return $data;
        }
        //退化：截取首个 { 到末个 }
        $start = strpos($raw, '{');
        $end = strrpos($raw, '}');
        if ($start !== false && $end !== false && $end > $start) {
            $data = json_decode(substr($raw, $start, $end - $start + 1), true);
            if (is_array($data)) {
                return $data;
            }
        }
        //再退化：数组形态
        $start = strpos($raw, '[');
        $end = strrpos($raw, ']');
        if ($start !== false && $end !== false && $end > $start) {
            $data = json_decode(substr($raw, $start, $end - $start + 1), true);
            if (is_array($data)) {
                return $data;
            }
        }
        return null;
    }

    /**
     * 是否走富文本档（单条成调、可用高档模型）
     * @param string $source
     * @return bool
     */
    public static function isRich(string $source): bool
    {
        return mb_strlen($source) > 500 || preg_match('/<[a-zA-Z][^>]*>/', $source) === 1;
    }
}
