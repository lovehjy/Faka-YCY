<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Service;

use Illuminate\Database\Capsule\Manager as DB;
use Kernel\Util\Lang;

/**
 * 按商品聚合它的译文。
 *
 * 核心的翻译库是**内容寻址**的：主键是 md5(原文)，词条只认文本、不认商品。这带来一个好处
 * （十个商品都叫「自动发货」只占一条词条、只翻一次），代价是站长改完商品要去几千条词条里
 * 翻找自己刚改的那句（GitHub #888）。
 *
 * 这里不改存储模型，只是把一个商品的几段原文与它们各语言的译文聚到一起，
 * 让「编辑商品」的时候顺手就能维护译文、也能一键交给 AI 翻。
 */
final class CommodityLang
{
    /**
     * 商品身上会被翻译的纯文本字段，与核心 App\Util\CommodityLang 保持一致
     */
    public const FIELDS = [
        'name' => '商品名称',
        'description' => '商品描述',
        'delivery_message' => '发货文案',
        'leave_message' => '发货留言',
        'card_show_tips' => '卡密展示提示',
    ];

    /**
     * 翻译库里动态内容的场景名，跟核心一致
     */
    public const SCENE = 'dyn';

    /**
     * 单条译文的长度上限，与后台翻译管理页一致
     */
    public const MAX_TEXT_LEN = 20000;

    /**
     * 取商品的原文与各语言译文
     *
     * @param object $commodity
     * @return array{langs:array, fields:array}
     */
    public static function read(object $commodity): array
    {
        $targets = Lang::targets();

        $langs = [];
        foreach ($targets as $code) {
            $langs[] = ['code' => $code, 'name' => Lang::name($code)];
        }

        $fields = [];
        $hashes = [];
        foreach (self::FIELDS as $field => $title) {
            $source = $commodity->{$field} ?? null;
            if (!is_string($source) || trim($source) === '') {
                continue;
            }
            $hash = md5($source);
            $hashes[$hash] = true;
            $fields[] = ['field' => $field, 'title' => $title, 'hash' => $hash, 'source' => $source];
        }

        //一次把这几段原文的全部译文查出来，别按 字段×语言 逐条查
        $map = [];
        if ($hashes !== [] && $targets !== []) {
            foreach (DB::table(Lang::TABLE)->whereIn('hash', array_keys($hashes))->whereIn('lang', $targets)
                         ->get(['hash', 'lang', 'text', 'status']) as $row) {
                $map[$row->hash . '|' . $row->lang] = ['text' => $row->text, 'status' => (int)$row->status];
            }
        }
        foreach ($fields as $i => $f) {
            foreach ($targets as $code) {
                $hit = $map[$f['hash'] . '|' . $code] ?? null;
                $fields[$i]['trans'][$code] = ['text' => (string)($hit['text'] ?? ''), 'status' => $hit['status'] ?? 0];
            }
        }

        return ['langs' => $langs, 'fields' => array_values($fields)];
    }

    /**
     * 写入人工译文。
     *
     * @param object $commodity
     * @param array $trans trans[语言][字段] = 译文
     * @return int 写入条数
     * @throws \Kernel\Exception\JSONException
     */
    public static function write(object $commodity, array $trans): int
    {
        $saved = 0;
        $touched = [];

        foreach ($trans as $lang => $fields) {
            $lang = Lang::normalizeCode((string)$lang);
            if ($lang === '' || !Lang::known($lang) || $lang === Lang::SOURCE || !is_array($fields)) {
                continue;
            }
            foreach ($fields as $field => $text) {
                if (!isset(self::FIELDS[$field]) || !is_string($text)) {
                    continue;
                }
                $source = $commodity->{$field} ?? null;
                if (!is_string($source) || trim($source) === '') {
                    continue;
                }
                $text = trim($text);
                if (str_contains($text, "\0") || mb_strlen($text) > self::MAX_TEXT_LEN) {
                    throw new \Kernel\Exception\JSONException(self::FIELDS[$field] . ' 的译文内容不合法');
                }
                //留空 = 清掉译文回到待翻译，跟后台翻译管理页里单条编辑的语义一致
                Lang::store($source, $lang, $text === '' ? null : $text, $text === '' ? 0 : 2, self::SCENE);
                $touched[$lang] = true;
                $saved++;
            }
        }

        foreach (array_keys($touched) as $lang) {
            Lang::rebuild($lang);
        }
        return $saved;
    }

    /**
     * 把这个商品的原文投给翻译队列。
     *
     * @param object $commodity
     * @param bool $override true=先清空已有译文再重翻（商品改过、旧译文对不上时用）
     * @return int 投递的原文段数
     */
    public static function enqueue(object $commodity, bool $override): int
    {
        $targets = Lang::targets();
        if ($targets === []) {
            return 0;
        }

        $sources = [];
        foreach (array_keys(self::FIELDS) as $field) {
            $source = $commodity->{$field} ?? null;
            if (is_string($source) && trim($source) !== '') {
                $sources[md5($source)] = $source;
            }
        }
        if ($sources === []) {
            return 0;
        }

        $now = date('Y-m-d H:i:s');
        $rows = [];
        foreach ($sources as $hash => $source) {
            foreach ($targets as $lang) {
                $rows[] = [
                    'hash' => $hash, 'source' => $source, 'lang' => $lang, 'text' => null,
                    'scene' => self::SCENE, 'status' => 0, 'create_time' => $now, 'update_time' => $now,
                ];
            }
        }
        //先补齐词条行（已存在的不动），再决定要不要清空
        DB::table(Lang::TABLE)->insertOrIgnore($rows);

        if ($override) {
            DB::table(Lang::TABLE)
                ->whereIn('hash', array_keys($sources))
                ->whereIn('lang', $targets)
                ->update(['text' => null, 'status' => 0, 'update_time' => $now]);
            foreach ($targets as $lang) {
                Lang::rebuild($lang);
            }
        }

        //直接进本插件的队列，不绕 LANG_MISS 钩子——这本来就是我们自己的活
        Queue::push(array_values($sources), $targets);

        return count($sources);
    }
}
