<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Service;

/**
 * 线程管理器任务模式探测：供面板显示当前是否由 consume 常驻任务驱动。
 * 只读 ThreadManager 的 status.json，绝不触发进程操作，任何异常都按「任务不在」处理。
 */
class TaskMode
{
    public const TASK_ID = Paths::NAME . ':consume';

    /** status.json 超过该秒数没刷新即视为守护进程离线（正常时秒级刷新） */
    private const FRESH_WINDOW = 180;

    /**
     * @return array{installed: bool, alive: bool, state: string}
     */
    public static function state(): array
    {
        $out = ['installed' => false, 'alive' => false, 'state' => ''];
        try {
            if (!class_exists(\App\Plugin\ThreadManager\Supervisor\Status::class)) {
                return $out;
            }
            $out['installed'] = true;

            $st = \App\Plugin\ThreadManager\Supervisor\Status::read();
            if (!is_array($st)) {
                return $out;
            }
            if (microtime(true) - (float)($st['ts'] ?? 0) > self::FRESH_WINDOW) {
                return $out;
            }
            if ((string)($st['daemon']['state'] ?? '') === 'stopped') {
                return $out;
            }

            $task = $st['tasks'][self::TASK_ID] ?? null;
            if (!is_array($task)) {
                foreach ((array)($st['tasks'] ?? []) as $row) {
                    if (is_array($row) && (string)($row['id'] ?? '') === self::TASK_ID) {
                        $task = $row;
                        break;
                    }
                }
            }
            if (!is_array($task)) {
                return $out;
            }

            $out['state'] = (string)($task['state'] ?? '');
            $out['alive'] = (bool)($task['enabled'] ?? false)
                && !in_array($out['state'], ['disabled', 'stopped'], true);
            return $out;
        } catch (\Throwable $e) {
            return $out;
        }
    }
}
