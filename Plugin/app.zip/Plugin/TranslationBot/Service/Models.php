<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Service;

use App\Util\Http;

/**
 * 模型列表拉取/筛选（用户端 Api 与管理端 Admin 共用）
 */
class Models
{
    public static function defaultBase(string $provider): string
    {
        return match ($provider) {
            'claude' => 'https://api.anthropic.com',
            'gemini' => 'https://generativelanguage.googleapis.com',
            default => 'https://api.openai.com',
        };
    }

    /** URL 规范化：base 已带 suffix 直接用；base 以 /v1 结尾时避免重复拼 /v1 */
    public static function providerUrl(string $base, string $suffix): string
    {
        $base = rtrim($base, '/');
        if ($suffix !== '' && str_ends_with($base, $suffix)) {
            return $base;
        }
        if (str_ends_with($base, '/v1') && str_starts_with($suffix, '/v1/')) {
            return $base . substr($suffix, 3);
        }
        return $base . $suffix;
    }

    /** 拉取模型列表（带1小时文件缓存；$force 跳过缓存） */
    public static function fetch(string $provider, string $base, string $key, bool $force = false): array
    {
        //各自写各自的 runtime，别再往 PetAgent 目录里写
        $dir = BASE_PATH . '/runtime/plugin/TranslationBot';
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
        }
        $cacheFile = $dir . '/models.cache.json';
        $hash = md5($provider . '|' . $base . '|' . substr($key, 0, 12));
        $cache = json_decode((string)@file_get_contents($cacheFile), true);
        if (!$force && is_array($cache) && isset($cache[$hash]) && (time() - (int)$cache[$hash]['t']) < 3600) {
            return (array)$cache[$hash]['list'];
        }

        $list = [];
        try {
            if ($provider === 'gemini') {
                $base2 = rtrim($base, '/');
                $url = (str_ends_with($base2, '/v1') || str_ends_with($base2, '/v1beta'))
                    ? $base2 . '/models?pageSize=200'
                    : $base2 . '/v1beta/models?pageSize=200';
                $headers = ['x-goog-api-key' => $key];
                if (!preg_match('#^https://generativelanguage\.googleapis\.com#i', $base2)) {
                    $headers['Authorization'] = 'Bearer ' . $key;
                }
                $response = Http::make(['timeout' => 15])->get($url, ['headers' => $headers]);
                $json = json_decode((string)$response->getBody()->getContents(), true);
                foreach ((array)($json['models'] ?? []) as $m) {
                    $methods = (array)($m['supportedGenerationMethods'] ?? []);
                    if ($methods && !in_array('generateContent', $methods, true)) {
                        continue;
                    }
                    $list[] = str_replace('models/', '', (string)($m['name'] ?? ''));
                }
            } elseif ($provider === 'claude') {
                $response = Http::make(['timeout' => 15])->get(self::providerUrl($base, '/v1/models') . '?limit=100', [
                    'headers' => ['x-api-key' => $key, 'Authorization' => 'Bearer ' . $key, 'anthropic-version' => '2023-06-01'],
                ]);
                $json = json_decode((string)$response->getBody()->getContents(), true);
                foreach ((array)($json['data'] ?? []) as $m) {
                    $list[] = (string)($m['id'] ?? '');
                }
            } else {
                $response = Http::make(['timeout' => 15])->get(self::providerUrl($base, '/v1/models'), [
                    'headers' => ['Authorization' => 'Bearer ' . $key],
                ]);
                $json = json_decode((string)$response->getBody()->getContents(), true);
                foreach ((array)($json['data'] ?? []) as $m) {
                    $list[] = (string)($m['id'] ?? '');
                }
            }
        } catch (\Exception|\Error $e) {
            return [];
        }

        $list = array_values(array_unique(array_filter($list, function ($id) {
            return $id !== '' && !preg_match('/embed|whisper|tts|audio|image|dall|moderation|rerank|realtime|transcribe|sora|veo|imagen|aqa|gecko|vision$|-ocr|guard/i', $id);
        })));

        $cache = is_array($cache) ? $cache : [];
        $cache[$hash] = ['t' => time(), 'list' => $list];
        @file_put_contents($cacheFile, json_encode($cache, JSON_UNESCAPED_UNICODE));
        return $list;
    }

    /** 从列表挑一个适合聊天的：偏好轻快模型 */
    public static function pick(array $list): string
    {
        if (!$list) {
            return '';
        }
        $best = '';
        $bestScore = -1;
        foreach ($list as $id) {
            $s = 0;
            if (preg_match('/mini|flash|haiku|lite|nano/i', $id)) {
                $s += 2;
            }
            if (preg_match('/gpt-5|gpt-4|claude|gemini-2|grok|deepseek|qwen|glm/i', $id)) {
                $s += 1;
            }
            if (preg_match('/preview|exp|beta|thinking|reasoner/i', $id)) {
                $s -= 1;
            }
            if ($s > $bestScore) {
                $bestScore = $s;
                $best = $id;
            }
        }
        return $best;
    }
}
