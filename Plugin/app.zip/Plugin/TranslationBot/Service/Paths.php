<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Service;

/**
 * 插件运行时目录集中定义。放在 runtime 而非插件代码目录，升级覆盖代码不会清空队列。
 */
class Paths
{
    public const NAME = "TranslationBot";

    /**
     * 队列根目录。
     *
     * 允许用环境变量 TRANSLATIONBOT_RUNTIME 改写：回归测试必须指向临时目录，
     * 否则测试里的清空/写队列会把线上待翻条目一起抹掉（曾导致公告等条目长期不翻）。
     */
    public static function runtime(): string
    {
        $override = getenv("TRANSLATIONBOT_RUNTIME");
        $dir = is_string($override) && $override !== ""
            ? rtrim($override, "/")
            : BASE_PATH . "/runtime/plugin/" . self::NAME;
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        return $dir;
    }

    public static function inbox(): string
    {
        $dir = self::runtime() . "/inbox";
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        return $dir;
    }

    public static function index(): string
    {
        $dir = self::runtime() . "/index";
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        return $dir;
    }

    public static function pending(): string
    {
        return self::runtime() . "/pending.jsonl";
    }

    public static function dead(): string
    {
        return self::runtime() . "/dead.jsonl";
    }

    public static function inflight(): string
    {
        return self::runtime() . "/inflight.json";
    }

    public static function lock(): string
    {
        return self::runtime() . "/consumer.lock";
    }

    /**
     * 日志走框架约定位置，后台「通用插件 → 日志」按钮才能读到。
     * 队列被改写到临时目录时（回归测试）日志一并跟走，免得测试噪声混进线上日志。
     */
    public static function log(): string
    {
        $override = getenv("TRANSLATIONBOT_RUNTIME");
        if (is_string($override) && $override !== "") {
            return rtrim($override, "/") . "/runtime.log";
        }
        return BASE_PATH . "/app/Plugin/" . self::NAME . "/runtime.log";
    }
}
