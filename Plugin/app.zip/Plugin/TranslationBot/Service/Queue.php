<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Service;

use Illuminate\Database\Capsule\Manager as DB;
use Kernel\Util\Lang;

/**
 * 文件队列（不依赖 Redis）。
 *
 * 写入侧（Web 请求内，必须微秒级）：
 *   push() 只做请求内去重 + 无锁只读查索引，然后 .tmp + rename 原子落一个 inbox 文件。
 *   不加锁、不读大文件、不查库 —— 这是"绝不卡站"的关键。
 *
 * 消费侧（tick，独占锁内）：
 *   merge() 收集 inbox → 与索引、翻译表双重去重 → 追加 pending.jsonl → 删 inbox 文件。
 *   权威去重发生在这里，所以写入侧的脏读是安全的。
 */
class Queue
{
    //done 状态在索引里只作留痕，不再据此拦截入队：防"入库后仍 miss"死循环
    //已改由 filterTranslated() 查库判定（见 indexHasFresh 注释）
    public const DONE_COOLDOWN = 86400;
    public const MAX_RETRY = 3;
    public const BACKOFF = [60, 300, 1800];
    public const INFLIGHT_TIMEOUT = 120;
    public const MAX_SOURCE_LEN = 8000;

    /**
     * 入队（Web 请求内调用）
     * @param string[] $sources
     * @param string[] $langs
     * @return int 落盘条目数
     */
    public static function push(array $sources, array $langs): int
    {
        static $seen = [];

        $items = [];
        foreach ($sources as $source) {
            if (!is_string($source) || $source === '') {
                continue;
            }
            if (mb_strlen($source) > self::MAX_SOURCE_LEN) {
                continue;
            }
            $hash = md5($source);
            foreach ($langs as $lang) {
                $key = $hash . ':' . $lang;
                if (isset($seen[$key])) {
                    continue;
                }
                $seen[$key] = true;
                //无锁只读查索引：脏读容忍，权威去重在消费端
                if (self::indexHasFresh($key)) {
                    continue;
                }
                $items[] = ['k' => $key, 'h' => $hash, 's' => $source, 'l' => $lang];
            }
        }

        if ($items === []) {
            return 0;
        }

        $file = Paths::inbox() . '/' . uniqid('', true) . '.json';
        $tmp = $file . '.tmp';
        if (@file_put_contents($tmp, json_encode($items, JSON_UNESCAPED_UNICODE)) === false) {
            return 0;
        }
        @rename($tmp, $file);
        return count($items);
    }

    /**
     * 回扫兜底：从词库捞仍无译文的历史条目（插件停用期间落库的 miss、升级导入的新词条）。
     * 这些行不会再触发实时「翻译未命中」事件——词条已在库里，运行时只有对应语言的访客
     * 恰好再次访问才会 miss；没有回扫它们就永远排不上队。仅在消费端持锁且队列为空时调用。
     * 随机取样而不是固定按 id：避免窗口开头堆积 dead（多次失败）条目时把后面的活活卡死。
     * @param int $limit
     * @return array[] 与 push() 相同结构的队列条目
     */
    public static function backfill(int $limit): array
    {
        try {
            $targets = \Kernel\Util\Lang::targets();
            if ($targets === []) {
                return [];
            }

            $rows = \Illuminate\Database\Capsule\Manager::table(\Kernel\Util\Lang::TABLE)
                ->where(static function ($query) {
                    $query->whereNull('text')->orWhere('text', '');
                })
                //停用的语言不捞（issue #929）：停用不删词条，不过滤的话这批行会被反复捞回来翻
                ->whereIn('lang', $targets)
                ->inRandomOrder()
                ->limit(max(1, $limit) * 3)
                ->get(['hash', 'source', 'lang']);
        } catch (\Throwable $e) {
            return [];
        }

        $items = [];
        foreach ($rows as $row) {
            $source = (string)$row->source;
            $lang = (string)$row->lang;
            if ($source === '' || $lang === '' || mb_strlen($source) > self::MAX_SOURCE_LEN) {
                continue;
            }
            $key = (string)$row->hash . ':' . $lang;
            if (self::indexHasFresh($key)) { //pending 已在队列、dead 已多次失败：都不重复捞
                continue;
            }
            $items[] = ['k' => $key, 'h' => (string)$row->hash, 's' => $source, 'l' => $lang];
            if (count($items) >= $limit) {
                break;
            }
        }
        return $items;
    }

    /**
     * 无锁读索引桶判断条目是否已处理且在冷却期内
     * @param string $key
     * @return bool
     */
    private static function indexHasFresh(string $key): bool
    {
        $bucket = self::bucketOf($key);
        $file = Paths::index() . '/' . $bucket . '.json';
        if (!is_file($file)) {
            return false;
        }
        $data = json_decode((string)@file_get_contents($file), true);
        if (!is_array($data) || !isset($data[$key])) {
            return false;
        }
        $entry = $data[$key];
        $state = (string)($entry['st'] ?? '');

        //pending/dead 是队列自己持有的状态，直接拦截
        if ($state === 'pending' || $state === 'dead') {
            return true;
        }

        //done 不在这里拦：索引可能与数据库不同步（队列被外部清空、写库前崩溃等），
        //一旦错标 done 就会把条目锁死一个冷却期。是否真的翻过由 filterTranslated()
        //查库裁决——那才是权威，也同样能防住「已入库仍 miss」的死循环。
        return false;
    }

    /**
     * @param string $key
     * @return string
     */
    private static function bucketOf(string $key): string
    {
        return substr(md5($key), 0, 1);
    }

    /**
     * 批量更新索引（消费端持锁时调用）
     * @param array $updates key => ['st'=>..,'ts'=>..,'retry'=>..]
     * @return void
     */
    public static function indexPut(array $updates): void
    {
        $byBucket = [];
        foreach ($updates as $key => $entry) {
            $byBucket[self::bucketOf((string)$key)][(string)$key] = $entry;
        }
        foreach ($byBucket as $bucket => $entries) {
            $file = Paths::index() . '/' . $bucket . '.json';
            $data = is_file($file) ? json_decode((string)@file_get_contents($file), true) : [];
            if (!is_array($data)) {
                $data = [];
            }
            foreach ($entries as $key => $entry) {
                $data[$key] = $entry;
            }
            //索引单桶超量时按时间裁剪，防无限增长
            if (count($data) > 20000) {
                uasort($data, static fn($a, $b) => (int)($b['ts'] ?? 0) <=> (int)($a['ts'] ?? 0));
                $data = array_slice($data, 0, 10000, true);
            }
            $tmp = $file . '.' . uniqid('', true) . '.tmp';
            @file_put_contents($tmp, json_encode($data, JSON_UNESCAPED_UNICODE));
            @rename($tmp, $file);
        }
    }

    /**
     * 合并 inbox 到 pending（消费端持锁时调用），执行权威去重
     * @return int 新增待译条目数
     */
    public static function merge(): int
    {
        $files = glob(Paths::inbox() . '/*.json') ?: [];
        if ($files === []) {
            return 0;
        }

        $incoming = [];
        foreach ($files as $file) {
            $items = json_decode((string)@file_get_contents($file), true);
            if (is_array($items)) {
                foreach ($items as $item) {
                    if (isset($item['k'], $item['h'], $item['s'], $item['l'])) {
                        $incoming[(string)$item['k']] = $item;
                    }
                }
            }
            @unlink($file);
        }

        if ($incoming === []) {
            return 0;
        }

        //去重 1：已在 pending 中的
        foreach (self::readPending() as $row) {
            unset($incoming[(string)$row['k']]);
        }

        //去重 2：索引中 pending/dead/冷却内 done
        foreach (array_keys($incoming) as $key) {
            if (self::indexHasFresh((string)$key)) {
                unset($incoming[$key]);
            }
        }

        //去重 3：翻译表中已有非空译文
        $incoming = self::filterTranslated($incoming);

        if ($incoming === []) {
            return 0;
        }

        $now = time();
        $lines = '';
        $indexUpdates = [];
        foreach ($incoming as $key => $item) {
            $item['retry'] = 0;
            $item['nextAt'] = $now;
            $lines .= json_encode($item, JSON_UNESCAPED_UNICODE) . "\n";
            $indexUpdates[$key] = ['st' => 'pending', 'ts' => $now, 'retry' => 0];
        }
        @file_put_contents(Paths::pending(), $lines, FILE_APPEND | LOCK_EX);
        self::indexPut($indexUpdates);

        return count($incoming);
    }

    /**
     * 剔除翻译表中已有译文的条目
     * @param array $incoming
     * @return array
     */
    private static function filterTranslated(array $incoming): array
    {
        try {
            $hashes = array_values(array_unique(array_map(static fn($i) => (string)$i['h'], $incoming)));
            foreach (array_chunk($hashes, 500) as $chunk) {
                $rows = DB::table(Lang::TABLE)
                    ->whereIn('hash', $chunk)
                    ->whereNotNull('text')
                    ->where('text', '!=', '')
                    ->get(['hash', 'lang']);
                foreach ($rows as $row) {
                    unset($incoming[$row->hash . ':' . $row->lang]);
                }
            }
        } catch (\Throwable $e) {
            //DB 不可用时不阻塞入队，交由后续翻译阶段处理
        }
        return $incoming;
    }

    /**
     * @return array[]
     */
    public static function readPending(): array
    {
        $file = Paths::pending();
        if (!is_file($file)) {
            return [];
        }
        $rows = [];
        foreach (explode("\n", (string)@file_get_contents($file)) as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $row = json_decode($line, true);
            if (is_array($row) && isset($row['k'], $row['s'], $row['l'])) {
                $rows[] = $row;
            }
        }
        return $rows;
    }

    /**
     * 整体重写 pending（消费端持锁时调用）
     * @param array[] $rows
     * @return void
     */
    public static function writePending(array $rows): void
    {
        $lines = '';
        foreach ($rows as $row) {
            $lines .= json_encode($row, JSON_UNESCAPED_UNICODE) . "\n";
        }
        $file = Paths::pending();
        $tmp = $file . '.' . uniqid('', true) . '.tmp';
        @file_put_contents($tmp, $lines);
        @rename($tmp, $file);
    }

    /**
     * 取一批到期条目（同一目标语言，便于单语批量翻译）
     * @param array[] $rows 全量 pending
     * @param int $size
     * @return array [批次条目, 剩余条目]
     */
    public static function takeBatch(array $rows, int $size): array
    {
        $now = time();
        $lang = null;
        $batch = [];
        $rest = [];
        $batchIsRich = false;
        foreach ($rows as $row) {
            $due = (int)($row['nextAt'] ?? 0) <= $now;
            if (!$due || $batchIsRich || count($batch) >= $size || ($lang !== null && $row['l'] !== $lang)) {
                $rest[] = $row;
                continue;
            }
            //富文本条目独占一批：消费端只对"单条且富文本"的批切换富文本模型，
            //混进普通短语批会被翻译模型硬翻长 HTML，质量与截断都不可控
            $isRich = Translator::isRich((string)($row['s'] ?? ''));
            if ($isRich && $batch !== []) {
                $rest[] = $row;
                continue;
            }
            $lang = (string)$row['l'];
            $batch[] = $row;
            $batchIsRich = $isRich;
        }
        return [$batch, $rest];
    }

    /**
     * 失败退避或转死信
     * @param array $row
     * @param string $reason
     * @return array|null 回队条目，null=已入死信
     */
    public static function fail(array $row, string $reason): ?array
    {
        $retry = (int)($row['retry'] ?? 0) + 1;
        if ($retry >= self::MAX_RETRY) {
            $row['retry'] = $retry;
            $row['reason'] = $reason;
            $row['ts'] = time();
            @file_put_contents(Paths::dead(), json_encode($row, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX);
            self::indexPut([(string)$row['k'] => ['st' => 'dead', 'ts' => time(), 'retry' => $retry]]);
            return null;
        }
        $row['retry'] = $retry;
        $row['nextAt'] = time() + (self::BACKOFF[$retry - 1] ?? 1800);
        return $row;
    }

    /**
     * 标记完成
     * @param array $rows
     * @return void
     */
    public static function done(array $rows): void
    {
        $now = time();
        $updates = [];
        foreach ($rows as $row) {
            $updates[(string)$row['k']] = ['st' => 'done', 'ts' => $now, 'retry' => (int)($row['retry'] ?? 0)];
        }
        self::indexPut($updates);
    }

    /**
     * 回收超时 inflight（消费启动时调用）
     * @return array[] 需要回队的条目
     */
    public static function reclaimInflight(): array
    {
        $file = Paths::inflight();
        if (!is_file($file)) {
            return [];
        }
        $data = json_decode((string)@file_get_contents($file), true);
        @unlink($file);
        if (!is_array($data) || !isset($data['ts'], $data['rows'])) {
            return [];
        }
        if (time() - (int)$data['ts'] < self::INFLIGHT_TIMEOUT) {
            return [];
        }
        $rows = [];
        foreach ((array)$data['rows'] as $row) {
            if (is_array($row)) {
                $row['retry'] = (int)($row['retry'] ?? 0) + 1;
                $rows[] = $row;
            }
        }
        return $rows;
    }

    /**
     * @param array[] $rows
     * @return void
     */
    public static function markInflight(array $rows): void
    {
        @file_put_contents(Paths::inflight(), json_encode(['ts' => time(), 'rows' => $rows], JSON_UNESCAPED_UNICODE));
    }

    public static function clearInflight(): void
    {
        @unlink(Paths::inflight());
    }

    /**
     * @return array 统计信息
     */
    public static function stats(): array
    {
        $pending = self::readPending();
        $byLang = [];
        foreach ($pending as $row) {
            $lang = (string)$row['l'];
            $byLang[$lang] = ($byLang[$lang] ?? 0) + 1;
        }
        $deadCount = 0;
        if (is_file(Paths::dead())) {
            $deadCount = max(0, count(explode("\n", trim((string)@file_get_contents(Paths::dead())))));
            if (trim((string)@file_get_contents(Paths::dead())) === '') {
                $deadCount = 0;
            }
        }
        return [
            'pending' => count($pending),
            'pending_by_lang' => $byLang,
            'inbox' => count(glob(Paths::inbox() . '/*.json') ?: []),
            'dead' => $deadCount,
        ];
    }
}
