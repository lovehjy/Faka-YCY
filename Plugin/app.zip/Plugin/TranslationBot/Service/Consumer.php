<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Service;

use App\Plugin\TranslationBot\Agent\ChatRequest;
use App\Plugin\TranslationBot\Agent\Conversation;
use App\Plugin\TranslationBot\Agent\Provider\ProviderFactory;
use App\Plugin\TranslationBot\Support\Quota;
use App\Util\Plugin;
use Kernel\Util\Lang;

/**
 * 队列消费者：独占锁 + 时间盒，绝不长跑。
 * 由 tick 端点（心跳/访客点火/cron）或常驻 worker 调用。
 */
class Consumer
{
    public const DEFAULTS = [
        'batch_size' => 10,
        'max_calls_per_tick' => 3,
        'time_box' => 8,
        'concurrency' => 1,
    ];

    /**
     * 跑一轮消费
     * @param int|null $timeBox 秒
     * @param array|null $config 覆盖插件配置；传入后不读后台设置（回归测试用，避免真的打上游接口）
     * @param callable|null $heartbeat 每完成一波调用后回调（线程管理器任务用来续命）
     * @return array 结果统计
     */
    public static function run(?int $timeBox = null, ?array $config = null, ?callable $heartbeat = null): array
    {
        $started = microtime(true);
        $result = ['ok' => true, 'merged' => 0, 'translated' => 0, 'failed' => 0, 'calls' => 0, 'skipped' => ''];

        $config = $config ?? self::config();
        $timeBox = $timeBox ?? (int)$config['time_box'];

        $fp = @fopen(Paths::lock(), 'c');
        if (!$fp) {
            $result['ok'] = false;
            $result['skipped'] = 'lock-open-failed';
            return $result;
        }
        if (!flock($fp, LOCK_EX | LOCK_NB)) {
            fclose($fp);
            $result['ok'] = false;
            $result['skipped'] = 'busy';
            return $result;
        }

        try {
            //回收上次崩溃残留
            $reclaimed = Queue::reclaimInflight();
            $result['merged'] += Queue::merge();

            $rows = array_merge($reclaimed, Queue::readPending());
            if ($rows === []) {
                //队列空时回扫词库里的历史待译条目（不会再触发实时 miss 的那些），
                //否则插件启用前积累的空译文永远没人翻
                $rows = Queue::backfill(max(1, (int)$config['batch_size']) * max(1, (int)$config['max_calls_per_tick']));
                $result['merged'] += count($rows);
            }

            //停用的语言不再花钱翻（issue #929）。
            //停用只是不再产生新 miss，词库里的存量待译行原样留着（人工确认过的译文不能删），
            //回扫会把它们捞回来，消费端又不校验语言，于是站长关掉日语之后 AI 还在偷偷翻。
            //过滤放在这里而不是只修 backfill()：inflight 与 pending 里可能压着停用「之前」
            //就已入队的条目，只修回扫的话那批照样会被翻掉。
            $rows = self::dropDisabledLangs($rows);

            if ($rows === []) {
                Queue::writePending([]);
                return $result;
            }

            $calls = 0;
            $maxCalls = max(1, (int)$config['max_calls_per_tick']);
            $parallel = self::parallel($config);

            while ($calls < $maxCalls && (microtime(true) - $started) < $timeBox) {
                //收集一波：最多 parallel 个批次，每批一次模型调用
                $wave = [];
                while (count($wave) < $parallel && ($calls + count($wave)) < $maxCalls) {
                    [$batch, $rest] = Queue::takeBatch($rows, max(1, (int)$config['batch_size']));
                    if ($batch === []) {
                        $rows = $rest;
                        break;
                    }
                    $rows = $rest;
                    $wave[] = $batch;
                }
                if ($wave === []) {
                    break;
                }

                //用量计数仅作面板展示，不做任何拦截
                Quota::count('calls', count($wave));
                Quota::count('items', (int)array_sum(array_map('count', $wave)));

                Queue::markInflight(array_merge(...$wave));
                $calls += count($wave);

                [$done, $requeue] = self::translateWave($wave, $config);
                $result['translated'] += count($done);
                $result['failed'] += count($requeue);

                Queue::done($done);
                Queue::clearInflight();

                $rows = array_merge($requeue, $rows);

                if ($heartbeat !== null) {
                    try {
                        $heartbeat();
                    } catch (\Throwable $e) {
                    }
                }
            }

            $result['calls'] = $calls;
            Queue::writePending($rows);
        } catch (\Throwable $e) {
            $result['ok'] = false;
            $result['skipped'] = 'error';
            self::log('消费异常：' . $e->getMessage());
        } finally {
            @flock($fp, LOCK_UN);
            fclose($fp);
        }

        return $result;
    }

    /**
     * 本轮并行度。「并发数」配置只在协程环境（线程管理器工作进程）内生效，
     * FPM 触发（后台心跳/访客点火/外部 cron）没有协程调度器，始终串行。
     * 每个并发批次入库时各占一条池化数据库连接，故并发上限收敛到线程管理器的
     * pool_max，防止后来的协程卡在借连接上。
     * @param array $config
     * @return int
     */
    /**
     * 丢掉已停用语言的条目。
     *
     * targets() 是站点当前启用的目标语言（源语言除外），随后台开关实时变化；
     * 返回空数组时代表一门目标语言都没有，这里会把队列清空——正确行为，没什么可翻的。
     *
     * @param array $rows 队列条目，每项含 l=目标语言代码
     * @return array
     */
    private static function dropDisabledLangs(array $rows): array
    {
        if ($rows === []) {
            return $rows;
        }

        $targets = \Kernel\Util\Lang::targets();
        $kept = [];
        $dropped = 0;

        foreach ($rows as $row) {
            if (in_array((string)($row['l'] ?? ''), $targets, true)) {
                $kept[] = $row;
                continue;
            }
            $dropped++;
        }

        if ($dropped > 0) {
            self::log("跳过已停用语言的条目 {$dropped} 条");
        }

        return $kept;
    }

    private static function parallel(array $config): int
    {
        $want = max(1, (int)($config['concurrency'] ?? 1));
        if ($want === 1 || !self::inCoroutine()) {
            return 1;
        }

        $poolMax = 6;
        try {
            $tm = (array)Plugin::getConfig('ThreadManager', false);
            $poolMax = max(1, (int)($tm['pool_max'] ?? 6));
        } catch (\Throwable $e) {
        }

        return max(1, min($want, $poolMax, 16));
    }

    /**
     * @return bool 当前是否运行在协程内（可用 go() 真并发）
     */
    private static function inCoroutine(): bool
    {
        return \extension_loaded('swoole')
            && \class_exists('Swoole\Coroutine')
            && \Swoole\Coroutine::getCid() > 0;
    }

    /**
     * 翻译一波批次：单批或非协程环境退化为顺序执行，多批时协程并行。
     * @param array[] $wave 批次数组（每批同一目标语言）
     * @param array $config
     * @return array{0: array[], 1: array[]} [成功条目, 回队条目]
     */
    private static function translateWave(array $wave, array $config): array
    {
        $done = [];
        $requeue = [];

        if (count($wave) === 1 || !self::inCoroutine()) {
            foreach ($wave as $batch) {
                [$d, $r] = self::translateBatch($batch, $config);
                $done = array_merge($done, $d);
                $requeue = array_merge($requeue, $r);
            }
            return [$done, $requeue];
        }

        $results = [];
        $wg = new \Swoole\Coroutine\WaitGroup();
        foreach ($wave as $i => $batch) {
            $wg->add();
            \Swoole\Coroutine::create(static function () use (&$results, $i, $batch, $config, $wg): void {
                try {
                    $results[$i] = self::translateBatch($batch, $config);
                } catch (\Throwable $e) {
                    //translateBatch 自身已兜底，这里防协程级意外把整波卡死
                    self::log('并发批次异常：' . $e->getMessage());
                    $results[$i] = [[], self::requeueAll($batch, 'wave:' . $e->getMessage())];
                } finally {
                    $wg->done();
                }
            });
        }
        $wg->wait();

        foreach ($results as [$d, $r]) {
            $done = array_merge($done, $d);
            $requeue = array_merge($requeue, $r);
        }
        return [$done, $requeue];
    }

    /**
     * 翻译一批（同一目标语言）
     * @param array[] $batch
     * @param array $config
     * @return array{0: array[], 1: array[]} [成功条目, 回队条目]
     */
    private static function translateBatch(array $batch, array $config): array
    {
        $lang = (string)$batch[0]['l'];
        $sources = array_map(static fn($row) => (string)$row['s'], $batch);
        $rich = count($batch) === 1 && Translator::isRich($sources[0]);

        try {
            $providerConfig = $config;
            if ($rich && trim((string)($config['rich_model'] ?? '')) !== '') {
                $providerConfig['ai_model'] = $config['rich_model'];
            }
            $provider = ProviderFactory::make($providerConfig);

            $conversation = new Conversation();
            $conversation->addUser(Translator::userMessage($sources));
            $request = new ChatRequest(
                Translator::systemPrompt($lang, (string)($config['brand_words'] ?? ''), $rich),
                $conversation,
                null,
                false
            );

            $raw = $provider->complete($request);
        } catch (\Throwable $e) {
            self::log("调用失败[{$lang}]：" . $e->getMessage());
            return [[], self::requeueAll($batch, 'provider:' . $e->getMessage())];
        }

        [$texts, $error] = Translator::parse($raw, $sources);
        if ($error !== '') {
            self::log("解析失败[{$lang}]：{$error}");
            return [[], self::requeueAll($batch, 'parse:' . $error)];
        }

        $store = [];
        $done = [];
        $requeue = [];
        foreach ($batch as $i => $row) {
            $text = $texts[$i] ?? null;
            if ($text === null) {
                $again = Queue::fail($row, 'invalid-item');
                if ($again !== null) {
                    $requeue[] = $again;
                }
                continue;
            }
            $store[] = [
                'source' => (string)$row['s'],
                'lang' => $lang,
                'text' => $text,
                'status' => 1,
                'scene' => 'dyn',
            ];
            $done[] = $row;
        }

        if ($store !== []) {
            try {
                Lang::storeBatch($store);
                self::log('已入库 ' . count($store) . " 条[{$lang}]");
            } catch (\Throwable $e) {
                self::log('入库失败：' . $e->getMessage());
                return [[], self::requeueAll($batch, 'store')];
            }
        }

        return [$done, $requeue];
    }

    /**
     * @param array[] $batch
     * @param string $reason
     * @return array[]
     */
    private static function requeueAll(array $batch, string $reason): array
    {
        $rows = [];
        foreach ($batch as $row) {
            $again = Queue::fail($row, $reason);
            if ($again !== null) {
                $rows[] = $again;
            }
        }
        return $rows;
    }

    /**
     * @return array
     */
    public static function config(): array
    {
        $config = [];
        try {
            $config = (array)Plugin::getConfig(Paths::NAME);
        } catch (\Throwable $e) {
        }
        foreach (self::DEFAULTS as $key => $value) {
            if (!isset($config[$key]) || $config[$key] === '' || (is_numeric($config[$key]) && (int)$config[$key] <= 0)) {
                $config[$key] = $value;
            }
        }
        return $config;
    }

    /**
     * @param string $message
     * @return void
     */
    public static function log(string $message): void
    {
        //写到框架约定位置 app/Plugin/TranslationBot/runtime.log，
        //后台「通用插件 → 日志」按钮读的就是这个文件
        $file = Paths::log();
        if (is_file($file) && filesize($file) > 512000) {
            @file_put_contents($file, '');
        }
        @file_put_contents($file, '[' . date('Y-m-d H:i:s') . '] ' . $message . "\n", FILE_APPEND);
    }

    /**
     * @param int $lines
     * @return string
     */
    public static function tailLog(int $lines = 100): string
    {
        $file = Paths::log();
        if (!is_file($file)) {
            return '';
        }
        $all = explode("\n", trim((string)@file_get_contents($file)));
        return implode("\n", array_slice($all, -$lines));
    }
}
