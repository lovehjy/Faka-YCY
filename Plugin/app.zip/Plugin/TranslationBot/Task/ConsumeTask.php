<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Task;

use App\Plugin\TranslationBot\Service\Consumer;
use App\Plugin\TranslationBot\Service\Queue;

/**
 * 线程管理器常驻任务：队列消费。
 *
 * 单次 run() = 连续消费直到队列排空 / 无进展，轮与轮之间的
 * 间隔调度、异常捕获与退避重启由 supervisor 负责（interval 模式契约）。
 * $ctx 声明为 object：ThreadManager 未安装时本插件仍可正常安装启用。
 */
class ConsumeTask
{
    public function run(object $ctx): void
    {
        while (true) {
            $result = Consumer::run(null, null, static function () use ($ctx): void {
                $ctx->heartbeat();
            });
            $ctx->heartbeat();

            $skipped = (string)($result['skipped'] ?? '');
            $progress = (int)($result['translated'] ?? 0) > 0 || (int)($result['merged'] ?? 0) > 0;

            //锁被他处占用/异常，或本轮毫无产出：睡到下个巡检间隔，不空转
            if ($skipped !== '' || !$progress) {
                return;
            }
            //队列已排空：本轮收工
            if ((int)(Queue::stats()['pending'] ?? 0) <= 0) {
                return;
            }
            //仍有存货且在正常产出 → 立即继续；管理器要求停止/重载时让路
            if (!$ctx->shouldContinue()) {
                return;
            }
        }
    }
}
