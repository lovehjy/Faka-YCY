<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Controller;

use App\Controller\Base\API\ManagePlugin;
use App\Interceptor\ManageSession;
use App\Interceptor\Waf;
use App\Plugin\TranslationBot\Service\Consumer;
use App\Plugin\TranslationBot\Service\Models;
use App\Plugin\TranslationBot\Service\Paths;
use App\Plugin\TranslationBot\Service\Queue;
use App\Plugin\TranslationBot\Service\TaskMode;
use App\Plugin\TranslationBot\Support\Quota;
use App\Model\ManageLog;
use App\Plugin\TranslationBot\Service\CommodityLang;
use Kernel\Context\Interface\Request;
use App\Util\Plugin;
use Illuminate\Database\Capsule\Manager as DB;
use Kernel\Annotation\Interceptor;
use Kernel\Exception\JSONException;
use Kernel\Util\Lang;

#[Interceptor([Waf::class, ManageSession::class], Interceptor::TYPE_API)]
class Admin extends ManagePlugin
{
    /**
     * 队列与用量总览
     * @return array
     */
    public function status(): array
    {
        $stats = Queue::stats();
        $quota = Quota::today();
        $config = Consumer::config();

        $untranslated = 0;
        try {
            //只统计启用中的语言（issue #929）：停用语言的存量待译行不会再被翻译，
            //算进来会让「待翻译」数字虚高，站长以为队列卡住了
            $targets = Lang::targets();
            $untranslated = $targets === [] ? 0 : (int)DB::table(Lang::TABLE)
                ->where(static function ($query) {
                    $query->whereNull('text')->orWhere('text', '');
                })
                ->whereIn('lang', $targets)
                ->count();
        } catch (\Throwable $e) {
        }

        return $this->json(200, 'success', [
            'pending' => $stats['pending'],
            'pending_by_lang' => $stats['pending_by_lang'],
            'inbox' => $stats['inbox'],
            'dead' => $stats['dead'],
            'untranslated_rows' => $untranslated,
            'today_calls' => (int)($quota['counts']['calls'] ?? 0),
            'today_items' => (int)($quota['counts']['items'] ?? 0),
            'task_mode' => TaskMode::state(),
            'concurrency' => (int)$config['concurrency'],
        ]);
    }

    /**
     * 手动处理一批（管理员会话鉴权，无需 token）
     * @return array
     */
    public function tick(): array
    {
        $result = Consumer::run();
        $stats = Queue::stats();
        $result['pending'] = $stats['pending'];
        return $this->json(200, 'success', $result);
    }

    /**
     * 给配置弹窗用：报告「线程管理器」的安装/运行状态与本插件 consume 任务状态。
     * 直接读 ThreadManager 的运行态文件，不引用它的类 —— 它可能根本没装。
     * @return array
     */
    public function runtime(): array
    {
        $base = rtrim(BASE_PATH, '/');
        $installed = is_dir($base . '/app/Plugin/ThreadManager');
        $enabled = false;
        if ($installed) {
            try {
                $cfg = (array)Plugin::getConfig('ThreadManager', false);
                $enabled = (string)($cfg['STATUS'] ?? '0') === '1';
            } catch (\Throwable $e) {
            }
        }

        $status = null;
        $f = $base . '/runtime/plugin/ThreadManager/status.json';
        if (is_file($f)) {
            $d = json_decode((string)@file_get_contents($f), true);
            if (is_array($d)) {
                $status = $d;
            }
        }

        $tick = (int)($status['daemon']['tick_ms'] ?? 250);
        $age = $status === null ? null : microtime(true) - (float)($status['ts'] ?? 0);
        $running = $status !== null && $age !== null && $age <= (3 * $tick / 1000 + 2);

        $task = null;
        foreach ((array)($status['tasks'] ?? []) as $id => $t) {
            if (str_starts_with((string)$id, Paths::NAME . ':')) {
                $r = (array)(($t['replicas'] ?? [])[0] ?? []);
                $task = [
                    'id' => (string)$id,
                    'state' => (string)($t['state'] ?? ''),
                    'iter' => (int)($r['iter'] ?? 0),
                    'last_ms' => $r['last_ms'] ?? null,
                    'ts' => $r['ts'] ?? null,
                    'restarts' => (int)($t['restarts'] ?? 0),
                    'error' => $t['last_error'] ?? null,
                ];
                break;
            }
        }

        return $this->json(200, 'success', [
            'installed' => $installed,
            'enabled' => $enabled,
            'running' => $running,
            'task' => $task,
            'panel' => '/plugin/ThreadManager/panel/index',
        ]);
    }

    /**
     * 把待翻译的库存行重新灌入队列（用于首次启用插件时补齐历史 miss）
     * @return array
     */
    public function enqueueUntranslated(): array
    {
        $limit = min(2000, max(1, (int)($_POST['limit'] ?? 500)));
        $rows = [];
        try {
            $targets = Lang::targets();
            if ($targets === []) {
                throw new JSONException('站点没有启用任何目标语言');
            }
            $rows = DB::table(Lang::TABLE)
                ->where(static function ($query) {
                    $query->whereNull('text')->orWhere('text', '');
                })
                //停用的语言不入队（issue #929）
                ->whereIn('lang', $targets)
                ->orderBy('id')
                ->limit($limit)
                ->get(['source', 'lang']);
        } catch (\Throwable $e) {
            throw new JSONException('读取翻译表失败：' . $e->getMessage());
        }

        $byLang = [];
        foreach ($rows as $row) {
            $byLang[(string)$row->lang][] = (string)$row->source;
        }
        $count = 0;
        foreach ($byLang as $lang => $sources) {
            $count += Queue::push(array_values(array_unique($sources)), [$lang]);
        }

        return $this->json(200, "已加入队列 {$count} 条", ['count' => $count]);
    }

    /**
     * 死信重试
     * @return array
     */
    public function retryDead(): array
    {
        $file = Paths::dead();
        if (!is_file($file)) {
            return $this->json(200, '没有失败条目', ['count' => 0]);
        }
        $count = 0;
        $sources = [];
        foreach (explode("\n", (string)@file_get_contents($file)) as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $row = json_decode($line, true);
            if (is_array($row) && isset($row['s'], $row['l'])) {
                $sources[(string)$row['l']][] = (string)$row['s'];
                $count++;
            }
        }
        @unlink($file);
        //清掉索引中的 dead 标记，使其可以重新入队
        foreach ($sources as $lang => $list) {
            $updates = [];
            foreach ($list as $source) {
                $updates[md5($source) . ':' . $lang] = ['st' => 'retry', 'ts' => 0, 'retry' => 0];
            }
            Queue::indexPut($updates);
            Queue::push(array_values(array_unique($list)), [$lang]);
        }
        return $this->json(200, "已重新入队 {$count} 条", ['count' => $count]);
    }

    /**
     * 清空队列
     * @return array
     */
    public function clearQueue(): array
    {
        foreach (glob(Paths::inbox() . '/*') ?: [] as $file) {
            @unlink($file);
        }
        foreach (glob(Paths::index() . '/*') ?: [] as $file) {
            @unlink($file);
        }
        @unlink(Paths::pending());
        @unlink(Paths::dead());
        Queue::clearInflight();
        return $this->json(200, '队列已清空');
    }

    /**
     * 运行日志
     * @return array
     */
    public function logs(): array
    {
        return $this->json(200, 'success', ['log' => Consumer::tailLog(100)]);
    }

    /**
     * 模型列表（供配置表单动态下拉）
     * @return array
     * @throws JSONException
     */
    public function models(): array
    {
        $provider = trim((string)($_POST['provider'] ?? 'openai_responses'));
        $base = rtrim(trim((string)($_POST['api'] ?? '')), '/');
        $key = trim((string)($_POST['key'] ?? ''));
        if ($key === '') {
            $config = (array)Plugin::getConfig(Paths::NAME);
            $key = trim((string)($config['ai_key'] ?? ''));
            $base = $base !== '' ? $base : rtrim(trim((string)($config['ai_api'] ?? '')), '/');
            $provider = $provider !== '' ? $provider : (string)($config['ai_provider'] ?? 'openai_responses');
        }
        if ($key === '') {
            throw new JSONException('请先填写密钥');
        }
        if ($base === '') {
            $base = match ($provider) {
                'claude' => 'https://api.anthropic.com',
                'gemini' => 'https://generativelanguage.googleapis.com',
                default => 'https://api.openai.com',
            };
        }
        return $this->json(200, 'success', ['list' => Models::fetch($provider, $base, $key)]);
    }

    // ---------------- 商品编辑弹窗里的「多语言」标签页（GitHub #888） ----------------

    /**
     * 取商品的原文与各语言译文
     * @return array
     * @throws JSONException
     */
    public function commodityLang(): array
    {
        $commodity = $this->commodity();
        $data = CommodityLang::read($commodity);

        return $this->json(200, 'success', [
            'id' => (int)$commodity->id,
            'name' => (string)$commodity->name,
        ] + $data);
    }

    /**
     * 保存人工译文。
     * 走 unsafePost 取原文——商品描述是富文本，被过滤过就存坏了。
     *
     * @param Request $request
     * @return array
     * @throws JSONException
     */
    public function commodityLangSave(Request $request): array
    {
        $commodity = $this->commodity();

        $trans = $request->unsafePost('trans');
        if (!is_array($trans)) {
            throw new JSONException('没有需要保存的译文');
        }

        $saved = CommodityLang::write($commodity, $trans);
        ManageLog::log($this->getManage(), "[AI自动多语言]保存商品#{$commodity->id} 译文 {$saved} 条");
        return $this->json(200, "已保存 {$saved} 条译文", ['count' => $saved]);
    }

    /**
     * 把这个商品的文案交给翻译队列
     * @return array
     * @throws JSONException
     */
    public function commodityLangTranslate(): array
    {
        $commodity = $this->commodity();

        if (Lang::targets() === []) {
            throw new JSONException('站点只启用了源语言，没有需要翻译的目标语言');
        }

        $override = (int)($_POST['override'] ?? 0) === 1;
        $n = CommodityLang::enqueue($commodity, $override);
        if ($n === 0) {
            throw new JSONException('这个商品没有可翻译的文案');
        }

        ManageLog::log($this->getManage(), "[AI自动多语言]商品#{$commodity->id} 提交翻译 {$n} 段" . ($override ? '（覆盖）' : ''));
        return $this->json(200, "已把 {$n} 段文案投进翻译队列，稍后回到这里刷新查看", ['count' => $n]);
    }

    /**
     * @return \App\Model\Commodity
     * @throws JSONException
     */
    private function commodity(): \App\Model\Commodity
    {
        $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        $commodity = $id > 0 ? \App\Model\Commodity::query()->find($id) : null;
        if (!$commodity) {
            throw new JSONException('商品不存在');
        }
        return $commodity;
    }
}
