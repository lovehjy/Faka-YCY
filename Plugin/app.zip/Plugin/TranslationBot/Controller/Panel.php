<?php
declare (strict_types=1);

namespace App\Plugin\TranslationBot\Controller;

use App\Controller\Base\View\ManagePlugin;
use App\Interceptor\ManageSession;
use Kernel\Annotation\Interceptor;
use Kernel\Exception\ViewException;

#[Interceptor(ManageSession::class, Interceptor::TYPE_VIEW)]
class Panel extends ManagePlugin
{
    /**
     * @return string
     * @throws ViewException
     */
    public function index(): string
    {
        return $this->render("翻译队列", "Panel/Index.html", [], true);
    }
}
