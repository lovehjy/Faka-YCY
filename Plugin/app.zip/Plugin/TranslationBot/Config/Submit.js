(function () {
    // 模型下拉动态拉取：翻译模型 + 富文本模型共用同一次拉取。打开任一下拉 / 变更密钥·地址·协议
    // 时，按表单实时值调管理端接口取模型列表，填充所有已注册的下拉字段。
    window.__tbModels = {
        fields: [],           // [{comp, name, def, emptyLabel}]
        sig: '', lastAt: 0, bound: false, lastList: null,
        fill: function (f, list) {
            // 只清动态 option 再重填列表；空项（value=""）由字段 placeholder 承担，不在这里加，避免重复。
            f.comp.clearOption(f.name);
            var hit = false;
            (list || []).forEach(function (m) {
                var id = typeof m === 'string' ? m : (m.id || m.name || '');
                if (id) { if (id === f.def) hit = true; f.comp.addOption(f.name, id, id, id === f.def, false); }
            });
            if (f.def && !hit) f.comp.addOption(f.name, f.def, f.def, true, false);   // 已保存的值不在最新列表里也保留
        },
        register: function (comp, name, def, emptyLabel) {
            var f = { comp: comp, name: name, def: def || '', emptyLabel: emptyLabel };
            this.fields.push(f);
            if (!this.bound) {
                this.bound = true;
                var self = this, scope = '.' + comp.unique;
                $(document).off('.tbModels');
                $(document).on('click.tbModels', scope + ' .component-ai_model, ' + scope + ' .component-rich_model', function () { self.refresh(false); });
                $(document).on('change.tbModels', scope + ' [name=ai_key], ' + scope + ' [name=ai_api], ' + scope + ' [name=ai_provider]', function () { self.refresh(true); });
            }
            // 统一走 fill 初始化（默认项 + 已缓存列表 + 保存值），避免 layui placeholder 与默认项重复。
            // 没缓存就先只放默认项，再去拉；拉回后 refresh 会 forEach 填充所有已注册字段。
            this.fill(f, this.lastList || []);
            layui.form.render();
            if (!this.lastList) { this.refresh(false); }
        },
        read: function () {
            var comp = this.fields[0] && this.fields[0].comp;
            if (!comp) return { provider: '', api: '', key: '' };
            var box = $('.' + comp.unique);
            return {
                provider: box.find('[name=ai_provider]').val() || '',
                api: box.find('[name=ai_api]').val() || '',
                key: box.find('[name=ai_key]').val() || ''
            };
        },
        refresh: function (force) {
            if (!this.fields.length) return;
            var now = Date.now();
            if (!force && now - this.lastAt < 3000) return;
            var p = this.read();
            var sig = JSON.stringify(p);
            if (!force && sig === this.sig) return;
            this.lastAt = now;
            var self = this;
            util.post({
                url: '/plugin/TranslationBot/admin/models',
                data: p,
                loader: false,
                done: function (res) {
                    if (!res || res.code != 200) return;
                    self.sig = sig;
                    self.lastList = (res.data && res.data.list) || [];
                    self.fields.forEach(function (f) { self.fill(f, self.lastList); });
                    layui.form.render();
                },
                error: function () {
                }
            });
        }
    };

    return [
        {
            name: '接入设置',
            form: [
                {
                    title: false,
                    name: "explain_intro",
                    type: "custom",
                    submit: false,
                    complete: function (form, dom) {
                        var intro = '<div class="alert alert-primary" style="margin:0">' + i18n('监听全站国际化的「翻译未命中」事件，异步批量翻译并写回词库。所有翻译都在后台队列中完成，不会阻塞用户请求。') + '</div>';
                        var assign = (form && form.opt && form.opt.assign) || {};
                        if (assign.STATUS == 1) {
                            dom.html(intro);
                            return;
                        }

                        // 插件未启用：置顶警告 + 一键启用（与插件列表的「启用」按钮同一接口）。
                        // 成功后回写 assign.STATUS（assign 即列表行的 PLUGIN_CONFIG，重开弹窗不再误报）并同步列表状态徽章。
                        dom.html(
                            '<style>.tb-enable-now:hover{background:rgba(var(--md-warning-rgb,255,171,0),.16)}</style>' +
                            '<div class="alert alert-warning tb-status-tip" style="margin:0 0 10px;display:flex;align-items:center;gap:12px;">' +
                                '<i class="fa-duotone fa-regular fa-triangle-exclamation" style="font-size:18px;flex:none;"></i>' +
                                '<div style="flex:1;min-width:0;"><b>' + i18n('插件尚未启用') + '</b><span style="opacity:.85">' + i18n('，配置可以先保存，但翻译功能要在启用插件后才会运行。') + '</span></div>' +
                                '<button type="button" class="tb-enable-now" style="flex:none;border:1px solid currentColor;background:transparent;color:inherit;border-radius:8px;padding:4px 14px;font-size:12px;font-weight:600;line-height:1.7;cursor:pointer;transition:background .15s ease;">' + i18n('立即启用') + '</button>' +
                            '</div>' + intro
                        );
                        dom.find('.tb-enable-now').on('click', function () {
                            var $btn = $(this).prop('disabled', true).css('opacity', .55);
                            var revert = function () { $btn.prop('disabled', false).css('opacity', 1); };
                            util.post({
                                url: '/admin/api/plugin/setConfig',
                                data: {id: 'TranslationBot', STATUS: 1},
                                done: function (res) {
                                    assign.STATUS = 1;
                                    $('.plugin-state[data-id=TranslationBot]').removeClass('badge-light-danger').addClass('badge-light-success').html(i18n('运行中'));
                                    dom.find('.tb-status-tip').replaceWith(
                                        '<div class="alert alert-success" style="margin:0 0 10px;display:flex;align-items:center;gap:12px;">' +
                                            '<i class="fa-duotone fa-regular fa-circle-check" style="font-size:18px;flex:none;"></i>' +
                                            '<div><b>' + i18n('插件已启用') + '</b><span style="opacity:.85">' + i18n('，保存下方配置即可开始翻译。') + '</span></div>' +
                                        '</div>'
                                    );
                                    layer.msg(res.msg || i18n('插件已启动'));
                                },
                                error: function (res) { revert(); message.error((res && res.msg) || i18n('启用失败')); },
                                fail: function () { revert(); message.error(i18n('网络错误，请重试')); }
                            });
                        });
                    }
                },
                {
                    title: "接口协议",
                    name: "ai_provider",
                    type: "select",
                    dict: [
                        {id: "openai_responses", name: "OpenAI Responses API"},
                        {id: "claude", name: "Claude Messages API"},
                        {id: "gemini", name: "Google Gemini"}
                    ],
                    default: "openai_responses"
                },
                {
                    title: "API 地址",
                    name: "ai_api",
                    type: "input",
                    placeholder: "基础地址，留空用官方默认",
                    tips: "只填基址（如 https://api.openai.com、中转站地址），无需带路径。Claude 默认 https://api.anthropic.com，Gemini 默认 https://generativelanguage.googleapis.com。"
                },
                {
                    title: "API 密钥",
                    name: "ai_key",
                    type: "input",
                    placeholder: "sk-... / AIza..."
                },
                {
                    title: "翻译模型",
                    name: "ai_model",
                    type: "select",
                    search: true,
                    dict: [],
                    placeholder: "自动选择（推荐）",
                    tips: "界面短语用，建议选轻快便宜的模型（如 gpt-4o-mini、claude-haiku、gemini-flash）。打开下拉或变更密钥/地址时自动拉取列表。",
                    complete: function (comp, def) { window.__tbModels && window.__tbModels.register(comp, 'ai_model', def, '自动选择（推荐）'); }
                },
                {
                    title: "富文本模型",
                    name: "rich_model",
                    type: "select",
                    search: true,
                    dict: [],
                    placeholder: "留空则与上面同一个模型",
                    tips: "商品介绍等长富文本单独成批翻译，可在此指定更强的模型以保证 HTML 结构与文风质量。留空＝与翻译模型相同。与翻译模型共用同一份列表，打开下拉自动拉取。",
                    complete: function (comp, def) { window.__tbModels && window.__tbModels.register(comp, 'rich_model', def, '留空则与上面同一个模型'); }
                },
                {
                    title: false,
                    name: "promo_armai",
                    type: "custom",
                    submit: false,
                    complete: function (form, dom) {
                        // 推广卡片：整卡可点，token 驱动明暗主题，与上方警告/简介条同一布局语言。
                        // 注意：胶囊按钮的颜色必须放在 <style> 类里而不是行内样式，否则 hover 反色规则压不过行内 color，蓝底蓝字看不见。
                        dom.html(
                            '<style>' +
                            '.tb-armai{display:flex;align-items:center;gap:12px;margin-top:2px;padding:12px 14px;border:1px solid rgba(var(--md-primary-rgb,63,81,181),.22);border-radius:var(--md-radius,12px);background:linear-gradient(135deg,rgba(var(--md-primary-rgb,63,81,181),.09),rgba(var(--md-primary-rgb,63,81,181),.02));text-decoration:none;transition:border-color .18s ease,box-shadow .18s ease,transform .18s ease;}' +
                            '.tb-armai:hover{text-decoration:none;border-color:rgba(var(--md-primary-rgb,63,81,181),.45);box-shadow:0 6px 18px rgba(var(--md-primary-rgb,63,81,181),.15);transform:translateY(-1px);}' +
                            '.tb-armai-go{flex:none;display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:999px;border:1px solid rgba(var(--md-primary-rgb,63,81,181),.4);background:transparent;color:var(--md-primary,#3f51b5);font-size:12px;font-weight:600;transition:background .18s ease,color .18s ease,border-color .18s ease;}' +
                            '.tb-armai-go i{font-size:11px;color:inherit;}' +
                            '.tb-armai:hover .tb-armai-go{background:var(--md-primary,#3f51b5);border-color:var(--md-primary,#3f51b5);color:var(--md-on-primary,#fff);}' +
                            '</style>' +
                            '<a class="tb-armai" href="https://ai.arm.moe" target="_blank" rel="noopener">' +
                                '<span style="flex:none;width:38px;height:38px;display:flex;align-items:center;justify-content:center;border-radius:11px;background:linear-gradient(135deg,var(--md-primary,#3f51b5),#7c4dff);color:#fff;font-size:17px;box-shadow:0 4px 10px rgba(var(--md-primary-rgb,63,81,181),.35);"><i class="fa-duotone fa-regular fa-sparkles"></i></span>' +
                                '<span style="flex:1;min-width:0;">' +
                                    '<b style="display:block;font-size:13px;color:var(--md-on-surface,#1f1f1f);">' + i18n('还没有 AI 接口？用 ARM-AI') + '</b>' +
                                    '<span style="display:block;margin-top:3px;font-size:12px;line-height:1.5;color:var(--md-on-surface-med,#5f6368);">' + i18n('GPT、Claude、Grok、Gemini 全系模型一站直连，低峰期低至 0.01 折；注册后把地址和密钥填到上面即可使用。') + '</span>' +
                                '</span>' +
                                '<span class="tb-armai-go">ai.arm.moe <i class="fa-duotone fa-regular fa-arrow-up-right"></i></span>' +
                            '</a>'
                        );
                    }
                }
            ]
        },
        {
            name: '运行设置',
            form: [
                {
                    title: "每批条数",
                    name: "batch_size",
                    type: "input",
                    inputmode: "numeric",
                    default: "10",
                    tips: "一次请求翻译多少条短语。过大容易导致模型串行漏译，建议 5~20。"
                },
                {
                    title: "每次最多调用",
                    name: "max_calls_per_tick",
                    type: "input",
                    inputmode: "numeric",
                    default: "3",
                    tips: "单次触发最多发起几次模型调用，配合 8 秒时间盒防止长跑。"
                },
                {
                    title: "并发数",
                    name: "concurrency",
                    type: "input",
                    inputmode: "numeric",
                    default: "1",
                    tips: "同时并行的模型调用数（批次数），1=逐批串行。由「线程管理器」常驻任务以协程并行执行；面板「立即处理」手动触发（无协程）时始终串行。请结合上游接口的限流设置，并注意「每次最多调用」是每轮总批次上限。"
                },
                {
                    title: "免翻词表",
                    name: "brand_words",
                    type: "textarea",
                    height: 100,
                    placeholder: "品牌名、专有名词，逗号或换行分隔，例如：\n异次元\nSteam\nNetflix",
                    tips: "这些词会要求模型原样保留，不做翻译。"
                }
            ]
        },
        {
            name: '运行方式',
            form: [
                {
                    title: false,
                    name: "tm_status",
                    type: "custom",
                    submit: false,
                    complete: function (form, dom) {
                        // 运行驱动完全交给「线程管理器」常驻任务。这里实时探测其安装/启用/运行状态，
                        // 一步步把用户引导到「安装 → 启用 → 起守护进程 → 任务运行中」。仿 AutoStockSync 同款体验。
                        var css = `<style>
                        .tb-box{border:1px solid var(--md-divider,#e6edf5);border-radius:10px;overflow:hidden;font-size:13px;line-height:1.7}
                        .tb-hd{padding:12px 14px;display:flex;align-items:center;gap:8px;font-weight:600}
                        .tb-dot{width:8px;height:8px;border-radius:50%;flex:0 0 auto}
                        .tb-bd{padding:12px 14px;border-top:1px solid var(--md-divider,#e6edf5)}
                        .tb-kv{display:flex;flex-wrap:wrap;gap:6px 22px;margin-top:2px}
                        .tb-kv div{font-size:12px;color:var(--md-on-surface-med,#64748b)}
                        .tb-kv b{color:var(--md-on-surface,#0f172a);font-weight:600;font-variant-numeric:tabular-nums}
                        .tb-code{display:block;background:#0c0f14;color:#d7dee9;border-radius:8px;
                                 font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px;
                                 line-height:1.9;padding:11px 13px;white-space:pre;overflow-x:auto;margin:8px 0 0}
                        .tb-note{font-size:12px;color:var(--md-on-surface-med,#64748b);margin-top:8px}
                        .tb-err{font-size:12px;color:var(--md-error,#d33);margin-top:6px;word-break:break-all}
                        </style>`;

                        var render = function (html) { dom.html(css + '<div class="tb-box">' + html + '</div>'); };
                        var box = function (color, title, body) {
                            return '<div class="tb-hd" style="background:rgba(' + color + ',.08);color:rgb(' + color + ')">' +
                                '<span class="tb-dot" style="background:rgb(' + color + ')"></span>' + title + '</div>' +
                                '<div class="tb-bd">' + body + '</div>';
                        };
                        var manual = '<div class="tb-note">没有线程管理器时，也可到 <a href="/plugin/TranslationBot/panel/index" target="_blank">翻译队列</a> 面板点「立即处理」手动翻译；但只有装了线程管理器才能无人值守自动翻译。</div>';

                        render(box("148,163,184", "正在检测运行环境…", ""));

                        util.post({
                            url: "/plugin/TranslationBot/admin/runtime",
                            loader: false,
                            error: false,
                            done: function (res) {
                                var d = (res && res.data) || {};

                                if (!d.installed) {
                                    render(box("237,108,2", "未安装「线程管理器」插件", '翻译的自动执行依赖<b>线程管理器</b>提供常驻运行能力。请先到应用商店安装并启用它，未命中的词条会先在队列里排队，装好后自动开始翻译。' + manual));
                                    return;
                                }
                                if (!d.enabled) {
                                    render(box("237,108,2", "「线程管理器」未启用", '请到<b>通用插件</b>里启用「线程管理器」，翻译任务才会被注册。' + manual));
                                    return;
                                }
                                if (!d.running) {
                                    render(box("211,47,47", "「线程管理器」守护进程未运行", '任务已注册，但守护进程没在跑，翻译不会执行。请在服务器上执行：' +
                                        '<code class="tb-code">cd /你的网站根目录\nchmod +x ./app/Plugin/ThreadManager/service.sh\n./app/Plugin/ThreadManager/service.sh install</code>' +
                                        '<div class="tb-note">这是一次性操作，之后所有插件的常驻任务都共用它。</div>'));
                                    return;
                                }
                                var t = d.task;
                                if (!t) {
                                    render(box("237,108,2", "运行中，但尚未注册翻译任务", '保存本页配置后即会注册；若已保存，请到 <a href="' + d.panel + '" target="_blank">线程管理器</a> 点一下「重载注册表」。'));
                                    return;
                                }
                                var ago = t.ts ? Math.max(0, Math.round(Date.now() / 1000 - t.ts)) + " 秒前" : "—";
                                render(box("46,125,50", "翻译任务运行中", '<div class="tb-kv">' +
                                    '<div>任务　<b>' + t.id + '</b></div>' +
                                    '<div>已执行　<b>' + t.iter + '</b> 轮</div>' +
                                    '<div>本轮耗时　<b>' + (t.last_ms == null ? "—" : t.last_ms) + '</b> ms</div>' +
                                    '<div>最近运行　<b>' + ago + '</b></div>' +
                                    '<div>重启　<b>' + t.restarts + '</b></div>' +
                                    '</div>' +
                                    (t.error ? '<div class="tb-err">⚠ ' + t.error + '</div>' : '') +
                                    '<div class="tb-note">修改下面的巡检间隔或并发数并保存后自动生效，无需重启任何服务。详细日志与手动启停见 <a href="' + d.panel + '" target="_blank">线程管理器</a>。</div>'));
                            },
                            fail: function () { render(box("211,47,47", "检测失败", "无法读取运行状态，请刷新页面重试。")); }
                        });
                    }
                },
                {
                    title: "任务巡检间隔(秒)",
                    name: "task_interval",
                    type: "input",
                    inputmode: "numeric",
                    default: "15",
                    tips: "线程管理器每隔该间隔巡检一次队列，有存货时连续消费直到翻完再回到巡检节奏。最小 5 秒。修改后保存即自动生效（管理器会自动重载注册表）。"
                }
            ]
        }
    ];
})()
