<?php
declare(strict_types=1);

use App\Consts\Plugin;

return [
    Plugin::NAME => 'AI自动多语言',
    Plugin::AUTHOR => '荔枝',
    Plugin::WEB_SITE => '#',
    Plugin::DESCRIPTION => '全站国际化的自动翻译后端：监听翻译库未命中事件（如商品介绍），异步批量调用大模型（OpenAI Responses / Claude / Gemini）翻译并回写词库。全流程队列化，绝不阻塞前台请求。启用后商品编辑弹窗会多出「多语言」标签页，可按商品维护译文或一键 AI 翻译。翻译由「线程管理器」的常驻任务驱动，支持多并发；请先安装并启用「线程管理器」插件。',
    Plugin::VERSION => '1.1.1'
];
