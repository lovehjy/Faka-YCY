<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent;

/**
 * Provider 归一化流事件：text_delta（文本增量）| tool_call（完整工具调用）| done
 * Provider 只在参数完整拼好并 json_decode 成功后才发 tool_call，循环层永远看不到半截 JSON
 */
class StreamEvent
{
    public const TEXT = 'text_delta';
    public const TOOL = 'tool_call';
    public const DONE = 'done';

    public string $type;
    public string $text = '';
    public ?ToolCall $call = null;
    public string $stop = '';

    public static function text(string $delta): self
    {
        $e = new self();
        $e->type = self::TEXT;
        $e->text = $delta;
        return $e;
    }

    public static function tool(ToolCall $call): self
    {
        $e = new self();
        $e->type = self::TOOL;
        $e->call = $call;
        return $e;
    }

    public static function done(string $stopReason = ''): self
    {
        $e = new self();
        $e->type = self::DONE;
        $e->stop = $stopReason;
        return $e;
    }
}
