<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent\Support;

/**
 * 模型能力库（Config/ModelCapabilities.json）：推理档位与输出上限自适应
 * 逻辑自 Controller/Api.php 原样迁入，行为不变
 */
class ModelCaps
{
    private static ?array $db = null;

    /**
     * 本插件自己的配置。消费者可能在 shutdown / 自唤醒请求里跑，
     * 那里未必有全局 helper，所以直接走 Util\Plugin 并吞掉异常。
     */
    private static function pluginConfig(): array
    {
        try {
            return (array)\App\Util\Plugin::getConfig('TranslationBot');
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** 按模型名查能力：精确匹配 → 最长前缀匹配 → null */
    public static function for(string $model): ?array
    {
        if (self::$db === null) {
            //自带一份能力表，不依赖 PetAgent 是否安装
            $raw = @file_get_contents(BASE_PATH . '/app/Plugin/TranslationBot/Config/ModelCapabilities.json');
            $list = json_decode((string)$raw, true);
            self::$db = is_array($list) ? $list : [];
        }
        $model = strtolower(trim($model));
        if ($model === '') {
            return null;
        }
        $best = null;
        $bestLen = 0;
        foreach (self::$db as $item) {
            $id = strtolower((string)($item['modelId'] ?? ''));
            if ($id === '') {
                continue;
            }
            if ($id === $model) {
                return $item;
            }
            if (strpos($model, $id) === 0 && strlen($id) > $bestLen) {
                $best = $item;
                $bestLen = strlen($id);
            }
        }
        return $best;
    }

    /** 站长配置的推理强度：off/low/medium/high；按模型支持列表校正 */
    public static function reasoningEffort(?array $caps): string
    {
        //从 PetAgent 复制过来时这里读的是 PetAgent 的配置，改读本插件自己的，避免跨插件依赖
        $cfg = strtolower(trim((string)(self::pluginConfig()['ai_reasoning'] ?? 'off')));
        if (!in_array($cfg, ['off', 'low', 'medium', 'high'], true)) {
            $cfg = 'off';
        }
        if ($cfg === 'off') {
            return 'off';
        }
        $supported = $caps ? array_map('strval', (array)($caps['reasoningEfforts'] ?? [])) : null;
        if ($supported !== null) {
            if (!$supported) {
                return 'off'; // 模型不支持推理
            }
            if (!in_array($cfg, $supported, true)) {
                $fallback = array_values(array_intersect(['low', 'medium', 'high', 'minimal'], $supported));
                return $fallback ? $fallback[0] : 'off';
            }
        }
        return $cfg;
    }

    /** 场景合理输出上限：min(模型 maxOutputTokens, 按推理档位的预算)——推理 token 会计入输出 */
    public static function outputBudget(?array $caps, string $effort): int
    {
        $budget = match ($effort) {
            'off' => 2048,
            'low', 'minimal' => 8192,
            'medium' => 16384,
            default => 32768,
        };
        $modelMax = $caps ? (int)($caps['maxOutputTokens'] ?? 0) : 0;
        return $modelMax > 0 ? min($modelMax, $budget) : $budget;
    }
}
