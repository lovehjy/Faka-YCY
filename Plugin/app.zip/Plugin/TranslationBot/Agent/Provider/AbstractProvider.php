<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent\Provider;

use App\Plugin\TranslationBot\Agent\Contract\ProviderInterface;
use App\Util\Http;
use Kernel\Exception\JSONException;

/**
 * Provider 公共底座：SSE 泵（自旧 Api::streamProvider 迁入）、URL 规范化、非流式 POST
 */
abstract class AbstractProvider implements ProviderInterface
{
    protected string $base;
    protected string $apiKey;
    protected string $model;

    public function __construct(string $base, string $apiKey, string $model)
    {
        $this->base = rtrim($base, '/');
        $this->apiKey = $apiKey;
        $this->model = $model;
    }

    public function cacheKey(): string
    {
        return $this->proto() . '|' . $this->base . '|' . $this->model;
    }

    /** URL 规范化：base 已带 suffix 直接用；base 以 /v1 结尾时避免重复拼 /v1 */
    protected function providerUrl(string $suffix): string
    {
        $base = rtrim($this->base, '/');
        if ($suffix !== '' && str_ends_with($base, $suffix)) {
            return $base;
        }
        if (str_ends_with($base, '/v1') && str_starts_with($suffix, '/v1/')) {
            return $base . substr($suffix, 3);
        }
        return $base . $suffix;
    }

    /**
     * 上游 SSE 泵：每个 data: JSON 交给 $onJson；上游没按 SSE 回话时解析错误体抛出真实原因
     * @throws JSONException
     */
    protected function pump(string $url, array $headers, array $payload, callable $onJson): void
    {
        $response = Http::make(['timeout' => 90])->post($url, [
            'headers' => $headers,
            'json' => $payload,
            'stream' => true,
        ]);
        $body = $response->getBody();
        $buffer = '';
        $sawData = false;
        $raw = '';
        while (!$body->eof()) {
            $chunk = $body->read(2048);
            if (!$sawData && strlen($raw) < 2000) {
                $raw .= $chunk;   // 万一不是 SSE，留个现场好报错
            }
            $buffer .= $chunk;
            while (($pos = strpos($buffer, "\n")) !== false) {
                $line = trim(substr($buffer, 0, $pos));
                $buffer = substr($buffer, $pos + 1);
                if ($line === '' || strpos($line, 'data:') !== 0) {
                    continue;
                }
                $sawData = true;
                $data = trim(substr($line, 5));
                if ($data === '[DONE]') {
                    return;
                }
                $json = json_decode($data, true);
                if (is_array($json)) {
                    $onJson($json);
                }
            }
        }
        if (!$sawData) {
            // 上游没有按 SSE 回话（限流/鉴权失败/参数被拒等会直接回 JSON 错误体），把原因带出来
            $err = '';
            $json = json_decode(trim($raw), true);
            if (is_array($json)) {
                $err = (string)($json['error']['message'] ?? $json['message'] ?? $json['msg'] ?? '');
            }
            throw new JSONException('模型接口无响应' . ($err !== '' ? '：' . mb_substr($err, 0, 160) : ''));
        }
    }

    //默认 90 秒与流式 pump 一致：批量翻译在上游繁忙时 30 秒会被自己掐死（0 bytes received）
    protected function postJson(string $url, array $headers, array $payload, int $timeout = 90): array
    {
        $response = Http::make(['timeout' => $timeout])->post($url, [
            'headers' => $headers,
            'json' => $payload,
        ]);
        $json = json_decode((string)$response->getBody()->getContents(), true);
        return is_array($json) ? $json : [];
    }

    /** 空 properties 的 object 必须编码成 {} 而不是 []（各协议通用） */
    protected static function normalizeSchema(array $schema): array
    {
        if (($schema['type'] ?? '') === 'object' && empty($schema['properties'])) {
            $schema['properties'] = new \stdClass();
        }
        return $schema;
    }
}
