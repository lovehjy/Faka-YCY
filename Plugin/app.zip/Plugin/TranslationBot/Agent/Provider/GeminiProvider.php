<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent\Provider;

use App\Plugin\TranslationBot\Agent\ChatRequest;
use App\Plugin\TranslationBot\Agent\Capability\ToolsCapability;
use App\Plugin\TranslationBot\Agent\StreamEvent;
use App\Plugin\TranslationBot\Agent\Support\ModelCaps;
use App\Plugin\TranslationBot\Agent\ToolCall;
use Kernel\Exception\JSONException;

/**
 * Gemini（Google 官方 / 中转）
 * 原生工具：functionDeclarations；parts[].functionCall 整块到达（args 已是对象）；
 * 回放 model[functionCall] + user[functionResponse]，被拒时降级 role:"function" 重试一次
 */
class GeminiProvider extends AbstractProvider
{
    public function proto(): string
    {
        return 'gemini';
    }

    private function headers(bool $stream): array
    {
        $headers = ['X-Goog-Api-Key' => $this->apiKey, 'Content-Type' => 'application/json', 'Accept' => $stream ? 'text/event-stream' : 'application/json'];
        if (!preg_match('#^https://generativelanguage\.googleapis\.com#i', $this->base)) {
            $headers['Authorization'] = 'Bearer ' . $this->apiKey; // 中转普遍要求 Bearer
        }
        return $headers;
    }

    /** Gemini URL：兼容 base 无路径 / 以 /v1 结尾 / 以 /v1beta 结尾等形态 */
    private function geminiUrl(bool $stream): string
    {
        $base = rtrim($this->base, '/');
        $action = $stream ? ':streamGenerateContent?alt=sse' : ':generateContent';
        if (strpos($base, ':generateContent') !== false || strpos($base, ':streamGenerateContent') !== false) {
            return $base;
        }
        $m = rawurlencode($this->model);
        if (str_ends_with($base, '/v1beta') || str_ends_with($base, '/v1')) {
            return $base . '/models/' . $m . $action;
        }
        return $base . '/v1beta/models/' . $m . $action;
    }

    /** Gemini 的 schema 白名单裁剪（v1beta 只认 OpenAPI 子集） */
    private static function geminiSchema(array $schema): array
    {
        $keep = function (array $s) use (&$keep): array {
            $out = [];
            foreach (['type', 'description', 'enum', 'required'] as $k) {
                if (isset($s[$k])) {
                    $out[$k] = $s[$k];
                }
            }
            if (isset($s['properties']) && is_array($s['properties'])) {
                $props = [];
                foreach ($s['properties'] as $name => $def) {
                    $props[$name] = $keep((array)$def);
                }
                if ($props) {
                    $out['properties'] = $props;
                }
            }
            if (isset($s['items'])) {
                $out['items'] = $keep((array)$s['items']);
            }
            return $out;
        };
        return $keep($schema);
    }

    private function buildPayload(ChatRequest $req, bool $stream, string $fnRole = 'user'): array
    {
        $caps = ModelCaps::for($this->model);
        $effort = ModelCaps::reasoningEffort($caps);
        $maxOut = ModelCaps::outputBudget($caps, $effort);

        $contents = [];
        if ($req->tools !== null) {
            foreach ($req->conversation->entries() as $e) {
                if ($e['role'] === 'tool') {
                    $data = json_decode($e['json'], true);
                    $contents[] = ['role' => $fnRole, 'parts' => [[
                        'functionResponse' => ['name' => $e['call']->name, 'response' => ['result' => is_array($data) ? $data : ['raw' => $e['json']]]],
                    ]]];
                    continue;
                }
                $text = trim((string)($e['text'] ?? ''));
                if (isset($e['call'])) {
                    $parts = [];
                    if ($text !== '') {
                        $parts[] = ['text' => $text];
                    }
                    $parts[] = ['functionCall' => ['name' => $e['call']->name, 'args' => $e['call']->args ?: new \stdClass()]];
                    $contents[] = ['role' => 'model', 'parts' => $parts];
                    continue;
                }
                if ($text !== '') {
                    $contents[] = ['role' => $e['role'] === 'assistant' ? 'model' : 'user', 'parts' => [['text' => $text]]];
                }
            }
        } else {
            foreach ($req->conversation->toPlainMessages() as $m) {
                $contents[] = ['role' => $m['role'] === 'assistant' ? 'model' : 'user', 'parts' => [['text' => $m['content']]]];
            }
        }

        $generation = ['maxOutputTokens' => $maxOut, 'temperature' => 0.8];
        if ($effort !== 'off' && $caps && (array)($caps['reasoningEfforts'] ?? [])) {
            $generation['thinkingConfig'] = ['thinkingBudget' => match ($effort) { 'minimal', 'low' => 1024, 'medium' => 8192, default => 24576 }];
        }
        $payload = ['systemInstruction' => ['parts' => [['text' => $req->system]]], 'contents' => $contents, 'generationConfig' => $generation];
        if ($req->tools !== null) {
            $decls = [];
            foreach ($req->tools as $t) {
                $decl = ['name' => $t['name'], 'description' => $t['description']];
                $schema = self::geminiSchema($t['schema']);
                if (!empty($schema['properties'])) {
                    $decl['parameters'] = $schema;   // 零参工具省略 parameters（部分后端拒绝空 OBJECT）
                }
                $decls[] = $decl;
            }
            $payload['tools'] = [['functionDeclarations' => $decls]];
        }
        return [$this->geminiUrl($stream), $this->headers($stream), $payload];
    }

    public function stream(ChatRequest $req, callable $onEvent): void
    {
        $hasToolResult = false;
        foreach ($req->conversation->entries() as $e) {
            if ($e['role'] === 'tool') {
                $hasToolResult = true;
                break;
            }
        }
        try {
            $this->streamWith($req, $onEvent, 'user');
        } catch (\Throwable $e) {
            // functionResponse 的 role 各版本口径不一：带工具回放失败时降级 legacy role 再试一次
            if ($req->tools !== null && $hasToolResult) {
                $this->streamWith($req, $onEvent, 'function');
                return;
            }
            throw $e;
        }
    }

    private function streamWith(ChatRequest $req, callable $onEvent, string $fnRole): void
    {
        [$url, $headers, $payload] = $this->buildPayload($req, true, $fnRole);
        $this->pump($url, $headers, $payload, function (array $json) use ($onEvent) {
            foreach ((array)($json['candidates'][0]['content']['parts'] ?? []) as $p) {
                if (isset($p['functionCall'])) {
                    $fc = (array)$p['functionCall'];
                    $args = (array)($fc['args'] ?? []);
                    $onEvent(StreamEvent::tool(new ToolCall(null, (string)($fc['name'] ?? ''), $args)));
                    continue;
                }
                $t = (string)($p['text'] ?? '');
                if ($t !== '') {
                    $onEvent(StreamEvent::text($t));
                }
            }
        });
        $onEvent(StreamEvent::done());
    }

    public function complete(ChatRequest $req): string
    {
        [$url, $headers, $payload] = $this->buildPayload($req, false);
        $json = $this->postJson($url, $headers, $payload);
        $out = '';
        foreach ((array)($json['candidates'][0]['content']['parts'] ?? []) as $p) {
            $out .= (string)($p['text'] ?? '');
        }
        return $out;
    }

    public function probeTools(): array
    {
        $payload = [
            'systemInstruction' => ['parts' => [['text' => '你是能力探针，按要求调用工具。']]],
            'contents' => [['role' => 'user', 'parts' => [['text' => '调用 probe 工具，参数 ping=ok']]]],
            'generationConfig' => ['maxOutputTokens' => 64],
            'tools' => [['functionDeclarations' => [[
                'name' => 'probe', 'description' => '能力探测',
                'parameters' => ['type' => 'object', 'properties' => ['ping' => ['type' => 'string']], 'required' => ['ping']],
            ]]]],
            'toolConfig' => ['functionCallingConfig' => ['mode' => 'ANY', 'allowedFunctionNames' => ['probe']]],
        ];
        $url = $this->geminiUrl(false);
        try {
            $json = $this->postJson($url, $this->headers(false), $payload, 15);
            if ($this->hasFunctionCall($json)) {
                return ['native' => true, 'reason' => 'probe:tool_use', 'cacheable' => true];
            }
            if (isset($json['error'])) {
                throw new \RuntimeException((string)json_encode($json['error'], JSON_UNESCAPED_UNICODE));
            }
        } catch (\Throwable $e) {
            if (!ToolsCapability::looksLikeToolsRejection($e->getMessage())) {
                return ['native' => false, 'reason' => 'inconclusive:' . mb_substr($e->getMessage(), 0, 60), 'cacheable' => false];
            }
            unset($payload['toolConfig']);
            try {
                $json = $this->postJson($url, $this->headers(false), $payload, 15);
                if ($this->hasFunctionCall($json)) {
                    return ['native' => true, 'reason' => 'probe:tool_use_noforce', 'cacheable' => true];
                }
            } catch (\Throwable $e2) {
            }
            return ['native' => false, 'reason' => 'http:' . mb_substr($e->getMessage(), 0, 80), 'cacheable' => true];
        }
        return ['native' => false, 'reason' => 'probe:silent_ignore', 'cacheable' => true];
    }

    private function hasFunctionCall(array $json): bool
    {
        foreach ((array)($json['candidates'][0]['content']['parts'] ?? []) as $p) {
            if (isset($p['functionCall'])) {
                return true;
            }
        }
        return false;
    }
}
