<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent\Provider;

use App\Plugin\TranslationBot\Agent\ChatRequest;
use App\Plugin\TranslationBot\Agent\Capability\ToolsCapability;
use App\Plugin\TranslationBot\Agent\StreamEvent;
use App\Plugin\TranslationBot\Agent\Support\ModelCaps;
use App\Plugin\TranslationBot\Agent\ToolCall;
use Kernel\Exception\JSONException;

/**
 * Claude Messages（Anthropic 官方 / 中转）
 * 原生工具：tools[input_schema]；流式 content_block_start(tool_use) + input_json_delta 累积
 * + content_block_stop 定稿；回放 assistant[tool_use] + user[tool_result]
 */
class ClaudeProvider extends AbstractProvider
{
    public function proto(): string
    {
        return 'claude';
    }

    private function headers(bool $stream): array
    {
        return [
            'Authorization' => 'Bearer ' . $this->apiKey,
            'X-Api-Key' => $this->apiKey,
            'Anthropic-Version' => '2023-06-01',
            'Content-Type' => 'application/json',
            'Accept' => $stream ? 'text/event-stream' : 'application/json',
        ];
    }

    private function buildPayload(ChatRequest $req, bool $stream): array
    {
        $caps = ModelCaps::for($this->model);
        $effort = ModelCaps::reasoningEffort($caps);
        $maxOut = ModelCaps::outputBudget($caps, $effort);

        $messages = [];
        if ($req->tools !== null) {
            foreach ($req->conversation->entries() as $e) {
                if ($e['role'] === 'tool') {
                    $messages[] = ['role' => 'user', 'content' => [[
                        'type' => 'tool_result', 'tool_use_id' => $e['call']->id, 'content' => $e['json'],
                    ]]];
                    continue;
                }
                $text = trim((string)($e['text'] ?? ''));
                if (isset($e['call'])) {
                    $content = [];
                    if ($text !== '') {
                        $content[] = ['type' => 'text', 'text' => $text];   // 空 text 块 API 会拒绝，必须省略
                    }
                    $content[] = ['type' => 'tool_use', 'id' => $e['call']->id, 'name' => $e['call']->name, 'input' => $e['call']->args ?: new \stdClass()];
                    $messages[] = ['role' => 'assistant', 'content' => $content];
                    continue;
                }
                if ($text !== '') {
                    $messages[] = ['role' => $e['role'], 'content' => $text];
                }
            }
        } else {
            $messages = $req->conversation->toPlainMessages();
        }

        $payload = ['model' => $this->model, 'system' => $req->system, 'messages' => $messages, 'max_tokens' => $maxOut, 'stream' => $stream];
        if ($effort !== 'off' && $caps && (array)($caps['reasoningEfforts'] ?? [])) {
            $budget = match ($effort) { 'low' => 2048, 'medium' => 8192, default => 16384 };
            $payload['thinking'] = ['type' => 'enabled', 'budget_tokens' => $budget];
            if ($payload['max_tokens'] <= $budget) {
                $payload['max_tokens'] = $budget + 1024; // thinking 要求 max_tokens 严格大于预算
            }
        }
        if ($req->tools !== null) {
            $payload['tools'] = array_map(fn($t) => [
                'name' => $t['name'],
                'description' => $t['description'],
                'input_schema' => self::normalizeSchema($t['schema']),
            ], $req->tools);
            // 不发 tool_choice（默认 auto），最大化中转兼容性；单次单工具靠提示词约束
        }
        return [$this->providerUrl('/v1/messages'), $this->headers($stream), $payload];
    }

    public function stream(ChatRequest $req, callable $onEvent): void
    {
        [$url, $headers, $payload] = $this->buildPayload($req, true);
        $blocks = [];   // index => {id, name, json 累积}
        $failed = null;
        $this->pump($url, $headers, $payload, function (array $json) use (&$blocks, &$failed, $onEvent) {
            $type = (string)($json['type'] ?? '');
            if ($type === 'content_block_delta') {
                $delta = (array)($json['delta'] ?? []);
                $dt = (string)($delta['type'] ?? '');
                if ($dt === 'text_delta') {
                    $d = (string)($delta['text'] ?? '');
                    if ($d !== '') {
                        $onEvent(StreamEvent::text($d));
                    }
                } elseif ($dt === 'input_json_delta') {
                    $idx = (int)($json['index'] ?? -1);
                    if (isset($blocks[$idx])) {
                        $blocks[$idx]['json'] .= (string)($delta['partial_json'] ?? '');
                    }
                }
                return;
            }
            if ($type === 'content_block_start' && (($json['content_block']['type'] ?? '') === 'tool_use')) {
                $idx = (int)($json['index'] ?? -1);
                $blocks[$idx] = [
                    'id' => (string)($json['content_block']['id'] ?? ''),
                    'name' => (string)($json['content_block']['name'] ?? ''),
                    'json' => '',
                ];
                return;
            }
            if ($type === 'content_block_stop') {
                $idx = (int)($json['index'] ?? -1);
                if (isset($blocks[$idx])) {
                    $args = $blocks[$idx]['json'] === '' ? [] : json_decode($blocks[$idx]['json'], true);
                    $onEvent(StreamEvent::tool(new ToolCall($blocks[$idx]['id'], $blocks[$idx]['name'], is_array($args) ? $args : [])));
                    unset($blocks[$idx]);
                }
                return;
            }
            if ($type === 'error') {
                $failed = (string)($json['error']['message'] ?? '上游返回失败');
            }
        });
        if ($failed !== null) {
            throw new JSONException(mb_substr('上游错误：' . $failed, 0, 160));
        }
        $onEvent(StreamEvent::done());
    }

    public function complete(ChatRequest $req): string
    {
        [$url, $headers, $payload] = $this->buildPayload($req, false);
        $json = $this->postJson($url, $headers, $payload);
        $out = '';
        foreach ((array)($json['content'] ?? []) as $c) {
            $out .= (string)($c['text'] ?? '');
        }
        return $out;
    }

    public function probeTools(): array
    {
        $payload = [
            'model' => $this->model,
            'system' => '你是能力探针，按要求调用工具。',
            'messages' => [['role' => 'user', 'content' => '调用 probe 工具，参数 ping=ok']],
            'max_tokens' => 128,
            'stream' => false,
            'tools' => [[
                'name' => 'probe', 'description' => '能力探测',
                'input_schema' => ['type' => 'object', 'properties' => ['ping' => ['type' => 'string']], 'required' => ['ping']],
            ]],
            'tool_choice' => ['type' => 'tool', 'name' => 'probe'],
        ];
        $url = $this->providerUrl('/v1/messages');
        try {
            $json = $this->postJson($url, $this->headers(false), $payload, 15);
            if ($this->hasToolUse($json)) {
                return ['native' => true, 'reason' => 'probe:tool_use', 'cacheable' => true];
            }
            if (isset($json['error'])) {
                throw new \RuntimeException((string)json_encode($json['error'], JSON_UNESCAPED_UNICODE));
            }
        } catch (\Throwable $e) {
            if (!ToolsCapability::looksLikeToolsRejection($e->getMessage())) {
                return ['native' => false, 'reason' => 'inconclusive:' . mb_substr($e->getMessage(), 0, 60), 'cacheable' => false];
            }
            unset($payload['tool_choice']);
            try {
                $json = $this->postJson($url, $this->headers(false), $payload, 15);
                if ($this->hasToolUse($json)) {
                    return ['native' => true, 'reason' => 'probe:tool_use_noforce', 'cacheable' => true];
                }
            } catch (\Throwable $e2) {
            }
            return ['native' => false, 'reason' => 'http:' . mb_substr($e->getMessage(), 0, 80), 'cacheable' => true];
        }
        return ['native' => false, 'reason' => 'probe:silent_ignore', 'cacheable' => true];
    }

    private function hasToolUse(array $json): bool
    {
        if (($json['stop_reason'] ?? '') === 'tool_use') {
            return true;
        }
        foreach ((array)($json['content'] ?? []) as $c) {
            if (($c['type'] ?? '') === 'tool_use') {
                return true;
            }
        }
        return false;
    }
}
