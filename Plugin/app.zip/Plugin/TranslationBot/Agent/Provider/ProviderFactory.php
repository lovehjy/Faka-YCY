<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent\Provider;

use App\Plugin\TranslationBot\Agent\Contract\ProviderInterface;
use App\Plugin\TranslationBot\Service\Models;
use Kernel\Exception\JSONException;

/**
 * 端点归一化 + 模型解析 + Provider 构造（自旧 Api::endpoint/resolveModel 迁入）
 */
class ProviderFactory
{
    /**
     * @return array{0:string,1:string,2:string} [provider, baseUrl, key]
     * @throws JSONException
     */
    public static function endpoint(array $config): array
    {
        $provider = (string)($config['ai_provider'] ?? 'openai_responses');
        if (!in_array($provider, ['openai_responses', 'claude', 'gemini'], true)) {
            $provider = 'openai_responses'; // 旧配置的 openai 一并归并到 Responses
        }
        $key = trim((string)($config['ai_key'] ?? ''));
        if ($key === '') {
            throw new JSONException("主人还没帮我接好大脑（未配置密钥）");
        }
        $base = rtrim(trim((string)($config['ai_api'] ?? '')), '/');
        if ($base === '') {
            $base = match ($provider) {
                'claude' => 'https://api.anthropic.com',
                'gemini' => 'https://generativelanguage.googleapis.com',
                default => 'https://api.openai.com',
            };
        }
        return [$provider, $base, $key];
    }

    /** @throws JSONException */
    public static function resolveModel(array $config, string $provider, string $base, string $key): string
    {
        $manual = trim((string)($config['ai_model'] ?? ''));
        if ($manual !== '' && strtolower($manual) !== 'auto') {
            return $manual;
        }
        $model = Models::pick(Models::fetch($provider, $base, $key));
        if ($model === '') {
            throw new JSONException("拉取模型列表失败，请在后台手动填写模型名");
        }
        return $model;
    }

    /** @throws JSONException */
    public static function make(array $config): ProviderInterface
    {
        [$provider, $base, $key] = self::endpoint($config);
        $model = self::resolveModel($config, $provider, $base, $key);
        return match ($provider) {
            'claude' => new ClaudeProvider($base, $key, $model),
            'gemini' => new GeminiProvider($base, $key, $model),
            default => new OpenAiResponsesProvider($base, $key, $model),
        };
    }

    public static function model(ProviderInterface $p): string
    {
        // cacheKey = proto|base|model
        $parts = explode('|', $p->cacheKey());
        return $parts[2] ?? '';
    }
}
