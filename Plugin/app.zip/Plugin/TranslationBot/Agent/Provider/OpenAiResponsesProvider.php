<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent\Provider;

use App\Plugin\TranslationBot\Agent\ChatRequest;
use App\Plugin\TranslationBot\Agent\Capability\ToolsCapability;
use App\Plugin\TranslationBot\Agent\StreamEvent;
use App\Plugin\TranslationBot\Agent\Support\ModelCaps;
use App\Plugin\TranslationBot\Agent\ToolCall;
use Kernel\Exception\JSONException;

/**
 * OpenAI Responses API（官方 / 中转 / Grok）
 * 原生工具：扁平 function 定义；流式事件 response.output_item.added(function_call)
 * + function_call_arguments.delta/done + output_item.done；回放 function_call / function_call_output
 */
class OpenAiResponsesProvider extends AbstractProvider
{
    public function proto(): string
    {
        return 'openai_responses';
    }

    private function headers(bool $stream): array
    {
        return [
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Content-Type' => 'application/json',
            'Accept' => $stream ? 'text/event-stream' : 'application/json',
        ];
    }

    private function buildPayload(ChatRequest $req, bool $stream): array
    {
        $caps = ModelCaps::for($this->model);
        $effort = ModelCaps::reasoningEffort($caps);
        $maxOut = ModelCaps::outputBudget($caps, $effort);
        $system = $req->system;
        $input = [];

        if ($req->tools !== null) {
            // 原生模式：结构化回放（工具轮以 function_call / function_call_output 项呈现）
            foreach ($req->conversation->entries() as $e) {
                if ($e['role'] === 'tool') {
                    $input[] = ['type' => 'function_call_output', 'call_id' => $e['call']->id, 'output' => $e['json']];
                    continue;
                }
                $text = trim((string)($e['text'] ?? ''));
                if (isset($e['call'])) {
                    if ($text !== '') {
                        $input[] = ['role' => 'assistant', 'content' => $text];
                    }
                    $input[] = [
                        'type' => 'function_call',
                        'call_id' => $e['call']->id,
                        'name' => $e['call']->name,
                        'arguments' => (string)json_encode($e['call']->args, JSON_UNESCAPED_UNICODE),
                    ];
                    continue;
                }
                if ($text !== '') {
                    $input[] = ['role' => $e['role'], 'content' => $text];
                }
            }
        } else {
            $messages = $req->conversation->toPlainMessages();
            foreach ($messages as $m) {
                $input[] = ['role' => $m['role'], 'content' => $m['content']];
            }
            // 双保险：部分浅层中转的 /responses 只读最后一条 user，历史回放进 instructions 保住上下文（旧行为保持）
            if (count($messages) > 1) {
                $lines = [];
                foreach (array_slice($messages, 0, -1) as $m) {
                    $lines[] = ($m['role'] === 'assistant' ? '你' : '用户') . '：' . $m['content'];
                }
                $system .= "\n\n（你与用户最近的对话回放，延续该语境回复）\n" . implode("\n", $lines);
            }
        }

        $payload = ['model' => $this->model, 'instructions' => $system, 'input' => $input, 'stream' => $stream, 'store' => false, 'max_output_tokens' => $maxOut];
        $supported = $caps ? array_map('strval', (array)($caps['reasoningEfforts'] ?? [])) : [];
        if ($effort !== 'off') {
            $payload['reasoning'] = ['effort' => $effort];
        } elseif (in_array('none', $supported, true)) {
            $payload['reasoning'] = ['effort' => 'none']; // 显式关闭，推理模型默认 medium 太慢
        }
        if ($req->tools !== null) {
            $payload['tools'] = array_map(fn($t) => [
                'type' => 'function',
                'name' => $t['name'],
                'description' => $t['description'],
                'parameters' => self::normalizeSchema($t['schema']),
            ], $req->tools);
            $payload['tool_choice'] = 'auto';
            $payload['parallel_tool_calls'] = false;
        }
        return [$this->providerUrl('/v1/responses'), $this->headers($stream), $payload];
    }

    public function stream(ChatRequest $req, callable $onEvent): void
    {
        [$url, $headers, $payload] = $this->buildPayload($req, true);
        $fcalls = [];    // item_id => {call_id, name, args(json string 累积)}
        $emitted = [];   // call_id => true，防 done 兜底重复
        $failed = null;
        $this->pump($url, $headers, $payload, function (array $json) use (&$fcalls, &$emitted, &$failed, $onEvent) {
            $type = (string)($json['type'] ?? '');
            if ($type === 'response.output_text.delta') {
                $d = (string)($json['delta'] ?? '');
                if ($d !== '') {
                    $onEvent(StreamEvent::text($d));
                }
                return;
            }
            if ($type === 'response.output_item.added' && (($json['item']['type'] ?? '') === 'function_call')) {
                $id = (string)($json['item']['id'] ?? ('fc' . count($fcalls)));
                $fcalls[$id] = [
                    'call_id' => (string)($json['item']['call_id'] ?? $id),
                    'name' => (string)($json['item']['name'] ?? ''),
                    'args' => (string)($json['item']['arguments'] ?? ''),
                ];
                return;
            }
            if ($type === 'response.function_call_arguments.delta') {
                $id = (string)($json['item_id'] ?? '');
                if (isset($fcalls[$id])) {
                    $fcalls[$id]['args'] .= (string)($json['delta'] ?? '');
                }
                return;
            }
            if ($type === 'response.function_call_arguments.done') {
                $id = (string)($json['item_id'] ?? '');
                if (isset($fcalls[$id]) && (string)($json['arguments'] ?? '') !== '') {
                    $fcalls[$id]['args'] = (string)$json['arguments'];   // 权威全量覆盖累积
                }
                return;
            }
            if ($type === 'response.output_item.done' && (($json['item']['type'] ?? '') === 'function_call')) {
                $item = (array)$json['item'];
                $callId = (string)($item['call_id'] ?? ($item['id'] ?? ''));
                $args = json_decode((string)($item['arguments'] ?? ''), true);
                $onEvent(StreamEvent::tool(new ToolCall($callId, (string)($item['name'] ?? ''), is_array($args) ? $args : [])));
                $emitted[$callId] = true;
                unset($fcalls[(string)($item['id'] ?? '')]);
                return;
            }
            if ($type === 'response.failed' || $type === 'error') {
                $failed = (string)($json['response']['error']['message'] ?? ($json['error']['message'] ?? ($json['message'] ?? '上游返回失败')));
            }
        });
        if ($failed !== null) {
            throw new JSONException(mb_substr('上游错误：' . $failed, 0, 160));
        }
        // 容错：中转裁剪了 output_item.done 时，用累积参数补发
        foreach ($fcalls as $fc) {
            if ($fc['name'] === '' || isset($emitted[$fc['call_id']])) {
                continue;
            }
            $args = json_decode($fc['args'], true);
            $onEvent(StreamEvent::tool(new ToolCall($fc['call_id'], $fc['name'], is_array($args) ? $args : [])));
        }
        $onEvent(StreamEvent::done());
    }

    public function complete(ChatRequest $req): string
    {
        [$url, $headers, $payload] = $this->buildPayload($req, false);
        $json = $this->postJson($url, $headers, $payload);
        if (isset($json['output_text'])) {
            return (string)$json['output_text'];
        }
        $out = '';
        foreach ((array)($json['output'] ?? []) as $item) {
            foreach ((array)($item['content'] ?? []) as $c) {
                if (($c['type'] ?? '') === 'output_text') {
                    $out .= (string)($c['text'] ?? '');
                }
            }
        }
        return $out;
    }

    public function probeTools(): array
    {
        $payload = [
            'model' => $this->model,
            'instructions' => '你是能力探针，按要求调用工具。',
            'input' => [['role' => 'user', 'content' => '调用 probe 工具，参数 ping=ok']],
            'stream' => false,
            'store' => false,
            'max_output_tokens' => 64,
            'tools' => [[
                'type' => 'function', 'name' => 'probe', 'description' => '能力探测',
                'parameters' => ['type' => 'object', 'properties' => ['ping' => ['type' => 'string']], 'required' => ['ping']],
            ]],
            'tool_choice' => 'required',
        ];
        $url = $this->providerUrl('/v1/responses');
        try {
            $json = $this->postJson($url, $this->headers(false), $payload, 15);
            if ($this->hasFunctionCall($json)) {
                return ['native' => true, 'reason' => 'probe:tool_use', 'cacheable' => true];
            }
            if (isset($json['error'])) {
                throw new \RuntimeException((string)json_encode($json['error'], JSON_UNESCAPED_UNICODE));
            }
        } catch (\Throwable $e) {
            if (!ToolsCapability::looksLikeToolsRejection($e->getMessage())) {
                return ['native' => false, 'reason' => 'inconclusive:' . mb_substr($e->getMessage(), 0, 60), 'cacheable' => false];
            }
            // 有些中转透传 tools 但拒绝 tool_choice：去掉强制再试一次
            unset($payload['tool_choice']);
            try {
                $json = $this->postJson($url, $this->headers(false), $payload, 15);
                if ($this->hasFunctionCall($json)) {
                    return ['native' => true, 'reason' => 'probe:tool_use_noforce', 'cacheable' => true];
                }
            } catch (\Throwable $e2) {
            }
            return ['native' => false, 'reason' => 'http:' . mb_substr($e->getMessage(), 0, 80), 'cacheable' => true];
        }
        return ['native' => false, 'reason' => 'probe:silent_ignore', 'cacheable' => true];
    }

    private function hasFunctionCall(array $json): bool
    {
        foreach ((array)($json['output'] ?? []) as $item) {
            if (($item['type'] ?? '') === 'function_call') {
                return true;
            }
        }
        return false;
    }
}
