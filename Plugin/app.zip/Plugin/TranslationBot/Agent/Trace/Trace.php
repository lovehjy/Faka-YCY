<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent\Trace;

/**
 * Agent 执行轨迹（JSONL → runtime/agent.log）
 * - ai_debug 开：每回合一行；关：只落 err/fallback 行（常开故障取证）
 * - 隐私红线：不记录聊天内容（只记长度）、不记录 API key、base 只记 hash；
 *   工具参数截断 200 字符且 password/contact 类键打码
 */
class Trace
{
    //各自写各自的 runtime，别再往 PetAgent 目录里写
    private const FILE = BASE_PATH . '/runtime/plugin/TranslationBot/agent.log';
    private const MAX_BYTES = 5242880;   // 5MB 轮转

    private array $data;
    private float $t0;
    private bool $debugAll;

    public static function begin(string $ep, ?int $uid): self
    {
        $t = new self();
        $t->t0 = microtime(true);
        //原样复制自 PetAgent 时这里读的是 PetAgent 配置；改读本插件自己的，并吞掉异常
        $config = [];
        try {
            $config = (array)\App\Util\Plugin::getConfig('TranslationBot');
        } catch (\Throwable $e) {
        }
        $t->debugAll = (string)($config['ai_debug'] ?? '0') === '1';
        $t->data = [
            'ts' => date('c'),
            'turn' => substr(md5(uniqid('', true)), 0, 8),
            'ep' => $ep,
            'uid' => $uid,
            'guest' => $uid === null,
            'provider' => null, 'base' => null, 'model' => null, 'mode' => null, 'probe' => null,
            'rounds' => [],
            'fallback' => null, 'act' => null, 'err' => null,
        ];
        return $t;
    }

    public function upstream(string $proto, string $base, string $model, string $mode): void
    {
        $this->data['provider'] = $proto;
        $this->data['base'] = 'sha1:' . substr(sha1($base), 0, 12);
        $this->data['model'] = $model;
        $this->data['mode'] = $mode;
    }

    public function probe(string $reason): void
    {
        $this->data['probe'] = $reason;
    }

    /** @param array[] $calls [{name,args,ok,ms,data_len}] */
    public function round(int $n, float $ms, int $textLen, array $calls): void
    {
        $this->data['rounds'][] = ['n' => $n, 'ms' => (int)round($ms), 'text_len' => $textLen, 'calls' => $calls];
    }

    public static function callEntry(string $name, array $args, bool $ok, float $ms, int $dataLen): array
    {
        foreach ($args as $k => $v) {
            if (preg_match('/password|contact|secret|code/i', (string)$k)) {
                $args[$k] = '***';
            }
        }
        return [
            'name' => $name,
            'args' => mb_substr((string)json_encode($args, JSON_UNESCAPED_UNICODE), 0, 200),
            'ok' => $ok,
            'ms' => (int)round($ms),
            'data_len' => $dataLen,
        ];
    }

    public function fallback(string $from, string $reason, int $round): void
    {
        $this->data['fallback'] = ['from' => $from, 'reason' => mb_substr($reason, 0, 120), 'round' => $round];
    }

    public function act(string $kind): void
    {
        $this->data['act'] = $kind;
    }

    public function err(string $message): void
    {
        $this->data['err'] = mb_substr($message, 0, 200);
    }

    public function mode(string $mode): void
    {
        $this->data['mode'] = $mode;
    }

    public function end(): void
    {
        $this->data['total_ms'] = (int)round((microtime(true) - $this->t0) * 1000);
        if (!$this->debugAll && $this->data['err'] === null && $this->data['fallback'] === null) {
            return;
        }
        try {
            $dir = dirname(self::FILE);
            if (!is_dir($dir)) {
                @mkdir($dir, 0777, true);
            }
            if (is_file(self::FILE) && filesize(self::FILE) > self::MAX_BYTES) {
                @rename(self::FILE, self::FILE . '.1');
            }
            $fp = @fopen(self::FILE, 'a');
            if (!$fp) {
                return;
            }
            flock($fp, LOCK_EX);
            fwrite($fp, json_encode($this->data, JSON_UNESCAPED_UNICODE) . "\n");
            flock($fp, LOCK_UN);
            fclose($fp);
        } catch (\Throwable $e) {
            // 日志永不影响业务
        }
    }
}
