<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent;

/**
 * 协议中立的对话转录。
 * 条目形态：
 *   ['role'=>'user'|'assistant', 'text'=>string]                          纯文本
 *   ['role'=>'assistant', 'text'=>string, 'call'=>ToolCall]               助手发起工具调用（text 为调用前旁白，可空）
 *   ['role'=>'tool', 'call'=>ToolCall, 'json'=>string]                    工具结果（JSON 字符串，已截断）
 * 各 Provider 自行渲染成线上格式；prompt 回退模式统一走 toPlainMessages()。
 */
class Conversation
{
    /** @var array[] */
    private array $entries = [];

    /** 从前端历史（[{role,content}...]，已清洗）构建 */
    public static function fromHistory(array $messages): self
    {
        $c = new self();
        foreach ($messages as $m) {
            $role = ($m['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
            $c->entries[] = ['role' => $role, 'text' => (string)($m['content'] ?? '')];
        }
        return $c;
    }

    public function addUser(string $text): void
    {
        $this->entries[] = ['role' => 'user', 'text' => $text];
    }

    public function addAssistant(string $text): void
    {
        $this->entries[] = ['role' => 'assistant', 'text' => $text];
    }

    /** 本轮：助手旁白+工具调用+工具结果，一次性入转录 */
    public function addToolExchange(string $assistantText, ToolCall $call, string $resultJson): void
    {
        $this->entries[] = ['role' => 'assistant', 'text' => $assistantText, 'call' => $call];
        $this->entries[] = ['role' => 'tool', 'call' => $call, 'json' => $resultJson];
    }

    /** @return array[] */
    public function entries(): array
    {
        return $this->entries;
    }

    /**
     * 渲染为纯文本 messages（prompt 回退协议 / 浅层中转回放）：
     * 工具调用轮 → assistant 文本(≤800字符，含 <call> 原文的旁白已在入转录时截断)
     * 工具结果   → user "[tool:name] 结果：{json}"
     * 与旧版 Api::chat() 的消息拼装逐字一致，保证中途降级无缝续跑。
     */
    public function toPlainMessages(): array
    {
        $out = [];
        foreach ($this->entries as $e) {
            if ($e['role'] === 'tool') {
                /** @var ToolCall $call */
                $call = $e['call'];
                $out[] = ['role' => 'user', 'content' => '[tool:' . $call->name . '] 结果：' . $e['json']];
                continue;
            }
            $text = trim((string)($e['text'] ?? ''));
            if (isset($e['call']) && $text === '') {
                // 纯工具调用轮：prompt 协议下需要有占位旁白，回放调用原文
                /** @var ToolCall $call */
                $call = $e['call'];
                $text = '<call>' . json_encode(['name' => $call->name, 'args' => $call->args], JSON_UNESCAPED_UNICODE) . '</call>';
            }
            if ($text === '') {
                continue;
            }
            $out[] = ['role' => $e['role'], 'content' => $text];
        }
        return $out;
    }
}
