<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent;

/**
 * 一次工具调用（模型侧发起）
 * id：原生协议的调用ID（Responses call_id / Claude toolu_…；Gemini 无则生成），回放时必须原样带回
 */
class ToolCall
{
    public ?string $id;
    public string $name;
    public array $args;

    public function __construct(?string $id, string $name, array $args)
    {
        $this->id = $id ?: ('call_' . substr(md5($name . microtime() . random_int(0, 99999)), 0, 12));
        $this->name = $name;
        $this->args = $args;
    }
}
