<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent;

/**
 * 一次上游请求的全部输入。
 * tools = null 表示本轮不带原生工具（prompt 模式，或最终轮强制出文本）
 * tools 形态：[['name'=>..,'description'=>..,'schema'=>JSON Schema], ...]
 */
class ChatRequest
{
    public string $system;
    public Conversation $conversation;
    public ?array $tools;
    public bool $stream;

    public function __construct(string $system, Conversation $conversation, ?array $tools = null, bool $stream = true)
    {
        $this->system = $system;
        $this->conversation = $conversation;
        $this->tools = $tools;
        $this->stream = $stream;
    }
}
