<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent\Contract;

use App\Plugin\TranslationBot\Agent\ChatRequest;

interface ProviderInterface
{
    /** 流式对话：$onEvent 逐个收到 StreamEvent（text_delta | tool_call | done） */
    public function stream(ChatRequest $req, callable $onEvent): void;

    /** 非流式补全（suggest/compress 用），返回全文 */
    public function complete(ChatRequest $req): string;

    /**
     * 原生工具能力探测（一次极小请求）
     * @return array{native:bool, reason:string, cacheable:bool}
     */
    public function probeTools(): array;

    /** 能力缓存键素材：proto|base|model */
    public function cacheKey(): string;

    /** 协议名：openai_responses|claude|gemini */
    public function proto(): string;
}
