<?php
declare(strict_types=1);

namespace App\Plugin\TranslationBot\Agent\Capability;

use App\Plugin\TranslationBot\Agent\Contract\ProviderInterface;
use App\Plugin\TranslationBot\Agent\Trace\Trace;

/**
 * 原生工具能力：按 (provider|base|model) 探测并缓存到 runtime/toolcaps.json
 * - native 粘滞直到运行期降级；prompt 7 天后重探（中转会升级）
 * - 探测失败但原因与 tools 无关（401/429/超时）→ 本轮走 prompt 但不缓存
 */
class ToolsCapability
{
    //各自写各自的 runtime，别再往 PetAgent 目录里写
    private const FILE = BASE_PATH . '/runtime/plugin/TranslationBot/toolcaps.json';
    private const REPROBE_AFTER = 604800;   // prompt 结论 7 天后重探

    public static function modeFor(ProviderInterface $provider, ?Trace $trace = null): string
    {
        $key = md5($provider->cacheKey());
        $all = self::load();
        $entry = $all[$key] ?? null;
        if (is_array($entry)) {
            $mode = (string)($entry['mode'] ?? 'prompt');
            if ($mode === 'native') {
                return 'native';
            }
            if (time() - (int)($entry['t'] ?? 0) < self::REPROBE_AFTER) {
                return 'prompt';
            }
        }
        // 缓存未命中或 prompt 结论过期：探测一次
        $result = $provider->probeTools();
        if ($trace) {
            $trace->probe((string)$result['reason']);
        }
        if (!empty($result['cacheable'])) {
            self::store($key, [
                'mode' => $result['native'] ? 'native' : 'prompt',
                't' => time(),
                'reason' => (string)$result['reason'],
                'fails' => 0,
            ]);
        }
        return $result['native'] ? 'native' : 'prompt';
    }

    /** 运行期降级：native 轮次命中 tools 类报错时调用 */
    public static function demote(ProviderInterface $provider, string $reason): void
    {
        self::store(md5($provider->cacheKey()), [
            'mode' => 'prompt',
            't' => time(),
            'reason' => 'stream_error:' . mb_substr($reason, 0, 80),
            'fails' => 0,
        ]);
    }

    /** 错误文案是否像「不支持 tools」（探测与运行期降级共用） */
    public static function looksLikeToolsRejection(string $message): bool
    {
        return (bool)preg_match('/tool|function|unknown\s+(param|parameter|field|argument)|not\s*.?support|invalid.*(tool_choice|toolconfig|parallel)/i', $message);
    }

    private static function load(): array
    {
        $raw = @file_get_contents(self::FILE);
        $data = json_decode((string)$raw, true);
        return is_array($data) ? $data : [];
    }

    private static function store(string $key, array $entry): void
    {
        try {
            $dir = dirname(self::FILE);
            if (!is_dir($dir)) {
                @mkdir($dir, 0777, true);
            }
            $fp = fopen(self::FILE, 'c+');
            if (!$fp) {
                return;
            }
            flock($fp, LOCK_EX);
            $data = json_decode((string)stream_get_contents($fp), true);
            if (!is_array($data)) {
                $data = [];
            }
            $data[$key] = $entry;
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            flock($fp, LOCK_UN);
            fclose($fp);
        } catch (\Throwable $e) {
        }
    }
}
