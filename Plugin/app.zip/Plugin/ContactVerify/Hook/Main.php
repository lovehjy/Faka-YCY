<?php
declare (strict_types=1);

namespace App\Plugin\ContactVerify\Hook;

use Kernel\Annotation\Hook;
use Kernel\Exception\JSONException;

class Main
{
    /** 同一次请求只注入一次（RENDER_VIEW 渲染片段时也会触发） */
    private static bool $injected = false;

    /**
     * 把确认框的前端注入到所有前台页面。
     *
     * 不用模板挂载点（USER_VIEW_COMMODITY_POST / USER_VIEW_BODY）：19 套主题里有 9 套
     * 连 body 挂载点都没写，商品表单挂载点更是 0 覆盖。RENDER_VIEW 是唯一在全部主题上
     * 都生效的注入位。确认框长什么样由前端脚本克隆当前主题自己的联系方式输入框决定，
     * 插件不带任何"自己的一套"控件样式。
     *
     * @param string $html
     */
    #[Hook(point: \App\Consts\Hook::RENDER_VIEW)]
    public function renderView(string &$html): void
    {
        if (self::$injected) {
            return;
        }
        //只处理完整文档：渲染菜单等页面片段时原样放行
        if (!str_contains($html, '</body>')) {
            return;
        }
        //后台不注入：/admin 前缀之外，插件后台面板走 /plugin/{名}/ 路由，
        //按是否引用后台样式识别（前台主题不会引用 /assets/admin/）
        if (str_starts_with((string)($_GET['s'] ?? ''), '/admin') || str_contains($html, '/assets/admin/css/')) {
            return;
        }

        $config = getPluginConfig('ContactVerify');
        $placeholder = trim((string)($config['placeholder'] ?? ''));

        //文案统一走 lang()：随站点多语言自动翻译，站长自定义文案同样进词库
        $boot = json_encode([
            'placeholder' => $placeholder !== '' ? lang($placeholder) : lang('请再次输入联系方式'),
            'mismatch' => lang('两次联系方式输入不一致，请检查后重新输入'),
            'match' => lang('两次输入一致'),
            'aria' => lang('确认联系方式'),
        ], JSON_UNESCAPED_UNICODE); //保持默认的 "/" 转义，"</script" 不会提前闭合脚本标签

        $css = \Plugin('ContactVerify', 'View/contact-verify.css');
        $js = \Plugin('ContactVerify', 'View/contact-verify.js');
        $inject = "<link rel=\"stylesheet\" href=\"{$css}\">"
            . "<script" . self::nonceAttr() . ">window.__acgContactVerify={$boot};</script>"
            . "<script src=\"{$js}\" defer></script>";

        //注到最后一个 </body> 之前：正文里出现过 "</body>" 字样的富文本不会被误伤
        $pos = strripos($html, '</body>');
        $html = substr($html, 0, $pos) . $inject . substr($html, $pos);
        self::$injected = true;
    }

    /**
     * 下单校验。$map 与入库值同源（Filter::NORMAL 管线），
     * 不读 $_POST——超全局那份多了一层 htmlspecialchars，比对口径会错。
     *
     * @param array $map
     * @throws JSONException
     */
    #[Hook(point: \App\Consts\Hook::USER_API_ORDER_TRADE_BEGIN)]
    public function trade(array $map): void
    {
        $contact = trim((string)($map['contact'] ?? ''));

        if (!array_key_exists('confirm_contact', $map)) {
            //宽松模式：没带确认字段就不管（API 对接、无表单入口）。
            //强制模式：填了联系方式就必须确认。
            $config = getPluginConfig('ContactVerify');
            if (($config['strict'] ?? '0') == '1' && $contact !== '') {
                throw new JSONException(lang('请再次输入联系方式以确认无误'));
            }
            return;
        }

        $confirm = trim((string)$map['confirm_contact']);

        if ($contact === $confirm) {
            return;
        }
        //邮箱大小写不敏感：Foo@x.com 与 foo@x.com 是同一个收件人，不为难用户
        if (str_contains($contact, '@') && str_contains($confirm, '@')
            && mb_strtolower($contact) === mb_strtolower($confirm)) {
            return;
        }

        throw new JSONException(lang('两次联系方式输入不一致，请检查后重新输入'));
    }

    /**
     * 开了 CSP 就得给自己拼的内联脚本带上 nonce。
     *
     * 渲染出口是先注入 nonce、再触发 RENDER_VIEW 的，本方法在钩子里往 </body> 前塞脚本，
     * 时机晚了一步，天生没有 nonce，强制模式下会被拦掉、两次确认整个不生效。
     * 外链那段是同源的，'self' 已经覆盖，不用管。
     *
     * @return string
     */
    private static function nonceAttr(): string
    {
        try {
            if (class_exists('\\App\\Util\\Csp') && \App\Util\Csp::enabled()) {
                return ' nonce="' . \App\Util\Csp::nonce() . '"';
            }
        } catch (\Throwable $e) {
        }
        return '';
    }

}
