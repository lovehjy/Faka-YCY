/* 联系方式-两次确认（前端）
 *
 * 原则：
 * 1. 不带一套自己的控件——确认框是克隆当前主题的联系方式输入框得来的，
 *    class/type/inputmode/autocomplete 全部继承，天然与 19 套主题贴合。
 * 2. 不打扰——已登录且联系方式是预填的，不出现；用户动了联系方式才浮现。
 * 3. 不催促——正在输入且仍是前缀匹配时不判错；打完了或失焦了才亮红。
 * 4. 后端才是裁判——这里所有提示都只是引导，最终比对在服务端 Hook 里。
 */
(function () {
    'use strict';

    var boot = window.__acgContactVerify || {};
    if (boot.__mounted) return;
    boot.__mounted = true;

    var L = {
        placeholder: boot.placeholder || '请再次输入联系方式',
        mismatch: boot.mismatch || '两次联系方式输入不一致，请检查后重新输入',
        match: boot.match || '两次输入一致',
        aria: boot.aria || '确认联系方式'
    };

    var ICON_OK = '<svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="1.4"/><path d="M5 8.2l2 2 4-4.2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    var ICON_BAD = '<svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="1.4"/><path d="M8 4.8v4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="8" cy="11.2" r=".9" fill="currentColor"/></svg>';

    function norm(v) {
        return (v || '').trim();
    }

    /* 邮箱大小写不敏感，其余精确比对（与服务端口径一致） */
    function same(a, b) {
        if (a === b) return true;
        return a.indexOf('@') > -1 && b.indexOf('@') > -1 && a.toLowerCase() === b.toLowerCase();
    }

    /* 联系方式输入框所在的"字段容器"：沿父链上行，只要这一层仍只包含
     * 这一个控件就继续（图标包裹层、input-group 等），确认框插在容器之后，
     * 不会插进主题的图标组内部把布局挤坏。 */
    function fieldAnchor(input) {
        var anchor = input;
        var p = input.parentElement;
        var hops = 0;
        while (p && hops < 3 && p.tagName !== 'FORM' && p.tagName !== 'BODY'
            && p.querySelectorAll('input,select,textarea,button').length === 1) {
            anchor = p;
            p = p.parentElement;
            hops++;
        }
        return anchor;
    }

    function mount(contact) {
        if (contact.__acgCv) return;
        if (contact.type === 'hidden') return;
        var scope = contact.closest('.commodity-form') || contact.closest('form') || document;
        if (scope.querySelector('input[name=confirm_contact]')) { contact.__acgCv = true; return; }
        contact.__acgCv = true;

        /* 克隆主题自己的输入框：外观全部继承 */
        var confirm = contact.cloneNode(false);
        var strip = [];
        for (var i = 0; i < confirm.attributes.length; i++) {
            var n = confirm.attributes[i].name;
            if (n === 'id' || n === 'required' || n === 'autofocus' || n.indexOf('data-') === 0 || n.indexOf('on') === 0) strip.push(n);
        }
        strip.forEach(function (n) { confirm.removeAttribute(n); });
        confirm.name = 'confirm_contact';
        confirm.value = '';
        confirm.placeholder = L.placeholder;
        confirm.setAttribute('aria-label', L.aria);

        var wrap = document.createElement('div');
        wrap.className = 'acg-cv';
        var inner = document.createElement('div');
        inner.className = 'acg-cv__inner';
        var status = document.createElement('div');
        status.className = 'acg-cv__status';
        status.setAttribute('role', 'status');
        status.setAttribute('aria-live', 'polite');
        inner.appendChild(confirm);
        inner.appendChild(status);
        wrap.appendChild(inner);

        var initial = norm(contact.value);
        var prefilled = initial !== '';
        var blurred = false;
        var composing = false;

        function visible() {
            return wrap.classList.contains('acg-cv--on');
        }

        function show() {
            confirm.disabled = false;
            wrap.classList.add('acg-cv--on');
        }

        /* 隐藏即退场：disabled 的控件不进 FormData，服务端不会收到空确认值 */
        function hide() {
            confirm.disabled = true;
            confirm.value = '';
            wrap.classList.remove('acg-cv--on', 'acg-cv--ok', 'acg-cv--bad');
            blurred = false;
        }

        function render(state) {
            wrap.classList.toggle('acg-cv--ok', state === 'ok');
            wrap.classList.toggle('acg-cv--bad', state === 'bad');
            if (state === 'ok') status.innerHTML = ICON_OK + '<span></span>';
            if (state === 'bad') status.innerHTML = ICON_BAD + '<span></span>';
            if (state !== 'idle') status.lastChild.textContent = state === 'ok' ? L.match : L.mismatch;
        }

        function judge(force) {
            if (composing) return;
            var c = norm(contact.value);
            var v = norm(confirm.value);
            if (!v) { render('idle'); return; }
            if (same(c, v)) { render('ok'); return; }
            /* 还在敲、且到目前为止仍一致：保持安静，别在人打到一半时亮红 */
            var typing = !force && !blurred && v.length < c.length
                && same(c.slice(0, v.length), v);
            var wasBad = wrap.classList.contains('acg-cv--bad');
            render(typing ? 'idle' : 'bad');
            if (!typing && !wasBad) {
                wrap.classList.remove('acg-cv--nudge');
                void wrap.offsetWidth; /* 重新触发动画 */
                wrap.classList.add('acg-cv--nudge');
            }
        }

        confirm.addEventListener('compositionstart', function () { composing = true; });
        confirm.addEventListener('compositionend', function () { composing = false; judge(false); });
        confirm.addEventListener('input', function () { judge(false); });
        confirm.addEventListener('blur', function () {
            if (norm(confirm.value)) { blurred = true; judge(true); }
        });
        contact.addEventListener('input', function () {
            if (!visible()) {
                /* 预填值被改动，确认框此刻才浮现 */
                if (norm(contact.value) !== initial) show();
            } else if (prefilled && norm(contact.value) === initial) {
                /* 改回了原预填值：确认框功成身退 */
                hide();
            }
            if (visible()) judge(false);
        });

        /* 预填（已登录带账户联系方式）默认不打扰；空白（游客）直接展示。
         * 先插入再亮相，首屏不播动画、后续浮现才有过渡。 */
        confirm.disabled = true;
        fieldAnchor(contact).insertAdjacentElement('afterend', wrap);
        if (!prefilled) {
            show();
            /* 消除首屏展开动画：先瞬时定格，再恢复过渡 */
            wrap.style.transition = 'none';
            void wrap.offsetWidth;
            wrap.style.transition = '';
        }
    }

    function scan() {
        var inputs = document.querySelectorAll('.commodity-form input[name=contact], form input[name=contact]');
        for (var i = 0; i < inputs.length; i++) mount(inputs[i]);
    }

    function start() {
        scan();
        /* 弹窗购买、SKU 切换等场景表单是后渲染的：观察 DOM，短窗合并多次变更。
         * 不用 requestAnimationFrame 节流——后台标签页里 rAF 会被整个挂起，
         * pending 置真后回调永不执行，之后的挂载就全卡死了。 */
        var pending = false;
        new MutationObserver(function () {
            if (pending) return;
            pending = true;
            setTimeout(function () {
                pending = false;
                scan();
            }, 50);
        }).observe(document.body, { childList: true, subtree: true });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }
})();
