<?php
declare (strict_types=1);

return [
    [
        "title" => "服务端强制校验",
        "name" => "strict",
        "type" => "select",
        "placeholder" => "请选择校验模式",
        "dict" => [
            ["id" => 0, "name" => "宽松（推荐）：提交了确认字段才比对，不影响 API 对接下单"],
            ["id" => 1, "name" => "强制：填写了联系方式就必须二次确认，API 对接下单也会被要求"],
        ],
        "default" => 0
    ],
    [
        "title" => "确认框提示文字",
        "name" => "placeholder",
        "type" => "input",
        "placeholder" => "留空则使用默认：请再次输入联系方式"
    ],
];
