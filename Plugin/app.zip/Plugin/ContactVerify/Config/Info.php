<?php
declare(strict_types=1);

use App\Consts\Plugin;

return [
    Plugin::NAME => '联系方式-两次确认',
    Plugin::AUTHOR => '荔枝',
    Plugin::WEB_SITE => 'https://lizhime.com/7.moe',
    Plugin::DESCRIPTION => '下单时要求二次输入联系方式，实时比对、输错即提示，从源头减少因联系方式写错导致的发货失联。确认框自动匹配当前模板的输入框样式，全部模板通用；已登录且未改动预填联系方式时不打扰。',
    Plugin::VERSION => '1.0.2'
];
