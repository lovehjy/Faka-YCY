<?php
declare(strict_types=1);

namespace App\Controller\Base\View;

use App\Consts\Render;
use App\Model\Business;
use App\Model\Config;
use App\Util\Client;
use App\Util\RichHtml;
use App\Util\ViewSafe;
use App\Util\Theme;
use Kernel\Exception\JSONException;
use Kernel\Exception\ViewException;
use Kernel\Util\View;

abstract class User extends \App\Controller\Base\User
{
    protected array $indexTemplateList = [
        'INDEX', 'ITEM', 'QUERY', 'CLOSED'
    ];

    private const TRANSLATABLE_CONFIG = ['notice', 'shop_name', 'title', 'closed_message', 'commodity_name'];

    private function translateConfigText(array $config): array
    {
        foreach (self::TRANSLATABLE_CONFIG as $key) {
            if (!empty($config[$key]) && is_string($config[$key])) {
                $config[$key] = lang($config[$key], "dyn");
            }
        }
        return $config;
    }

    protected function render(string $title, string $template, array $data = []): string
    {
        try {
            require(BASE_PATH . "/app/View/User/Helper.php");

            $data['title'] = lang($title, "tpl");
            $data['app']['version'] = \config("app")['version'];
            $cfg = Config::list();

            foreach ($cfg as $k => $v) {
                $data["config"][$k] = $v;
            }

            $data['config'] = $this->translateConfigText($data['config']);
            return View::render('User/' . $template, ViewSafe::escape($data));
        } catch (\SmartyException $e) {
            throw new ViewException($e->getMessage());
        }
    }

    protected function theme(string $title, string $template, string $default, array $data = []): string
    {
        try {
            require(BASE_PATH . "/app/View/User/Helper.php");

            $data['title'] = lang($title, "tpl");
            $data['app']['version'] = \config("app")['version'];
            $data['favicon'] = "/favicon.ico";

            $cfg = Config::list();

            foreach ($cfg as $k => $v) {
                $data["config"][$k] = $v;
            }

            if (in_array($template, $this->indexTemplateList)) {
                if (Client::isMobile()) {
                    $theme = $cfg['user_mobile_theme'];
                    if ($data['config']['background_mobile_url']) {
                        $data['config']['background_url'] = $data['config']['background_mobile_url'];
                    }

                } else {
                    $theme = $cfg['user_theme'];
                }

                if ($theme == "0") {
                    $theme = $cfg['user_theme'];
                }
            } else {
                $centerTheme = $cfg['user_center_theme'] ?? "Cartoon";
                if (Client::isMobile()) {
                    $theme = $cfg['user_center_mobile_theme'] ?? "0";
                    if ($theme === "" || $theme === "0") {
                        $theme = $centerTheme;
                    }
                } else {
                    $theme = $centerTheme;
                }
                $theme = $theme ?: "Cartoon";
            }

            $data['static'] = "/app/View/User/Theme/" . $theme;

            $domain = Client::getDomain();
            $business = Business::query()->where("subdomain", $domain)->first() ?? Business::query()->where("topdomain", $domain)->first();
            if ($business) {
                $data['isBusinessSite'] = true;
                $data['config']['shop_name'] = $business->shop_name;
                $data['config']['title'] = $business->title;
                $data['config']['notice'] = RichHtml::sanitize((string)$business->notice, false);
                $data['config']['service_url'] = $business->service_url != "" ? $business->service_url : "https://wpa.qq.com/msgrd?v=1&uin={$business->service_qq}";
                if (!$data['from']) {
                    $data['from'] = $business->user_id;
                }
                $businessUser = $business->user;

                if ($businessUser && $businessUser->avatar) {
                    $data['favicon'] = $businessUser->avatar;
                }
            }

            $data['config'] = $this->translateConfigText($data['config']);

            $defaultThemePath = "User/Theme/Cartoon/";
            $themePath = "User/Theme/{$theme}/";
            $config = Theme::getConfig($theme);
            $path = $defaultThemePath . $default;
            $system = true;

            if (!empty($config['theme']) && key_exists($template, $config['theme'])) {
                $path = $themePath . $config['theme'][$template];
                $system = false;
            }

            $user = $this->getUser();
            if ($user) {
                $data['user'] = $user;
                $data['group'] = $this->getUserGroup()?->toArray();
            }

            if ($system) {
                $data['setting'] = Theme::getConfig("Cartoon")["setting"];
            } else {
                $data['setting'] = $config['setting'];
            }

            //语言切换器数据源。**必须以变量形式给模板**，不能让模板去调 lang_menu()：
            //Smarty 在编译期就校验普通函数是否存在，模板一旦更新到只有旧核心的站点上，
            //整页会抛 SmartyCompilerException 白屏；而未定义的变量只会渲染成空，最多是
            //切换器不显示。模板是独立上架、可以先于核心更新的，这个降级路径必须留着。
            $data['langs'] = \Kernel\Util\Lang::menu();

            $data = ViewSafe::escape($data);

            if ($config['info']['RENDER'] == Render::ENGINE_SMARTY || $system) {
                return View::render($path, $data);
            } elseif ($config['info']['RENDER'] == Render::ENGINE_PHP) {
                ob_start();
                require(BASE_PATH . '/app/View/' . $path);
                $result = ob_get_contents();
                ob_end_clean();
                if (\App\Util\Csp::enabled()) {
                    $result = \App\Util\Csp::injectNonce($result);
                }
                hook(\App\Consts\Hook::RENDER_VIEW, $result);
                return $result;
            }
        } catch (\SmartyException $e) {
            throw new ViewException($e->getMessage());
        }

        return "";
    }
}
