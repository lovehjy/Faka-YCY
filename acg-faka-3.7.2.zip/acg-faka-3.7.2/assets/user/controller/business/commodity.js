!function () {
    let table, _createForms = [];
    const isSeattleCommodity = Boolean(document.querySelector('[data-st-page="commodity"]'));
    const escapeHtml = value => String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    const safeInlineHtml = value => window.SeattleTheme && typeof window.SeattleTheme.safeInlineHtml === 'function'
        ? window.SeattleTheme.safeInlineHtml(value)
        : escapeHtml(value);
    const pairedMetric = (firstLabel, firstValue, secondLabel, secondValue) => {
        const value = item => escapeHtml(item == null || item === '' ? '—' : item);
        return `<span class="st-commodity-pair"><span><small>${escapeHtml(firstLabel)}</small><strong>${value(firstValue)}</strong></span><span><small>${escapeHtml(secondLabel)}</small><strong>${value(secondValue)}</strong></span></span>`;
    };
    const safeItem = item => {
        if (!item) return '-';
        if (!isSeattleCommodity) {
            const image = item.cover ? `<img src="${escapeHtml(item.cover)}" class="table-item-icon" alt="">` : '';
            return `<span class="table-item">${image}<span class="table-item-name">${safeInlineHtml(item.name || i18n('未命名商品'))}</span></span>`;
        }
        const image = item.cover
            ? `<span class="st-commodity-product-cell__media"><img src="${escapeHtml(item.cover)}" alt=""></span>`
            : '<span class="st-commodity-product-cell__media"><span class="material-icons-outlined" aria-hidden="true">inventory_2</span></span>';
        const category = item.category && item.category.name ? item.category.name : '未分类';
        return `<span class="st-commodity-product-cell">${image}<span class="st-commodity-product-cell__copy"><strong>${safeInlineHtml(item.name || i18n('未命名商品'))}</strong><small>${safeInlineHtml(category)}</small></span></span>`;
    };
    const modal = (title, assign = {}) => {
        component.popup({
            submit: '/user/api/commodity/save',
            tab: [
                {
                    name: title,
                    form: [
                        {
                            title: "商品分类",
                            name: "category_id",
                            type: "treeSelect",
                            placeholder: "请选择商品分类",
                            dict: `category?tree=true`,
                            required: true,
                            parent: false
                        },
                        {
                            title: "商品图标",
                            name: "cover",
                            type: "image",
                            placeholder: "请选择图标",
                            uploadUrl: '/user/api/upload/send',
                            photoAlbumUrl: '/user/api/upload/get',
                            required: true
                        },
                        {
                            title: "商品名称",
                            name: "name",
                            type: "textarea",
                            height: 38,
                            placeholder: "商品名称",
                            required: true
                        },
                        {
                            title: "零售价",
                            name: "price",
                            type: "input",
                            placeholder: "零售价",
                            tips: "零售价，游客看到的价格，0=免费",
                            required: true
                        },
                        {
                            title: "会员零售价",
                            name: "user_price",
                            type: "input",
                            tips: "会员零售价，登录后看到的价格，0=免费",
                            placeholder: "会员零售价",
                            required: true
                        },
                        {title: "排序", name: "sort", type: "input", default: 1000, placeholder: "排序，越小越靠前"},
                        {title: "状态", name: "status", type: "switch", text: "启用"},
                    ]
                },
                {
                    name: util.icon("fa-duotone fa-regular fa-truck") + i18n(" 发货设置"),
                    form: [
                        {
                            title: "发货方式",
                            name: "delivery_way",
                            type: "radio",
                            placeholder: "请选择",
                            dict: "_commodity_delivery_way",
                            default: 0,
                            required: true,
                            change: (_, __) => {
                                if (__ == 1) {
                                    _.show("delivery_message");
                                    _.hide("delivery_auto_mode");
                                    _.show("stock");
                                } else {
                                    _.hide("delivery_message");
                                    _.show("delivery_auto_mode");
                                    _.hide("stock");
                                }
                            },
                            complete: (_, __) => {
                                _.triggerOtherPopupChange("delivery_way", __);
                            }
                        },
                        {
                            title: "卡密排序",
                            name: "delivery_auto_mode",
                            type: "radio",
                            dict: "_commodity_delivery_auto_mode",
                            default: 0,
                            hide: true
                        },
                        {
                            title: "虚拟库存",
                            name: "stock",
                            type: "number",
                            placeholder: "虚拟库存数量",
                            default: 10000000,
                            tips: "虚拟库存，每购买1次，则减1，直到为0，商品就会已售罄",
                            hide: true
                        },
                        {
                            title: "发货信息",
                            name: "delivery_message",
                            type: "textarea",
                            placeholder: "手动发货信息，可以是一些固定的卡密或者软件下载链接等..",
                            height: 100,
                            hide: true
                        },
                        {
                            title: "发货留言",
                            name: "leave_message",
                            type: "textarea",
                            placeholder: "当用户购买商品后，该留言会显示在订单中",
                            height: 80,
                            tips: "当用户购买商品后，该留言会显示在订单中"
                        },
                        {
                            title: "联系方式",
                            name: "contact_type",
                            type: "radio",
                            dict: "_contact_type",
                            default: 0,
                            required: true
                        },
                        {
                            title: "邮件发送",
                            name: "send_email",
                            type: "switch",
                            text: "启用",
                            tips: "用户购买商品后，会将卡密信息发送至邮箱，仅联系方式为邮箱状态下有效。"
                        },
                        {
                            title: "查询密码",
                            name: "password_status",
                            type: "switch",
                            text: "启用",
                            tips: "开启后，下单时需要设置查询订单的密码，更强的保护用户隐私"
                        },
                    ]
                },
                {
                    name: util.icon("fa-duotone fa-regular fa-pen-field") + i18n(" 控件"),
                    form: [
                        {
                            name: "widget",
                            type: "widget",
                            height: 660
                        },
                    ]
                },
                {
                    name: util.icon("fa-duotone fa-regular fa-circle-info") + i18n(" 商品介绍"),
                    form: [
                        {
                            title: false,
                            name: "description",
                            type: "editorv2",
                            placeholder: "介绍一下你的商品..",
                            required: true,
                            uploadUrl: '/user/api/upload/send',
                        },
                    ]
                },
                {
                    name: util.icon("fa-duotone fa-regular fa-shop-lock") + i18n(" 商品限制"),
                    form: [
                        {
                            title: "最低购买数量",
                            name: "minimum",
                            type: "input",
                            tips: "单次最低购买数量，0=不限制，默认0",
                            default: 0,
                            placeholder: "单次最低购买数量"
                        },
                        {
                            title: "最大购买数量",
                            name: "maximum",
                            type: "input",
                            tips: "单次最大购买数量，0=不限制，默认0",
                            default: 0,
                            placeholder: "单次最大购买数量"
                        },
                        {title: "优惠券", name: "coupon", type: "switch"},
                        {
                            title: "限时秒杀",
                            name: "seckill_status",
                            type: "switch",
                            text: "启用",
                            change: (_, __) => {
                                if (__ == 1) {
                                    _.show('seckill_start_time');
                                    _.show('seckill_end_time');
                                } else {
                                    _.hide('seckill_start_time');
                                    _.hide('seckill_end_time');
                                }
                            },
                            complete: (_, __) => {
                                _.triggerOtherPopupChange("seckill_status", __);
                            }
                        },
                        {
                            title: "秒杀开始时间",
                            name: "seckill_start_time",
                            type: "date",
                            placeholder: "开始时间",
                            hide: true
                        },
                        {
                            title: "秒杀结束时间",
                            name: "seckill_end_time",
                            type: "date",
                            placeholder: "结束时间",
                            hide: true
                        },
                        {
                            title: "卡密预选",
                            name: "draft_status",
                            type: "switch",
                            text: "启用",
                            tips: "顾名思义，意思就是顾客在购买时，可以预先选择想要购买的那个卡密，一般针对于出售游戏账号等用途。",
                            change: (_, __) => {
                                if (__ == 1) {
                                    _.show('draft_premium');
                                } else {
                                    _.hide('draft_premium');
                                }
                            },
                            complete: (_, __) => {
                                _.triggerOtherPopupChange("draft_status", __);
                            }
                        },
                        {
                            title: "预选加价",
                            name: "draft_premium",
                            type: "input",
                            tips: "如果用户使用预选功能，则会加价购买",
                            placeholder: "加价金额",
                            hide: true
                        },
                        {
                            title: "仅限会员购买",
                            name: "only_user",
                            type: "switch",
                            text: "启用",
                            tips: "用户必须登录后才能购买商品"
                        },
                        {
                            title: "会员限购",
                            name: "purchase_count",
                            type: "input",
                            placeholder: "0代表不限制",
                            tips: "0代表不限制，如果限制了购买数量，那么用户必须登录才能购买",
                            default: 0,
                        },
                        {
                            title: "隐藏库存",
                            name: "inventory_hidden",
                            type: "switch",
                            text: "启用",
                            tips: "该功能开启后，库存会被隐藏"
                        },
                        {
                            title: "禁用折扣",
                            name: "level_disable",
                            type: "switch",
                            text: "禁用",
                            tips: "如果禁用会员等级后，那么登录用户购买该商品将无法应用会员折扣，不包含会员价。"
                        }
                    ]
                },
                {
                    name: util.icon("fa-duotone fa-regular fa-gears") + i18n(" 配置参数"),
                    form: [
                        {title: false, name: "config", type: "textarea", placeholder: "配置参数", height: 480},
                        {
                            title: false, name: "config_tips", type: "custom", complete: (_, __) => {
                                __.html(`<div class="uc-cardtip"><div class="uc-cardtip__warn"><span class="material-icons-outlined">info</span><span>${i18n('配置参数包含商品种类、多')} SKU ${i18n('等高级功能。修改前请先阅读')}<a href="https://faka.wiki/#/zh-cn/goods-config" target="_blank" rel="noopener noreferrer">${i18n('配置文档')}</a>。</span></div></div>`);
                            }
                        },
                    ]
                }
            ],
            assign: assign,
            autoPosition: true,
            content: {
                css: {
                    height: "auto",
                    overflow: "inherit"
                }
            },
            height: "auto",
            width: "820px",
            done: () => {
                table.refresh();
            }
        });
    }

    const uploadCard = (commodityId) => {
        component.popup({
            submit: '/user/api/card/save',
            tab: [
                {
                    name: util.icon("fa-duotone fa-regular fa-folder-arrow-up") + " 上传卡密",
                    form: [
                        {
                            title: false,
                            name: "commodity_id",
                            type: "input",
                            default: commodityId,
                            hide: true,
                            complete: (_, __) => {
                                _.setRadio("race_get_mode", 0, true);
                                _.setInput("race_input", "");

                                _.hide("race");
                                _.hide("race_input");
                                _.clearComponent("race");
                                _.hide("race_get_mode");
                                _createForms.forEach(k => _.removeForm(k));
                                _createForms = [];

                                util.get(`/user/api/card/sku?commodityId=${commodityId}`, data => {
                                    if (!util.isEmptyOrNotJson(data?.category)) {
                                        let i = 0;
                                        for (const cKey in data.category) {
                                            _.addRadio("race", cKey, cKey, i === 0);
                                            i++;
                                        }
                                        _.show("race");
                                        _.show(`race_get_mode`);
                                    }
                                    if (!util.isEmptyOrNotJson(data?.sku)) {
                                        for (const sKey in data.sku) {
                                            let dict = [];
                                            for (const sk in data.sku[sKey]) {
                                                dict.push({id: sk, name: sk});
                                            }
                                            _.createForm({
                                                title: sKey,
                                                name: `sku.${sKey}`,
                                                type: "radio",
                                                dict: dict
                                            }, "race", "after");
                                            _createForms.push(`sku-${sKey}`);
                                        }
                                    }
                                });

                            }
                        },
                        {
                            title: "种类获取方法",
                            name: "race_get_mode",
                            type: "radio",
                            dict: [{id: 0, name: "自动获取"}, {id: 1, name: "手动填写(如独立设置了会员等级)"}],
                            hide: true,
                            change: (_, __) => {
                                if (__ == 1) {
                                    _.hide("race");
                                    _.show("race_input");
                                } else {
                                    _.show("race");
                                    _.hide("race_input");
                                }
                            }
                        },
                        {
                            title: "商品种类",
                            name: "race_input",
                            type: "input",
                            placeholder: "请填写商品种类",
                            hide: true
                        },
                        {
                            title: "商品种类",
                            name: "race",
                            type: "radio",
                            placeholder: "商品类别，一般你用不着，而且不懂不要乱填哦，想用请查看说明文档",
                            hide: true
                        },
                        {
                            title: "备注信息",
                            name: "note",
                            type: "input",
                            placeholder: "备注信息(可空)，方便查询某次添加的卡密"
                        },
                        {
                            title: "卡密类型",
                            name: "card_type",
                            type: "radio",
                            dict: [
                                {id: 0, name: "普通卡密"},
                                {id: 1, name: "账号/预告"}
                            ],
                            change: (form, val) => {
                                if (val == 0) {
                                    form.show("general_card");
                                    form.hide("account_card");
                                } else {
                                    form.hide("general_card");
                                    form.show("account_card");
                                }
                            }
                        },
                        {
                            title: false,
                            name: "general_card",
                            type: "custom",
                            complete: (form, dom) => {
                                dom.html(`<div class="uc-cardtip">
          <p>${i18n('一行一个库存卡密，内容随意。买家购买后直接获得该行内容，下面示例：')}</p>
          <pre class="uc-cardtip__code">ABCDEF-GHIJK-LMNOP
VIP-2025-0821-XYZ</pre>
        </div>`);
                            }
                        },
                        {
                            title: false,
                            hide: true,
                            name: "account_card",
                            type: "custom",
                            complete: (form, dom) => {
                                dom.html(`<div class="uc-cardtip">
          <p>${i18n('一行一个，必须使用')} <code>║</code> ${i18n('分隔，结构为：')}<b>${i18n('卡密本体')} ║ ${i18n('预告信息')} ║ ${i18n('自选加价金额')}(${i18n('可选')})</b></p>
          <ul class="uc-cardtip__legend">
            <li><span class="a-badge a-badge-dark">${i18n('卡密本体')}</span><span>${i18n('买家付款后实际获得的完整内容')}</span></li>
            <li><span class="a-badge a-badge-success">${i18n('预告信息')}</span><span>${i18n('买家下单时可见，用于自选')}</span></li>
            <li><span class="a-badge a-badge-warning">${i18n('自选加价金额')}</span><span>${i18n('选填，不写默认为')} 0</span></li>
          </ul>
          <pre class="uc-cardtip__code">${i18n('账号')}:testname--${i18n('密码')}:testpassword123║${i18n('大区')}:${i18n('神境之地')}--${i18n('等级')}:100║5.5
ACC_US_12M_9F2K-7QPA-88XZ║${i18n('地区')}:${i18n('美区')}·${i18n('时长')}:12${i18n('个月')}║20
ACC_JP_6M_0KLD-22MM-PP31║${i18n('地区')}:${i18n('日区')}·${i18n('时长')}:6${i18n('个月')}</pre>
          <div class="uc-cardtip__warn"><span class="material-icons-outlined">warning_amber</span><span>${i18n('必须使用特殊符号')} <strong>║</strong>（U+2551），${i18n('不要用普通竖线')} |</span></div>
        </div>`);
                            }
                        },
                        {
                            title: "卡密信息",
                            name: "secret",
                            type: "textarea",
                            placeholder: "卡密信息，一行一个",
                            preserveLiteral: true,
                            height: 200
                        },
                        {
                            title: "去除重复",
                            name: "unique",
                            type: "switch",
                            text: "启用（保持数据唯一，会占用CPU资源）"
                        },
                    ]
                },
            ],
            autoPosition: true,
            height: "auto",
            width: "680px",
            done: () => {
                table.refresh();
            }
        });
    }

    table = new Table("/user/api/commodity/data", "#commodity-table");
    table.setUpdate("/user/api/commodity/save");
    table.setColumns([
        {
            field: 'category.name', title: '分类', class: 'nowrap', width: 120,
            visible: !isSeattleCommodity,
            formatter: value => safeInlineHtml(value || '—')
        }
        , {
            field: 'name', title: isSeattleCommodity ? '商品' : '商品名称', class: 'nowrap',
            width: isSeattleCommodity ? 220 : 180,
            formatter: (_, __) => safeItem(__)
        }
        , {
            field: 'card_count', title: '库存', class: 'nowrap', width: isSeattleCommodity ? 104 : 120, formatter: function (val, item) {
                if (item.delivery_way == 0) {
                    return `${item.card_count} <button type="button" class="add-card a-badge-glass nowrap" data-id="${item.id}" title="${i18n('上传卡密')}" aria-label="${i18n('为此商品上传卡密')}">${i18n('上传卡密')}</button>`;
                }
                return item.stock;
            }
        }
        , ...(isSeattleCommodity ? [
            {
                field: 'st_price_pair', title: '售价', class: 'nowrap st-commodity-pair-column', width: 100,
                formatter: (_, item) => pairedMetric('零售', item.price, '会员', item.user_price)
            },
            {
                field: 'st_recent_pair', title: '近两日', class: 'nowrap st-commodity-pair-column', width: 100,
                formatter: (_, item) => pairedMetric('今日', item.order_today_amount, '昨日', item.order_yesterday_amount)
            },
            {
                field: 'st_total_pair', title: '销量', class: 'nowrap st-commodity-pair-column', width: 100,
                formatter: (_, item) => pairedMetric('本周', item.order_week_amount, '全部', item.order_all_amount)
            }
        ] : [
            {field: 'price', title: '零售价', class: 'nowrap', width: 90},
            {field: 'user_price', title: '会员价', class: 'nowrap', width: 90},
            {field: 'order_today_amount', title: '今日', class: 'nowrap', width: 80},
            {field: 'order_yesterday_amount', title: '昨日', class: 'nowrap', width: 80},
            {field: 'order_week_amount', title: '本周', class: 'nowrap', width: 80},
            {field: 'order_all_amount', title: '全部', class: 'nowrap', width: 80}
        ])
        , {field: 'sort', title: '排序', class: 'nowrap', width: 80}
        , {
            field: 'share_url', title: '推广链接', type: "button", class: 'nowrap', width: 100, buttons: [
                {
                    icon: 'fa-duotone fa-regular fa-copy',
                    class: "text-primary",
                    title: "复制",
                    click: (event, value, row, index) => {
                        util.copyTextToClipboard(row.share_url, () => {
                            message.success("复制成功");
                        });
                    }
                },
            ]
        }
        , {
            field: 'status', title: '状态', type: "switch", text: "上架|下架", reload: true, class: "nowrap", width: 96
        },
        {
            field: 'operation', title: '操作', type: 'button', class: 'nowrap', width: 210, buttons: [
                {
                    icon: 'fa-duotone fa-regular fa-pen-to-square',
                    class: "text-primary",
                    title: "编辑",
                    click: (event, value, row, index) => {
                        modal(util.icon("fa-duotone fa-regular fa-pen-to-square me-1") + "修改商品", row);
                    }
                },
                {
                    icon: 'fa-duotone fa-regular fa-copy',
                    class: "text-warning",
                    title: "克隆",
                    click: (event, value, row, index) => {
                        const clone = {...row};
                        delete clone.id;
                        modal(util.icon("fa-duotone fa-regular fa-copy me-1") + "克隆商品", clone);
                    }
                },
                {
                    icon: 'fa-duotone fa-regular fa-trash-can',
                    class: "text-danger",
                    title: "删除",
                    click: (event, value, row, index) => {
                        message.ask("是否删除此商品？", () => {
                            util.post('/user/api/commodity/del', {id: row.id}, res => {
                                message.success("删除成功");
                                table.refresh();
                            });
                        });
                    }
                }
            ]
        },
    ]);

    table.setColumnDetail({
        column: 'name',
        trigger: 'dblclick',
        header: false,
        title: (row) => row.name,
        fields: [
        {field: 'id', title: '商品ID'},
        {
            field: 'card_success_count', title: '已出售'
        },
        {
            field: 'delivery_way', title: '发货方式', dict: "_commodity_delivery_way"
        },
        {
            field: 'delivery_auto_mode', title: '出库顺序', dict: "_commodity_delivery_auto_mode"
        },
        {
            field: 'contact_type', title: '联系方式', dict: "_contact_type"
        },
        {
            field: 'password_status', title: '订单密码', dict: "_commodity_api_status"
        },
        {
            field: 'coupon', title: '优惠券', dict: "_commodity_api_status"
        },
        {
            field: 'seckill_status', title: '商品秒杀', dict: "_commodity_api_status"
        },
        {
            field: 'seckill_start_time', title: '秒杀时间(开始)'
        },
        {
            field: 'seckill_end_time', title: '秒杀时间(结束)'
        },
        {
            field: 'draft_status', title: '预选卡密', dict: "_commodity_api_status"
        },
        {
            field: 'draft_premium', title: '预选加价'
        },
        {
            field: 'inventory_hidden', title: '隐藏库存', dict: "_commodity_api_status"
        },
        {
            field: 'send_email', title: '发送邮件', dict: "_commodity_api_status"
        },
        {
            field: 'only_user', title: '仅限会员购买(需登录)', dict: "_commodity_api_status"
        },
        {
            field: 'purchase_count', title: '限购数量(需登录)'
        },
        {
            field: 'minimum', title: '单次最低购买数量'
        },
        {
            field: 'level_disable', title: '禁用所有折扣(含优惠券)', dict: "_commodity_api_status"
        },
        {
            field: 'create_time', title: '创建时间'
        },
        ]
    });

    table.setSearch([
        {title: "商品分类", name: "equal-category_id", type: "select", dict: "category", search: true},
        {title: "商品名称(模糊搜索)", name: "search-name", type: "input"}
    ]);
    table.setState("status", "_commodity_status");

    table.render();


    $('.button-add').click(function () {
        modal(`<i class="fa-duotone fa-regular fa-circle-plus"></i> ${i18n('添加商品')}`);
    });


    $(document).off("click", ".add-card").on("click", ".add-card", function () {
        const id = $(this).data("id");
        uploadCard(id);
    });
}();
